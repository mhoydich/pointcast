# Industry Next Communications Lab brand and program kit

Original proposed identity and 12 project explorations for 2026/2027. No affiliation with Nokia Bell Labs, AT&T or their affiliates. No claims of historical inventions, existing facilities, confirmed partnerships or live job offers.

## Contents
- content.json: all project briefs, publication copy and governance notes
- brand-tokens.css: implementation tokens
- assets/: editable SVG wordmarks, mark, six icons, three posters, letterhead and researcher card
- templates/: editable research note, experiment log and email signature
- program-guide.pdf: 12-page designed program and identity guide
- build.py: editable source for regeneration (Python + reportlab)

## Brand use
Use the signal-grid mark as an original motif; never combine it with a Bell Labs or AT&T logo. Keep clear space equal to the orange dot diameter on all sides; minimum mark width 28 px or 10 mm. Use full wordmark above 240 px; below that use the mark and live-text name. Do not stretch, add shadows, rotate or recolor the mark beyond supplied one-color equivalents.

Cobalt and ink on paper are primary text combinations. Orange is a signal/accent, never the only status cue; avoid small orange body text on paper. Pair every state with a written label. Use 8 px spacing steps, 16 px minimum web body text and visible keyboard focus. Honor reduced motion.

Fonts are system sans-serif and system monospace; no proprietary font is bundled. Main SVG assets use outlined DejaVu Sans for reliable rendering. Editable text versions are in assets/editable; these may vary by installed font. Regenerate with build.py, then outline_assets.py. SVG artwork is original. No third-party illustration assets are included.

## Before launch
Confirm pay, hours, eligibility, supervisor, location, agreements and legal requirements. Budgets are illustrative USD materials estimates excluding labor, tax and shipping; no purchases are authorized. Do not collect applications or personal data through these assets. PointCast venue, partnership and installation permissions remain unconfirmed. Public program copy may be published as explorations only.

## Deployment
Use content.json as the source of truth. Keep status, affiliation, materials-budget and PointCast notes visible. Link each project to a readable detail view; do not invent an application endpoint. Intended destinations are the intern hub and industrynext.xyz; this kit does not establish deployment status.
