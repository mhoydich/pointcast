from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
import xml.etree.ElementTree as E
P=Path(__file__).parent
E.register_namespace('','http://www.w3.org/2000/svg')
fonts={w:TTFont('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if w=='700' else '')+'.ttf') for w in ['400','700']}
(P/'assets'/'editable').mkdir(exist_ok=True)
for f in (P/'assets').glob('*.svg'):
 src=f.read_text(); (P/'assets'/'editable'/f.name).write_text(src);root=E.fromstring(src)
 def walk(parent,inherited):
  props={**inherited,**parent.attrib}
  for el in list(parent):
   if el.tag.endswith('text'):
    a={**props,**el.attrib};font=fonts['700' if a.get('font-weight') in ['700','bold'] else '400'];gs=font.getGlyphSet();cmap=font.getBestCmap();scale=float(a.get('font-size','16'))/font['head'].unitsPerEm;x=float(a.get('x','0'));y=float(a.get('y','0'));letter=float(a.get('letter-spacing','0'))
    g=E.Element('{http://www.w3.org/2000/svg}g',{'fill':a.get('fill','#171B22'),'aria-label':el.text or ''})
    for ch in el.text or '':
     name=cmap.get(ord(ch),'.notdef');pen=SVGPathPen(gs);gs[name].draw(pen);d=pen.getCommands()
     if d:E.SubElement(g,'{http://www.w3.org/2000/svg}path',{'d':d,'transform':f'translate({x:.3f} {y}) scale({scale:.6f} {-scale:.6f})'})
     x+=font['hmtx'][name][0]*scale+letter
    idx=list(parent).index(el);parent.remove(el);parent.insert(idx,g)
   else:walk(el,props)
 walk(root,{})
 f.write_text(E.tostring(root,encoding='unicode'))
