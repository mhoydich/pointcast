# [Experiment title]

Industry Next Communications Lab
Research note [ID] • [Date] • [Author] • [Human reviewer]

## Question
[One falsifiable question and why it matters]

## Scope and authority
[Data, tools, budget cap, consent and human approval boundaries]

## Method
[Baseline, apparatus, versions, steps, repetitions and known constraints]

## Evidence
[Results with units, sample size, source, timestamps and artifact references]

## What failed
[Unexpected outcomes, missing evidence and limitations]

## Conclusion
[Supported conclusion separated from interpretation]

## Reproduce this
[Safe setup, dependencies, fixtures, expected outputs and tolerances]

## Release check
[License, privacy, accessibility, retention and human signoff]
