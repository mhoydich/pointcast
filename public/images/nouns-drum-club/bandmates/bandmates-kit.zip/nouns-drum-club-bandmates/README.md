# Nouns Drum Club Bandmates kit

Twelve playable collectible previews for PointCast’s Nouns Drum Club. This collection is **not minted**. There is no contract, token, price, edition cap, creator wallet, signing request, or financial claim in this package.

## Contents

- 12 PNG cards at 1600 × 1600.
- 12 WebP previews at 800 × 800.
- 12 SVG companion sources at 1600 × 1600.
- 12 preview metadata files generated from the same adapter used by the website.
- Canonical 16-step scores in `data/nouns-drum-club-bandmates.json`.
- Artwork and score provenance plus `SHA256SUMS.txt`.

Each metadata file links to the exact score in the free Drum Club player. Opening a link does not autoplay audio; a person must enable sound. The underlying Noun artwork is CC0. PointCast publishes these cards and scores as remix-friendly project sources; no additional formal license has been selected.
