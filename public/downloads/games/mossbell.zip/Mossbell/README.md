# Mossbell 0.1

A little animal town with room for two. This is a playable browser prototype with original characters and artwork. Its save is separate from Good Fortune.

## Start playing

Unzip the package and open `Mossbell.html` in a current desktop browser. The game contains its artwork and code in one file and needs no installation or account.

For a stable local address on this Mac, open `Start-Mossbell.command`. It uses the Mac's Python 3 to open `http://127.0.0.1:48379/`. Keep its Terminal window open while playing; Control-C stops the local server. If macOS prevents opening the command, run `python3 serve.py` from the unzipped folder. Use the same browser and address each time to retain your town.

Walk with WASD or arrow keys, or tap a path. E interacts, H goes home or steps outside, and B opens your pocket. Find Oona, Pella, and Boro from the neighbor panel. Explore the pond's edge for discoveries, give discoveries to a neighbor, and bring three different treasures to the picnic corner. Enter your home, choose a furnishing from your pocket, and tap the floor to place it. Tap placed furniture to rotate, move, or return it to your pocket.

## Invite one friend

Both people open their copy of the game in a browser. They do not need to share a save or run a public server.

1. The host chooses **Invite a friend**, then opens their town. Copy the invitation and send it to the guest through a channel you choose.
2. The guest chooses **Invite a friend**, switches to visiting a town, and pastes the invitation. Create a reply and send it back to the host.
3. The host pastes the reply and welcomes the visitor. Wait for the connected message, then close the invitation panel and play.

Visits use an encrypted WebRTC data channel between the two browsers. There is no game backend or account. The default Internet mode asks a public STUN service for connection candidates; it does not send it your town save. Invitation and reply codes contain connection information, so share them with the intended guest. **Skip public connection discovery** disables STUN for the next visit you open or join; choose it on both browsers when playing on the same local network. It does not enforce a network boundary.

This version supports one host and one guest. The host controls the shared world. Both can walk, talk, collect, donate, and wave. Only the host can decorate the host's home. The guest's visit pocket is temporary, and leaving restores the guest's own saved town. Shared discoveries, friendships, and picnic contributions stay with the host.

Keep the host browser open. When the host closes the game or ends the visit, the guest returns home. There is no TURN relay in this version, so some restrictive networks cannot connect. A real connection between two independent browser clients on this Mac was verified; a visit across different Internet networks has not yet been independently verified.

## Saves and backups

The game automatically saves in browser local storage. Browser profiles and origins have separate saves. Moving the HTML file or switching from a file to the local launcher may use a different save location. Export a backup before switching.

Use the menu to export a JSON backup. If downloading is unavailable, copy the backup text shown in the menu. Restore accepts a JSON file or pasted backup text, validates it, and shows a preview before replacement. A failed or malformed restore does not replace the current town. A corrupt existing save is retained for recovery and is not silently overwritten.

The game reads only its own `mossbell-town-v1` storage key. It does not read Good Fortune's private reflections or other application data. There are no analytics, runtime AI calls, wallet connections, camera requests, or microphone requests.

## Source and checks

The package includes the editable source. `index.html`, `style.css`, `app.mjs`, `core.mjs`, `peer.mjs`, and `render.mjs` form the game. `assets/atlas.png` is the original generated character and environment atlas; its generation prompt and map accompany it.

With Node.js available, run:

```
npm test
npm run build
```

There are no npm dependencies to install. Building regenerates `Mossbell.html` and `dist/index.html`. The included verification report distinguishes pure unit checks from actual browser and peer connection checks.

This is a browser game prototype. Find the PointCast web edition and participation guide at https://pointcast.xyz/play/games/mossbell/. Responsive styles are included; mobile hardware and visits across different Internet networks remain to be tested.
