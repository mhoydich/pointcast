// Mossbell's local world rules. No storage, DOM, network, or timers live here.
export const TILE_SIZE = 32;
export const TOWN = Object.freeze({
  width: 28, height: 22, tileSize: TILE_SIZE,
  pond: Object.freeze({ x: 19, y: 3, w: 7, h: 7 }),
  home: Object.freeze({ x: 3, y: 3, w: 6, h: 5, door: Object.freeze({ x: 6, y: 8 }) }),
  spawn: Object.freeze({ x: 13, y: 13 }),
});
export const HOME = Object.freeze({
  width: 14, height: 12, tileSize: TILE_SIZE,
  spawn: Object.freeze({ x: 7, y: 10 }), exit: Object.freeze({ x: 7, y: 10 }),
});
export const PROJECT = Object.freeze({ id: 'picnic', name: 'The little picnic corner', x: 14, y: 15, required: 3 });

export const FURNITURE_CATALOG = Object.freeze([
  { id: 'fern-pot', name: 'Fern pot', color: '#78a96e', w: 1, h: 1, kind: 'plant', emoji: '🌿' },
  { id: 'round-table', name: 'Round tea table', color: '#d9a66e', w: 2, h: 2, kind: 'table', emoji: '🫖' },
  { id: 'moss-chair', name: 'Moss chair', color: '#95ad77', w: 1, h: 1, kind: 'chair', emoji: '🪑' },
  { id: 'cloud-sofa', name: 'Cloud sofa', color: '#e6beac', w: 2, h: 1, kind: 'sofa', emoji: '🛋️' },
  { id: 'bookcase', name: 'Little bookcase', color: '#bc8966', w: 2, h: 1, kind: 'books', emoji: '📚' },
  { id: 'sun-lamp', name: 'Sun lamp', color: '#e8c36b', w: 1, h: 1, kind: 'lamp', emoji: '💡' },
  { id: 'berry-rug', name: 'Berry rug', color: '#c68b93', w: 2, h: 2, kind: 'rug', emoji: '🧶' },
  { id: 'tiny-bed', name: 'Patchwork bed', color: '#b5b8d4', w: 2, h: 2, kind: 'bed', emoji: '🛏️' },
  { id: 'tea-tray', name: 'Tea tray', color: '#cdad79', w: 1, h: 1, kind: 'tea', emoji: '☕' },
  { id: 'shell-vase', name: 'Shell vase', color: '#e0c9ae', w: 1, h: 1, kind: 'vase', emoji: '🏺' },
  { id: 'little-radio', name: 'Little radio', color: '#91b6af', w: 1, h: 1, kind: 'radio', emoji: '📻' },
  { id: 'window-box', name: 'Window box', color: '#79ac8c', w: 2, h: 1, kind: 'flowers', emoji: '🌼' },
].map(Object.freeze));
export const CAT = Object.freeze(Object.fromEntries(FURNITURE_CATALOG.map(item => [item.id, item])));
export const DISCOVERIES = Object.freeze([
  { id: 'pond-pebble', name: 'Skipping pebble', color: '#aab7ad', emoji: '🪨' },
  { id: 'pond-shell', name: 'Moon shell', color: '#e7cdbd', emoji: '🐚' },
  { id: 'pond-leaf', name: 'Heart leaf', color: '#8db589', emoji: '🍃' },
  { id: 'pond-feather', name: 'Soft feather', color: '#ced6e0', emoji: '🪶' },
  { id: 'pond-flower', name: 'Water flower', color: '#dfa9ba', emoji: '🌸' },
  { id: 'pond-glass', name: 'Sea glass', color: '#8cbbb2', emoji: '💎' },
].map(Object.freeze));
export const NPCS = Object.freeze([
  { id: 'oona', name: 'Oona', species: 'otter', x: 18, y: 11, color: '#aa805e', favorite: 'pond-shell', greeting: 'The pond always has a little surprise. Come sit a while.' },
  { id: 'pella', name: 'Pella', species: 'pigeon', x: 12, y: 8, color: '#939eb2', favorite: 'pond-feather', greeting: 'I found the nicest sunbeam. There is room for you, too.' },
  { id: 'boro', name: 'Boro', species: 'tapir', x: 9, y: 15, color: '#877e8b', favorite: 'pond-leaf', greeting: 'A picnic corner would be lovely. Three little pond finds should do it.' },
].map(Object.freeze));
export const ITEMS = Object.freeze({ ...CAT, ...Object.fromEntries(DISCOVERIES.map(item => [item.id, item])) });
const npcIds = NPCS.map(npc => npc.id);
const discoveryIds = new Set(DISCOVERIES.map(item => item.id));
const itemIds = new Set(Object.keys(ITEMS));
const PALETTE = /^#[0-9a-f]{6}$/i;
const MAX_ITEMS = 300;
const MAX_FURNITURE = 80;
export const MAX_SAVE_BYTES = 131072;
const clone = value => JSON.parse(JSON.stringify(value));
const ownKeys = (obj, keys) => obj !== null && typeof obj === 'object' && !Array.isArray(obj)
  && Object.keys(obj).length === keys.length && keys.every(key => Object.hasOwn(obj, key));
const boundedInt = (value, min, max) => Number.isInteger(value) && value >= min && value <= max;
const safeText = (value, max) => typeof value === 'string' && value.length <= max && !/[\u0000-\u001f\u007f]/u.test(value)
  && !/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(value);
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

export function createDefaultState(name = 'Guest', color = '#89cdb9') {
  let cleanName = typeof name === 'string' ? name.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 24) : 'Guest';
  if (/[\uD800-\uDBFF]$/.test(cleanName)) cleanName = cleanName.slice(0, -1);
  return {
    version: 1,
    player: { name: safeText(cleanName, 24) && cleanName ? cleanName : 'Guest', color: PALETTE.test(color) ? color : '#89cdb9', x: 13, y: 13, scene: 'town' },
    inventory: FURNITURE_CATALOG.map(item => item.id),
    furniture: [
      { id: 'f-1', type: 'tiny-bed', x: 2, y: 2, rotation: 0 },
      { id: 'f-2', type: 'round-table', x: 8, y: 3, rotation: 0 },
      { id: 'f-3', type: 'moss-chair', x: 8, y: 6, rotation: 0 },
      { id: 'f-4', type: 'fern-pot', x: 11, y: 2, rotation: 0 },
    ],
    collection: [], friendships: { oona: 0, pella: 0, boro: 0 },
    project: { donations: [] },
    progress: { talked: { oona: false, pella: false, boro: false }, pondVisits: 0, projectComplete: false },
  };
}

export function furnitureSize(type, rotation = 0) {
  const item = CAT[type];
  if (!item) return null;
  return rotation % 2 ? { w: item.h, h: item.w } : { w: item.w, h: item.h };
}
const overlaps = (a, b) => {
  const sa = furnitureSize(a.type, a.rotation), sb = furnitureSize(b.type, b.rotation);
  return a.x < b.x + sb.w && a.x + sa.w > b.x && a.y < b.y + sb.h && a.y + sa.h > b.y;
};
function validPlacement(row, furniture, ignoreId = null) {
  const size = furnitureSize(row.type, row.rotation);
  return !!size && boundedInt(row.x, 1, HOME.width - 2) && boundedInt(row.y, 1, HOME.height - 2)
    && row.x + size.w <= HOME.width - 1 && row.y + size.h <= HOME.height - 1
    && !(row.x <= HOME.exit.x && HOME.exit.x < row.x + size.w && row.y <= HOME.exit.y && HOME.exit.y < row.y + size.h)
    && !furniture.some(other => other.id !== ignoreId && overlaps(row, other));
}

function townCellBlocked(x, y) {
  const ix = Math.floor(x + 0.5), iy = Math.floor(y + 0.5), { pond, home } = TOWN;
  if (ix < 0 || iy < 0 || ix >= TOWN.width || iy >= TOWN.height) return true;
  return (ix >= pond.x && ix < pond.x + pond.w && iy >= pond.y && iy < pond.y + pond.h)
    || (ix >= home.x && ix < home.x + home.w && iy >= home.y && iy < home.y + home.h);
}
export function canWalk(state, x, y, scene = state?.player?.scene) {
  if (!Number.isFinite(x) || !Number.isFinite(y)) return false;
  const radius = 0.24;
  if (scene === 'town') {
    return x >= 0 && y >= 0 && x <= TOWN.width - 1 && y <= TOWN.height - 1
      && [[x-radius,y-radius],[x+radius,y-radius],[x-radius,y+radius],[x+radius,y+radius]].every(([px,py]) => !townCellBlocked(px,py));
  }
  if (scene !== 'home' || x < 1 || y < 1 || x > HOME.width - 2 || y > HOME.height - 2) return false;
  return !(state?.furniture ?? []).some(row => {
    const size = furnitureSize(row.type, row.rotation);
    return size && x + radius > row.x - 0.5 && x - radius < row.x + size.w - 0.5
      && y + radius > row.y - 0.5 && y - radius < row.y + size.h - 0.5;
  });
}

export function validateState(state) {
  try {
    if (!ownKeys(state, ['version','player','inventory','furniture','collection','friendships','project','progress']) || state.version !== 1) return false;
    if (!ownKeys(state.player, ['name','color','x','y','scene'])) return false;
    const player = state.player;
    if (!safeText(player.name, 24) || !player.name.trim() || !PALETTE.test(player.color) || typeof player.color !== 'string'
      || !['town','home'].includes(player.scene) || !Number.isFinite(player.x) || !Number.isFinite(player.y)) return false;
    if (!Array.isArray(state.inventory) || state.inventory.length > MAX_ITEMS || state.inventory.some(id => !itemIds.has(id))) return false;
    if (!Array.isArray(state.collection) || state.collection.length > DISCOVERIES.length || new Set(state.collection).size !== state.collection.length
      || state.collection.some(id => !discoveryIds.has(id))) return false;
    if (!Array.isArray(state.furniture) || state.furniture.length > MAX_FURNITURE || new Set(state.furniture.map(row => row.id)).size !== state.furniture.length) return false;
    for (const row of state.furniture) {
      if (!ownKeys(row, ['id','type','x','y','rotation']) || typeof row.id !== 'string' || !/^f-[A-Za-z0-9_-]{1,60}$/.test(row.id)
        || !Object.hasOwn(CAT, row.type) || !boundedInt(row.rotation, 0, 3) || !validPlacement(row, state.furniture, row.id)) return false;
    }
    if (!ownKeys(state.friendships, npcIds) || npcIds.some(id => !boundedInt(state.friendships[id], 0, 100))) return false;
    if (!ownKeys(state.project, ['donations']) || !Array.isArray(state.project.donations) || state.project.donations.length > PROJECT.required
      || new Set(state.project.donations).size !== state.project.donations.length || state.project.donations.some(id => !discoveryIds.has(id) || !state.collection.includes(id))) return false;
    if (!ownKeys(state.progress, ['talked','pondVisits','projectComplete']) || !ownKeys(state.progress.talked, npcIds)
      || npcIds.some(id => typeof state.progress.talked[id] !== 'boolean') || !boundedInt(state.progress.pondVisits, 0, 1000000)
      || state.progress.projectComplete !== (state.project.donations.length === PROJECT.required)) return false;
    if (state.inventory.some(id => discoveryIds.has(id) && !state.collection.includes(id))) return false;
    return canWalk(state, player.x, player.y) && new TextEncoder().encode(JSON.stringify(state)).length <= MAX_SAVE_BYTES;
  } catch { return false; }
}

const fail = (state, error) => ({ ok: false, state, error });
function change(state, action) {
  if (!validateState(state)) return fail(state, 'This local save cannot be read safely.');
  const next = clone(state);
  try {
    const extra = action(next) ?? {};
    if (!validateState(next)) return fail(state, 'That change would leave the world in an invalid state.');
    return { ok: true, state: next, ...extra };
  } catch (error) { return fail(state, error.message || 'That change could not be made.'); }
}
export function serializeState(state) {
  if (!validateState(state)) throw new Error('Cannot save invalid world data.');
  return JSON.stringify(state);
}
export function parseState(text) {
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > MAX_SAVE_BYTES) return { ok: false, state: null, error: 'The save is too large or is not text.' };
  try {
    const state = JSON.parse(text);
    return validateState(state) ? { ok: true, state } : { ok: false, state: null, error: 'The save has an unsupported version or invalid world data.' };
  } catch { return { ok: false, state: null, error: 'The save is not valid JSON.' }; }
}

export function movePlayer(state, dx, dy, dt) {
  if (!Number.isFinite(dx) || !Number.isFinite(dy) || !Number.isFinite(dt) || dt < 0 || dt > 0.25) return fail(state, 'Movement needs a short, valid frame time.');
  return change(state, next => {
    const length = Math.hypot(dx, dy);
    if (!length) return;
    const amount = 3 * dt, nx = dx / length * amount, ny = dy / length * amount;
    // Small substeps prevent crossing a wall even when a rendered frame is late.
    const steps = Math.max(1, Math.ceil(amount / 0.1));
    for (let i = 0; i < steps; i++) {
      if (canWalk(next, next.player.x + nx / steps, next.player.y)) next.player.x += nx / steps;
      if (canWalk(next, next.player.x, next.player.y + ny / steps)) next.player.y += ny / steps;
    }
  });
}
export function getNearby(state) {
  const p = state.player;
  if (p.scene === 'home') return { npcs: [], pond: false, door: false, exit: distance(p, HOME.exit) <= 1.5, project: false };
  const closestPond = { x: Math.max(TOWN.pond.x, Math.min(p.x, TOWN.pond.x + TOWN.pond.w - 1)), y: Math.max(TOWN.pond.y, Math.min(p.y, TOWN.pond.y + TOWN.pond.h - 1)) };
  return { npcs: NPCS.filter(npc => distance(p, npc) <= 1.7), pond: distance(p, closestPond) <= 1.8,
    door: distance(p, TOWN.home.door) <= 1.5, exit: false, project: distance(p, PROJECT) <= 1.8 };
}
export function enterHome(state) {
  if (state?.player?.scene !== 'town' || !getNearby(state).door) return fail(state, 'Walk to your front door first.');
  return change(state, next => { next.player = { ...next.player, ...HOME.spawn, scene: 'home' }; });
}
export function exitHome(state) {
  if (state?.player?.scene !== 'home' || !getNearby(state).exit) return fail(state, 'Walk to the bottom door first.');
  return change(state, next => { next.player = { ...next.player, ...TOWN.home.door, y: TOWN.home.door.y + 0.5, scene: 'town' }; });
}
function requireHome(next) { if (next.player.scene !== 'home') throw new Error('Arrange furniture inside your home.'); }
const findFurniture = (next, id) => {
  const row = next.furniture.find(item => item.id === id);
  if (!row) throw new Error('That furnishing is no longer here.');
  return row;
};
function takeItem(next, itemId) {
  const index = next.inventory.indexOf(itemId);
  if (index < 0) throw new Error('That item is not in your bag.');
  next.inventory.splice(index, 1);
}
export function placeFurniture(state, type, x, y) {
  return change(state, next => {
    requireHome(next);
    if (!Object.hasOwn(CAT, type)) throw new Error('Choose a furnishing from your bag.');
    if (next.furniture.length >= MAX_FURNITURE) throw new Error('There are already plenty of furnishings here.');
    let number = 1; while (next.furniture.some(item => item.id === `f-${number}`)) number++;
    const row = { id: `f-${number}`, type, x, y, rotation: 0 };
    if (!validPlacement(row, next.furniture)) throw new Error('Choose empty floor inside the room; keep the door clear.');
    takeItem(next, type); next.furniture.push(row);
    if (!canWalk(next, next.player.x, next.player.y)) throw new Error('Leave a little room around yourself.');
    return { furnitureId: row.id };
  });
}
export function moveFurniture(state, id, x, y) {
  return change(state, next => {
    requireHome(next); const row = findFurniture(next, id), proposed = { ...row, x, y };
    if (!validPlacement(proposed, next.furniture, id)) throw new Error('Choose empty floor inside the room; keep the door clear.');
    Object.assign(row, proposed);
    if (!canWalk(next, next.player.x, next.player.y)) throw new Error('Leave a little room around yourself.');
  });
}
export function rotateFurniture(state, id) {
  return change(state, next => {
    requireHome(next); const row = findFurniture(next, id), proposed = { ...row, rotation: (row.rotation + 1) % 4 };
    if (!validPlacement(proposed, next.furniture, id)) throw new Error('This furnishing needs a little more room to turn.');
    row.rotation = proposed.rotation;
    if (!canWalk(next, next.player.x, next.player.y)) throw new Error('Leave a little room around yourself.');
  });
}
export function removeFurniture(state, id) {
  return change(state, next => {
    requireHome(next); const row = findFurniture(next, id);
    if (next.inventory.length >= MAX_ITEMS) throw new Error('Your bag is full.');
    next.furniture = next.furniture.filter(item => item.id !== id); next.inventory.push(row.type);
  });
}
export function collectAtPond(state, rng = Math.random) {
  return change(state, next => {
    if (next.player.scene !== 'town' || !getNearby(next).pond) throw new Error('Stand beside the pond to look for a small find.');
    if (next.inventory.length >= MAX_ITEMS) throw new Error('Your bag is full. Make room before another pond find.');
    const roll = rng(); if (!Number.isFinite(roll) || roll < 0 || roll >= 1) throw new Error('The pond suggestion could not be made.');
    const item = DISCOVERIES[Math.floor(roll * DISCOVERIES.length)], isNew = !next.collection.includes(item.id);
    next.inventory.push(item.id); if (isNew) next.collection.push(item.id);
    next.progress.pondVisits = Math.min(1000000, next.progress.pondVisits + 1);
    return { item, isNew };
  });
}
export function talkTo(state, npcId) {
  return change(state, next => {
    const npc = getNearby(next).npcs.find(person => person.id === npcId);
    if (!npc) throw new Error('Walk a little closer to your neighbor.');
    const first = !next.progress.talked[npcId]; next.progress.talked[npcId] = true;
    if (first) next.friendships[npcId] = Math.min(100, next.friendships[npcId] + 1);
    return { npc, text: npc.greeting, first };
  });
}
export function giveGift(state, npcId, itemId) {
  return change(state, next => {
    const npc = getNearby(next).npcs.find(person => person.id === npcId);
    if (!npc) throw new Error('Walk a little closer to your neighbor.');
    if (!itemIds.has(itemId)) throw new Error('Choose something from your bag.');
    takeItem(next, itemId); next.friendships[npcId] = Math.min(100, next.friendships[npcId] + (npc.favorite === itemId ? 2 : 1));
    return { npc, item: ITEMS[itemId], text: `Thank you! ${ITEMS[itemId].name} is a lovely thought.` };
  });
}
export function donateProject(state, itemId) {
  return change(state, next => {
    if (next.player.scene !== 'town' || !getNearby(next).project) throw new Error('Visit the picnic corner to contribute.');
    if (next.progress.projectComplete) throw new Error('The picnic corner is ready for everyone.');
    if (!discoveryIds.has(itemId)) throw new Error('The picnic corner needs three different pond finds.');
    if (next.project.donations.includes(itemId)) throw new Error('That find already has a place here. Choose another kind.');
    takeItem(next, itemId); next.project.donations.push(itemId);
    next.progress.projectComplete = next.project.donations.length === PROJECT.required;
    return { completed: next.progress.projectComplete, item: ITEMS[itemId] };
  });
}
