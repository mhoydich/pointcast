import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=name=>fs.readFileSync(path.join(root,name),'utf8');
function wrap(file,globalName){let code=read(file);const names=[...code.matchAll(/^export (?:const|function|class) (\w+)/gm)].map(x=>x[1]);code=code.replace(/^export /gm,'');code=code.replace(/^import \{([^}]+)\} from '\.\/core\.mjs';/m,'const {$1}=window.MossbellCore;');return `window.${globalName}=(()=>{\n${code}\nreturn {${names.join(',')}};})();`;}
const data='data:image/png;base64,'+fs.readFileSync(path.join(root,'assets/atlas.png')).toString('base64');
let app=read('app.mjs').replace(/^import \* as C from '\.\/core\.mjs';/m,'const C=window.MossbellCore;').replace(/^import \{PeerVisit\} from '\.\/peer\.mjs';/m,'const {PeerVisit}=window.MossbellPeer;').replace(/^import \{createRenderer\} from '\.\/render\.mjs';/m,'const {createRenderer}=window.MossbellRender;').replace("atlasUrl:'./assets/atlas.png'",'atlasUrl:'+JSON.stringify(data));
const js=[wrap('core.mjs','MossbellCore'),wrap('peer.mjs','MossbellPeer'),wrap('render.mjs','MossbellRender'),'(()=>{\n'+app+'\n})();'].join('\n');
const html=read('index.html').replace('<link rel="stylesheet" href="style.css">','<style>'+read('style.css')+'</style>').replace('<script type="module" src="app.mjs"></script>','<script>\n'+js.replace(/<\/script/gi,'<\\/script')+'\n</script>');
fs.mkdirSync(path.join(root,'dist'),{recursive:true});
fs.writeFileSync(path.join(root,'dist/index.html'),html);
fs.writeFileSync(path.join(root,'Mossbell.html'),html);
fs.writeFileSync(path.join(root,'test/bundle-check.js'),js);
console.log('Built a self-contained game: '+Buffer.byteLength(html)+' bytes.');
