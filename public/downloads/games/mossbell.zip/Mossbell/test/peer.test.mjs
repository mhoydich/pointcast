import test from 'node:test';
import assert from 'node:assert/strict';
import { PeerVisit, encodeSignal, decodeSignal, validateSignal, validateMessage, decodeMessage, SIGNAL_LIMIT, MESSAGE_LIMIT, MESSAGE_TYPES, BUFFER_LIMIT } from '../peer.mjs';

const sdp = 'v=0\r\no=- 123 1 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\nm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\na=sctp-port:5000\r\n';
const offer = () => ({ v: 1, kind: 'offer', session: 'a-safe-session-123456', sdp, type: 'offer' });
const raw = value => Buffer.from(JSON.stringify(value)).toString('base64url');

test('manual invitation and reply codes roundtrip and bind the host session', () => {
  const value = offer(), token = encodeSignal(value);
  assert.match(token, /^[A-Za-z0-9_-]+$/);
  assert.deepEqual(decodeSignal(`\n${token}\n`, 'offer'), value);
  const answer = { ...value, kind: 'answer', type: 'answer' };
  assert.deepEqual(decodeSignal(encodeSignal(answer), 'answer', value.session), answer);
  assert.throws(() => decodeSignal(encodeSignal(answer), 'answer', 'another-safe-session'), /different invitation/);
  assert.throws(() => decodeSignal(token, 'answer'), /guest’s reply/);
});

test('version, kind, session, type and exact token envelope are validated', () => {
  for (const patch of [{ v: 2 }, { kind: 'bogus' }, { type: 'answer' }, { session: 'short' }, { session: 'a'.repeat(65) }, { session: 'contains spaces here' }, { extra: 'payload' }, { sdp: null }]) {
    assert.throws(() => decodeSignal(raw({ ...offer(), ...patch })));
  }
  for (const value of [null, [], 'code', 42, { ...offer(), v: undefined }]) assert.throws(() => decodeSignal(raw(value)));
});

test('malformed, padded, noncanonical, invalid UTF-8 and oversized codes fail closed', () => {
  for (const code of ['', 'a', '!!', 'e30=', 'e 30', '_w', 'Zh', 'a'.repeat(Math.ceil(SIGNAL_LIMIT * 4 / 3) + 17)]) assert.throws(() => decodeSignal(code));
  assert.throws(() => decodeSignal(123));
  assert.throws(() => decodeSignal(Buffer.alloc(SIGNAL_LIMIT + 1, 32).toString('base64url')));
});

test('signaling accepts only one data section and bounded ASCII SDP', () => {
  for (const bad of ['not SDP at all', sdp.replace('v=0', 'v=1'), sdp.replace('m=application', 'm=audio'), sdp + 'm=video 9 UDP/TLS/RTP/SAVPF 96\r\n', sdp + 'm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\n', sdp + '\u0000', sdp + '💚', sdp + 'a=x:' + 'z'.repeat(SIGNAL_LIMIT)]) {
    assert.throws(() => validateSignal({ ...offer(), sdp: bad }));
  }
});

test('all game message types are accepted; wrong versions and invalid top levels are rejected', () => {
  for (const type of MESSAGE_TYPES) assert.deepEqual(decodeMessage(JSON.stringify({ v: 1, type, payload: { chosen: 'only explicit game words' } })), { v: 1, type, payload: { chosen: 'only explicit game words' } });
  for (const value of [null, [], 42, 'message', {}, { v: 2, type: 'move' }, { v: 1, type: 'unknown' }, { v: 1, type: ['chat'] }, Object.create({ v: 1, type: 'hello' })]) assert.equal(validateMessage(value), false);
  for (const text of ['not JSON', 'null', '[]', '{"v":1,"type":"chat","__proto__":{}}']) assert.throws(() => decodeMessage(text));
});

test('message bounds count UTF-8 bytes and reject binary input', () => {
  const prefix = '{"v":1,"type":"chat","text":"', suffix = '"}';
  const exact = prefix + 'a'.repeat(MESSAGE_LIMIT - prefix.length - suffix.length) + suffix;
  assert.equal(Buffer.byteLength(exact), MESSAGE_LIMIT);
  assert.equal(decodeMessage(exact).type, 'chat');
  assert.throws(() => decodeMessage(exact + ' '));
  assert.throws(() => decodeMessage(JSON.stringify({ v: 1, type: 'chat', text: '💚'.repeat(MESSAGE_LIMIT / 3) })));
  assert.throws(() => decodeMessage(new Uint8Array([1, 2])));
});

// Transport lifecycle unit doubles exercise cancellation and guards, not connectivity.
class FakeRTC extends EventTarget {
  static instances = [];
  static gathering = false;
  constructor(configuration) {
    super(); this.configuration = configuration; this.iceGatheringState = FakeRTC.gathering ? 'gathering' : 'complete';
    this.connectionState = 'new'; this.iceConnectionState = 'new'; this.closeCount = 0;
    FakeRTC.instances.push(this);
  }
  createDataChannel(label, options) {
    this.channel = {
      label, ordered: options.ordered, maxRetransmits: null, maxPacketLifeTime: null,
      readyState: 'connecting', bufferedAmount: 0, sent: [],
      send(text) { this.sent.push(text); }, close() { this.readyState = 'closed'; },
    };
    return this.channel;
  }
  async createOffer() { return { type: 'offer', sdp }; }
  async createAnswer() { return { type: 'answer', sdp }; }
  async setLocalDescription(description) { this.localDescription = description; }
  async setRemoteDescription(description) { this.remoteDescription = description; }
  close() { this.closeCount++; this.connectionState = 'closed'; }
}

async function withRTC(run) {
  const previous = globalThis.RTCPeerConnection;
  FakeRTC.instances = []; FakeRTC.gathering = false;
  globalThis.RTCPeerConnection = FakeRTC;
  try { await run(); } finally {
    if (previous === undefined) delete globalThis.RTCPeerConnection;
    else globalThis.RTCPeerConnection = previous;
    FakeRTC.gathering = false;
  }
}

test('closing during ICE gathering cancels old work without contaminating the next session', async () => {
  await withRTC(async () => {
    FakeRTC.gathering = true;
    const closes = [], visit = new PeerVisit({ iceServers: [], onClose: event => closes.push(event) });
    const old = visit.host();
    const rejection = assert.rejects(old, /cancelled/);
    await new Promise(resolve => setImmediate(resolve));
    const first = FakeRTC.instances[0];
    visit.close();
    FakeRTC.gathering = false;
    const code = await visit.host();
    await rejection;
    assert.equal(first.closeCount, 1);
    assert.equal(first.channel.onmessage, null);
    assert.equal(decodeSignal(code).kind, 'offer');
    assert.equal(visit.role, 'host');
    assert.equal(visit.diagnostics.state, 'awaiting-reply');
    assert.equal(visit.diagnostics.discovery, 'local-only');
    assert.equal(closes.length, 1);
    visit.close(); assert.equal(closes.length, 2);
  });
});

test('a mismatched reply preserves the invitation and only one matching answer is accepted', async () => {
  await withRTC(async () => {
    const visit = new PeerVisit({ iceServers: [] });
    const invitation = decodeSignal(await visit.host());
    const answer = { ...invitation, kind: 'answer', type: 'answer' };
    await assert.rejects(visit.accept(encodeSignal({ ...answer, session: 'another-valid-session' })), /different invitation/);
    assert.equal(visit.diagnostics.state, 'awaiting-reply');
    await visit.accept(encodeSignal(answer));
    assert.equal(FakeRTC.instances[0].remoteDescription.type, 'answer');
    await assert.rejects(visit.accept(encodeSignal(answer)));
    assert.equal(visit.role, 'host');
    visit.close();
  });
});

test('channel lifecycle enforces backpressure and rejects malformed incoming messages', async () => {
  await withRTC(async () => {
    const received = [], closes = [], opens = [];
    const visit = new PeerVisit({ iceServers: [], onMessage: message => received.push(message), onClose: event => closes.push(event), onOpen: event => opens.push(event) });
    await visit.host();
    const channel = FakeRTC.instances[0].channel;
    assert.equal(visit.send({ v: 1, type: 'chat', text: 'hello' }), false);
    channel.readyState = 'open'; channel.onopen(); channel.onopen();
    assert.equal(opens.length, 1);
    channel.bufferedAmount = BUFFER_LIMIT;
    assert.equal(visit.send({ v: 1, type: 'chat', text: 'hello' }), false);
    channel.bufferedAmount = 0;
    assert.equal(visit.send({ v: 1, type: 'chat', text: 'hello' }), true);
    assert.equal(visit.send({ v: 2, type: 'chat' }), false);
    assert.equal(visit.send({ v: 1, type: 'chat', text: 'z'.repeat(MESSAGE_LIMIT) }), false);
    assert.equal(channel.sent.length, 1);
    channel.onmessage({ data: '{"v":1,"type":"move","dx":1,"dy":0}' });
    assert.equal(received.length, 1);
    channel.onmessage({ data: '{"v":1,"type":"unknown"}' });
    assert.equal(visit.connected, false);
    assert.equal(visit.diagnostics.state, 'error');
    assert.equal(closes.length, 1);
    assert.equal(channel.onmessage, null);
    visit.close(); assert.equal(closes.length, 1);
  });
});
