import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createDefaultState, validateState, parseState, serializeState, canWalk, movePlayer,
  enterHome, exitHome, placeFurniture, moveFurniture, rotateFurniture, removeFurniture,
  collectAtPond, giveGift, donateProject, talkTo, getNearby, CAT, DISCOVERIES, NPCS,
} from '../core.mjs';
const at = (state, x, y, scene = 'town') => ({ ...structuredClone(state), player: { ...state.player, x, y, scene } });
const nearPond = () => at(createDefaultState(), 18, 7);
const interior = () => enterHome(at(createDefaultState(), 6, 8)).state;

test('default save has twelve bag furnishings, four placed items, and independent nested state', () => {
  const a = createDefaultState(), b = createDefaultState();
  assert.equal(validateState(a), true); assert.equal(a.inventory.length, 12); assert.equal(a.furniture.length, 4);
  a.inventory.pop(); a.progress.talked.oona = true;
  assert.equal(b.inventory.length, 12); assert.equal(b.progress.talked.oona, false);
  assert.deepEqual(parseState(serializeState(b)).state, b);
  assert.equal(createDefaultState('a'.repeat(23)+'🐈').player.name,'a'.repeat(23));
});
test('malformed and future imports are refused without an automatic reset', () => {
  for (const text of ['null','{}','{','[]',JSON.stringify({ ...createDefaultState(), version: 2 })]) assert.equal(parseState(text).ok, false);
  const patches = [ { inventory: ['secret-item'] }, { collection: ['pond-shell','pond-shell'] }, { inventory: Array(301).fill('fern-pot') }, { friendships: {oona:Infinity,pella:0,boro:0} }, { player: { name:'Me',color:'url(x)',x:13,y:13,scene:'town' } } ];
  for (const patch of patches) assert.equal(validateState({ ...createDefaultState(), ...patch }), false);
  const embedded = createDefaultState(); embedded.furniture.push({ ...embedded.furniture[0], id: 'f-99' }); assert.equal(validateState(embedded), false);
  const wall = at(createDefaultState(), 21, 7); assert.equal(validateState(wall), false);
  const fabricated = createDefaultState(); fabricated.progress.projectComplete = true; assert.equal(validateState(fabricated), false);
});
test('town movement blocks pond, house, and map edge; diagonal movement is normalized', () => {
  const s = nearPond(), before = structuredClone(s);
  assert.equal(canWalk(s, 21, 5), false); assert.equal(canWalk(s, 5, 4), false); assert.equal(canWalk(s, -1, 13), false);
  let cursor = s; for (let i = 0; i < 20; i++) cursor = movePlayer(cursor, 1, 0, 0.1).state;
  assert.ok(cursor.player.x < 18.5); assert.equal(validateState(cursor), true); assert.deepEqual(s, before);
  const start = createDefaultState(), moved = movePlayer(start, 1, 1, 0.1).state;
  assert.ok(Math.abs(Math.hypot(moved.player.x-start.player.x,moved.player.y-start.player.y)-0.3)<1e-10);
  assert.equal(movePlayer(start, 1, 0, Infinity).ok, false); assert.equal(movePlayer(start, 1, 0, 1).ok, false);
});
test('home transitions require the correct nearby door and keep the floor walkable', () => {
  assert.equal(enterHome(createDefaultState()).ok, false);
  const entered = enterHome(at(createDefaultState(), 6, 8)); assert.equal(entered.ok, true); assert.equal(entered.state.player.scene,'home');
  assert.equal(getNearby(entered.state).exit,true); assert.equal(exitHome(entered.state).state.player.scene,'town');
  assert.equal(exitHome(at(entered.state, 5, 8,'home')).ok,false);
  assert.equal(canWalk(entered.state,2,2),false); assert.equal(canWalk(entered.state,0,7),false);
});
test('placement, moving, rotation, and removal preserve inventory and refuse overlap', () => {
  const start = interior(), before = structuredClone(start);
  assert.equal(placeFurniture(start,'fern-pot',2,2).ok,false);
  assert.equal(placeFurniture(start,'fern-pot',7,10).ok,false);
  assert.equal(placeFurniture(start,'fern-pot',0,8).ok,false);
  assert.equal(placeFurniture(start,'fern-pot',6.5,8).ok,false);
  const placed = placeFurniture(start,'cloud-sofa',4,6); assert.equal(placed.ok,true); assert.equal(placed.state.inventory.length,start.inventory.length-1);
  assert.equal(moveFurniture(placed.state,placed.furnitureId,2,2).ok,false);
  const rotated = rotateFurniture(placed.state,placed.furnitureId); assert.equal(rotated.ok,true); assert.equal(rotated.state.furniture.at(-1).rotation,1);
  const removed = removeFurniture(rotated.state,placed.furnitureId); assert.equal(removed.ok,true); assert.equal(removed.state.inventory.length,start.inventory.length);
  assert.deepEqual(start,before); assert.equal(validateState(removed.state),true);
});
test('pond finds use controlled random values, retain distinct collection, and do not mutate input', () => {
  const s=nearPond(),before=structuredClone(s);
  const first=collectAtPond(s,()=>0),again=collectAtPond(first.state,()=>0);
  assert.equal(first.ok,true);assert.equal(first.item.id,DISCOVERIES[0].id);assert.equal(first.isNew,true);assert.equal(again.isNew,false);
  assert.equal(again.state.collection.length,1);assert.equal(again.state.inventory.filter(id=>id===first.item.id).length,2);assert.deepEqual(s,before);
  for(const value of [NaN,Infinity,-0.1,1])assert.equal(collectAtPond(s,()=>value).ok,false);
  assert.equal(collectAtPond(createDefaultState(),()=>0).ok,false);
});
test('gifts consume exactly one owned item, reward the selected neighbor, and keep collection', () => {
  const found=collectAtPond(nearPond(),()=>1/6).state,near=at(found,17,11),before=structuredClone(near);
  const gift=giveGift(near,'oona','pond-shell');assert.equal(gift.ok,true);assert.equal(gift.state.friendships.oona,2);
  assert.equal(gift.state.inventory.includes('pond-shell'),false);assert.equal(gift.state.collection.includes('pond-shell'),true);
  assert.equal(giveGift(gift.state,'oona','pond-shell').ok,false);assert.equal(giveGift(near,'pella','pond-shell').ok,false);assert.deepEqual(near,before);
  const talk=talkTo(near,'oona');assert.equal(talk.state.friendships.oona,1);assert.equal(talkTo(talk.state,'oona').state.friendships.oona,1);
});
test('three distinct donations consume once and complete the shared town project', () => {
  let state=nearPond();for(const roll of [0,1/6,2/6])state=collectAtPond(state,()=>roll).state;
  state=at(state,14,14);const first=donateProject(state,DISCOVERIES[0].id);assert.equal(first.ok,true);
  assert.equal(first.state.inventory.length,state.inventory.length-1);assert.equal(first.completed,false);
  assert.equal(donateProject(first.state,DISCOVERIES[0].id).ok,false);
  const second=donateProject(first.state,DISCOVERIES[1].id),third=donateProject(second.state,DISCOVERIES[2].id);
  assert.equal(third.completed,true);assert.equal(third.state.project.donations.length,3);assert.equal(third.state.progress.projectComplete,true);
  assert.equal(donateProject(third.state,DISCOVERIES[3].id).ok,false);assert.equal(donateProject(state,Object.keys(CAT)[0]).ok,false);
  assert.equal(validateState(third.state),true);assert.equal(NPCS.length,3);
});
