// Manual WebRTC signaling. Only explicit game messages cross this connection.
export const SIGNAL_LIMIT = 80 * 1024;
export const MESSAGE_LIMIT = 48 * 1024;
export const BUFFER_LIMIT = 256 * 1024;
export const MESSAGE_TYPES = Object.freeze(['hello', 'welcome', 'move', 'world', 'action', 'chat', 'bye', 'error']);
export const DEFAULT_ICE_SERVERS = Object.freeze([Object.freeze({ urls: 'stun:stun.l.google.com:19302' })]);
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const signalKeys = ['v', 'kind', 'session', 'sdp', 'type'];
const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value)
  && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);

function bytesToBase64(bytes) {
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 8192) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function validateSignal(value, expectedKind, expectedSession) {
  if (!isRecord(value) || Object.keys(value).length !== signalKeys.length
      || signalKeys.some(key => !Object.hasOwn(value, key))) throw new Error('This is not a Mossbell invitation or reply.');
  if (value.v !== 1) throw new Error('This visit code uses an unsupported version.');
  if (!['offer', 'answer'].includes(value.kind) || value.type !== value.kind) throw new Error('The visit code has an invalid signaling type.');
  if (expectedKind && value.kind !== expectedKind) throw new Error(expectedKind === 'offer' ? 'Paste the host’s invitation code here.' : 'Paste the guest’s reply code here.');
  if (typeof value.session !== 'string' || !/^[A-Za-z0-9_-]{16,64}$/.test(value.session)) throw new Error('The visit code has an invalid session.');
  if (expectedSession && value.session !== expectedSession) throw new Error('That reply belongs to a different invitation. Create a new visit or use the matching reply.');
  if (typeof value.sdp !== 'string' || value.sdp.length < 20 || value.sdp.length > SIGNAL_LIMIT
      || !/^v=0(?:\r?\n)/.test(value.sdp) || !/^[\t\r\n\x20-\x7e]+$/.test(value.sdp)) throw new Error('The visit code has an invalid connection description.');
  const media = value.sdp.split(/\r?\n/).filter(line => line.startsWith('m='));
  if (media.length !== 1 || !media[0].startsWith('m=application ')) throw new Error('Mossbell visit codes must contain a single data connection.');
  if (encoder.encode(JSON.stringify(value)).byteLength > SIGNAL_LIMIT) throw new Error('This visit code is too large.');
  return value;
}

export function encodeSignal(value) {
  validateSignal(value);
  return bytesToBase64(encoder.encode(JSON.stringify(value)));
}

export function decodeSignal(code, expectedKind, expectedSession) {
  if (typeof code !== 'string') throw new Error('Paste a Mossbell visit code.');
  if (code.length > Math.ceil(SIGNAL_LIMIT * 4 / 3) + 16) throw new Error('This visit code is too large.');
  const trimmed = code.trim();
  if (!trimmed || !/^[A-Za-z0-9_-]+$/.test(trimmed) || trimmed.length % 4 === 1) throw new Error('The visit code is incomplete or malformed.');
  let bytes, value;
  try {
    const padded = trimmed.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - trimmed.length % 4) % 4);
    const binary = atob(padded);
    bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
    if (bytes.byteLength > SIGNAL_LIMIT) throw new Error('oversized');
    if (bytesToBase64(bytes) !== trimmed) throw new Error('noncanonical');
    value = JSON.parse(decoder.decode(bytes));
  } catch {
    throw new Error('The visit code is incomplete, malformed, or too large.');
  }
  return validateSignal(value, expectedKind, expectedSession);
}

export function validateMessage(value) {
  return isRecord(value) && Object.hasOwn(value, 'v') && value.v === 1
    && Object.hasOwn(value, 'type') && MESSAGE_TYPES.includes(value.type)
    && !Object.hasOwn(value, '__proto__') && !Object.hasOwn(value, 'constructor') && !Object.hasOwn(value, 'prototype');
}

export function decodeMessage(text) {
  if (typeof text !== 'string' || text.length > MESSAGE_LIMIT
      || encoder.encode(text).byteLength > MESSAGE_LIMIT) throw new Error('The visit sent an oversized or non-text message.');
  let value;
  try { value = JSON.parse(text); } catch { throw new Error('The visit sent an invalid message.'); }
  if (!validateMessage(value)) throw new Error('The visit sent an unsupported message.');
  return value;
}

function normalizeServers(servers) {
  if (!Array.isArray(servers) || servers.length > 4) throw new Error('Choose a list of STUN servers, or [] for local discovery only.');
  return servers.map(server => {
    if (!isRecord(server)) throw new Error('Invalid STUN server configuration.');
    const urls = Array.isArray(server.urls) ? server.urls : [server.urls];
    if (!urls.length || urls.length > 4 || urls.some(url => typeof url !== 'string' || url.length > 256 || !/^stuns?:[^\s]+$/.test(url))) {
      throw new Error('Mossbell supports STUN discovery only; it does not use a TURN relay.');
    }
    return { urls: [...urls] };
  });
}

function nonce() {
  if (!globalThis.crypto?.getRandomValues) throw new Error('Secure browser randomness is unavailable. Open Mossbell in a current browser.');
  return bytesToBase64(globalThis.crypto.getRandomValues(new Uint8Array(24)));
}

export class PeerVisit {
  constructor({ onState, onMessage, onOpen, onClose, iceServers = DEFAULT_ICE_SERVERS } = {}) {
    this._callbacks = { onState, onMessage, onOpen, onClose };
    this._servers = normalizeServers(iceServers);
    this._generation = 0;
    this._pc = null;
    this._channel = null;
    this._role = null;
    this._session = null;
    this._state = 'idle';
    this._message = '';
    this._gatheringTimedOut = false;
    this._cancelGather = null;
    this._disconnectTimer = null;
    this._accepted = false;
    this._openNotified = false;
  }

  get role() { return this._role; }
  get connected() { return this._channel?.readyState === 'open' && !!this._pc; }
  get diagnostics() {
    return {
      state: this._state, role: this.role, connected: this.connected, message: this._message,
      connectionState: this._pc?.connectionState ?? 'closed',
      iceConnectionState: this._pc?.iceConnectionState ?? 'closed',
      iceGatheringState: this._pc?.iceGatheringState ?? 'new',
      gatheringTimedOut: this._gatheringTimedOut,
      discovery: this._servers.length ? 'stun' : 'local-only',
      bufferedAmount: this._channel?.bufferedAmount ?? 0,
    };
  }

  _call(name, value) {
    // An application callback cannot leave the transport half-cleaned up.
    try { this._callbacks[name]?.(value); } catch { /* No user payload is logged. */ }
  }

  _setState(state, message = '') {
    this._state = state;
    this._message = message;
    this._call('onState', this.diagnostics);
  }

  _current(pc, generation) { return this._pc === pc && this._generation === generation; }
  _assertCurrent(pc, generation) {
    if (!this._current(pc, generation)) throw new Error('Visit setup was cancelled.');
  }

  _start(role, session) {
    if (typeof globalThis.RTCPeerConnection !== 'function') throw new Error('WebRTC is unavailable. Open Mossbell in a current browser with WebRTC enabled.');
    if (this._pc) this._finish('A new visit was started.', 'closed');
    const pc = new globalThis.RTCPeerConnection({ iceServers: this._servers });
    const generation = ++this._generation;
    this._pc = pc;
    this._role = role;
    this._session = session;
    this._accepted = false;
    this._openNotified = false;
    this._gatheringTimedOut = false;
    const update = () => {
      if (!this._current(pc, generation)) return;
      const connection = pc.connectionState, ice = pc.iceConnectionState;
      if (connection === 'failed' || ice === 'failed') {
        this._finish('The visit could not connect. Some networks need a relay server; Mossbell has no relay.', 'error');
      } else if (connection === 'closed' || ice === 'closed') {
        this._finish('The visit connection closed.', 'closed');
      } else if (connection === 'disconnected' || ice === 'disconnected') {
        this._setState('disconnected', 'The connection was interrupted. Waiting briefly for it to return.');
        if (!this._disconnectTimer) this._disconnectTimer = setTimeout(() => {
          if (this._current(pc, generation)) this._finish('The visit disconnected. Start a new invitation to reconnect.', 'closed');
        }, 15000);
      } else {
        clearTimeout(this._disconnectTimer); this._disconnectTimer = null;
        if (this.connected) this._setState('connected', 'Your visitor is connected.');
        else this._call('onState', this.diagnostics);
      }
    };
    pc.onconnectionstatechange = update;
    pc.oniceconnectionstatechange = update;
    pc.ondatachannel = event => {
      if (!this._current(pc, generation) || role !== 'guest' || this._channel) { event.channel.close(); return; }
      this._bindChannel(event.channel, pc, generation);
    };
    this._setState('gathering', 'Preparing a visit code. This can take up to eight seconds.');
    return { pc, generation };
  }

  _bindChannel(channel, pc, generation) {
    if (channel.label !== 'mossbell' || channel.ordered !== true
        || channel.maxRetransmits != null || channel.maxPacketLifeTime != null) {
      channel.close();
      this._finish('The visitor offered an unsupported data connection.', 'error');
      return;
    }
    this._channel = channel;
    channel.onopen = () => {
      if (!this._current(pc, generation) || this._channel !== channel) return;
      clearTimeout(this._disconnectTimer); this._disconnectTimer = null;
      this._setState('connected', 'Your visitor is connected.');
      if (!this._openNotified) { this._openNotified = true; this._call('onOpen', { role: this.role }); }
    };
    channel.onmessage = event => {
      if (!this._current(pc, generation) || this._channel !== channel) return;
      let message;
      try { message = decodeMessage(event.data); }
      catch (error) { this._finish(error.message, 'error'); return; }
      this._call('onMessage', message);
    };
    channel.onclose = () => {
      if (this._current(pc, generation) && this._channel === channel) this._finish('Your visitor left the visit.', 'closed');
    };
    channel.onerror = () => {
      if (this._current(pc, generation)) this._finish('The visit data connection failed. Create a new invitation to retry.', 'error');
    };
  }

  async _gather(pc, generation) {
    this._assertCurrent(pc, generation);
    if (pc.iceGatheringState === 'complete') return;
    await new Promise((resolve, reject) => {
      let timer, settled = false;
      const cleanup = () => {
        clearTimeout(timer);
        pc.removeEventListener('icegatheringstatechange', changed);
        pc.removeEventListener('icecandidate', candidate);
        if (this._cancelGather === cancel) this._cancelGather = null;
      };
      const finish = timedOut => {
        if (settled) return;
        settled = true; cleanup();
        if (!this._current(pc, generation)) { reject(new Error('Visit setup was cancelled.')); return; }
        this._gatheringTimedOut = timedOut;
        resolve();
      };
      const changed = () => { if (pc.iceGatheringState === 'complete') finish(false); };
      const candidate = event => { if (!event.candidate) finish(false); };
      const cancel = () => {
        if (settled) return;
        settled = true; cleanup(); reject(new Error('Visit setup was cancelled.'));
      };
      this._cancelGather = cancel;
      pc.addEventListener('icegatheringstatechange', changed);
      pc.addEventListener('icecandidate', candidate);
      timer = setTimeout(() => finish(true), 8000);
      changed();
    });
    this._assertCurrent(pc, generation);
  }

  _signal(pc, kind) {
    const description = pc.localDescription;
    if (!description || description.type !== kind) throw new Error('The browser did not create a connection description.');
    return encodeSignal({ v: 1, kind, session: this._session, sdp: description.sdp, type: kind });
  }

  async host() {
    const { pc, generation } = this._start('host', nonce());
    try {
      this._bindChannel(pc.createDataChannel('mossbell', { ordered: true, protocol: 'mossbell-v1' }), pc, generation);
      const offer = await pc.createOffer(); this._assertCurrent(pc, generation);
      await pc.setLocalDescription(offer); this._assertCurrent(pc, generation);
      await this._gather(pc, generation);
      const invite = this._signal(pc, 'offer');
      this._setState('awaiting-reply', this._gatheringTimedOut ? 'Invitation ready with the addresses gathered so far. Exchange codes promptly.' : 'Invitation ready. Send it to one guest, then paste their reply.');
      return invite;
    } catch (error) { if (this._current(pc, generation)) this._finish(`Could not prepare the invitation: ${error.message}`, 'error'); throw error; }
  }

  async join(inviteString) {
    const invite = decodeSignal(inviteString, 'offer');
    const { pc, generation } = this._start('guest', invite.session);
    try {
      await pc.setRemoteDescription({ type: 'offer', sdp: invite.sdp }); this._assertCurrent(pc, generation);
      const answer = await pc.createAnswer(); this._assertCurrent(pc, generation);
      await pc.setLocalDescription(answer); this._assertCurrent(pc, generation);
      await this._gather(pc, generation);
      const reply = this._signal(pc, 'answer');
      this._setState('awaiting-host', this._gatheringTimedOut ? 'Reply ready with the addresses gathered so far. Send it to your host promptly.' : 'Reply ready. Send it to the host so they can connect you.');
      return reply;
    } catch (error) { if (this._current(pc, generation)) this._finish(`Could not join this visit: ${error.message}`, 'error'); throw error; }
  }

  async accept(replyString) {
    if (this.role !== 'host' || !this._pc || this._state !== 'awaiting-reply') throw new Error('Create an invitation before accepting a guest’s reply.');
    if (this._accepted) throw new Error('This invitation already has a guest. Create a new visit to invite someone else.');
    const reply = decodeSignal(replyString, 'answer', this._session);
    const pc = this._pc, generation = this._generation;
    this._accepted = true;
    this._setState('connecting', 'Connecting your guest. Some networks cannot make a direct visit.');
    try {
      await pc.setRemoteDescription({ type: 'answer', sdp: reply.sdp });
      this._assertCurrent(pc, generation);
    } catch (error) { if (this._current(pc, generation)) this._finish(`Could not accept the reply: ${error.message}`, 'error'); throw error; }
  }

  send(message) {
    const channel = this._channel;
    if (!this.connected || !validateMessage(message)) return false;
    let text;
    try { text = JSON.stringify(message); decodeMessage(text); } catch { return false; }
    const length = encoder.encode(text).byteLength;
    if (channel.bufferedAmount + length > BUFFER_LIMIT) return false;
    try { channel.send(text); return true; } catch { return false; }
  }

  _finish(reason, state) {
    const pc = this._pc, channel = this._channel, role = this._role;
    ++this._generation;
    this._pc = null; this._channel = null; this._role = null; this._session = null;
    clearTimeout(this._disconnectTimer); this._disconnectTimer = null;
    const cancel = this._cancelGather; this._cancelGather = null; cancel?.();
    if (channel) { channel.onopen = channel.onmessage = channel.onclose = channel.onerror = null; try { channel.close(); } catch {} }
    if (pc) { pc.onconnectionstatechange = pc.oniceconnectionstatechange = pc.ondatachannel = null; try { pc.close(); } catch {} }
    this._setState(state, reason);
    if (pc) this._call('onClose', { reason, role });
  }

  close() { this._finish('The visit is closed.', 'closed'); }
}
