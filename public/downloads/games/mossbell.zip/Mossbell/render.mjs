import { CAT, NPCS, TOWN, HOME, PROJECT, TILE_SIZE, furnitureSize } from './core.mjs';

const S = TILE_SIZE;
const ATLAS_NAMES = ['oona', 'pella', 'boro', 'player', 'house', 'bakery', 'workshop', 'tree', 'flowers', 'bench', 'picnic', 'whale'];
const ATLAS_ROWS = [[0, 365], [365, 710], [710, 1024]];
const DEFAULT_CROPS = [
  [81, 56, 240, 298], [443, 49, 265, 305], [821, 48, 241, 306], [1238, 52, 236, 302],
  [35, 377, 321, 320], [419, 383, 329, 309], [784, 391, 343, 304], [1188, 384, 304, 316],
  [49, 772, 295, 191], [440, 772, 275, 191], [796, 780, 325, 192], [1179, 713, 348, 280],
];
const FURNITURE_ART = {
  'fern-pot': 'flowers', 'round-table': 'picnic', 'moss-chair': 'bench',
  'cloud-sofa': 'bench', 'window-box': 'flowers',
};
const TREE_POSITIONS = [[1, 2], [4, 1], [11, 1], [16, 1], [27, 2], [1, 9], [27, 13], [1, 18], [4, 20], [10, 21], [20, 21], [26, 20]];
const COLORS = {
  grass: '#bdcf93', grassLight: '#c5d89a', grassDark: '#b7ca8c', grassMark: '#99b275',
  path: '#ead5ab', pathEdge: '#d4bd92', pathStone: '#f6e5c4', water: '#87bfc5',
  waterLight: '#add5d3', waterDark: '#70a8b1', ink: '#36493c', cream: '#fff9e9',
};

export function createRenderer(canvas, { atlasUrl = './assets/atlas.png' } = {}) {
  if (!canvas?.getContext) throw new Error('Mossbell needs a canvas to draw its village.');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('The village canvas could not be opened.');
  let atlas = null;
  let crops = DEFAULT_CROPS.map(box => [...box]);
  let lastState = null;
  let lastOptions = {};
  let previousPosition = null;
  const portraits = new Map();
  const reducedMotion = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)');
  const art = new Image();

  const ready = new Promise((resolve, reject) => {
    art.onload = () => {
      atlas = art;
      // Scan alpha inside each safe cell so every sprite has a useful, tight crop.
      // The atlas is same-origin. Hardcoded inspected bounds remain a safe fallback.
      try {
        const scratch = document.createElement('canvas');
        scratch.width = art.naturalWidth; scratch.height = art.naturalHeight;
        const sc = scratch.getContext('2d', { willReadFrequently: true });
        sc.drawImage(art, 0, 0);
        const { data } = sc.getImageData(0, 0, scratch.width, scratch.height);
        crops = ATLAS_NAMES.map((_, index) => {
          const left = index % 4 * 384;
          const [top, bottom] = ATLAS_ROWS[Math.floor(index / 4)];
          let minX = left + 384, minY = bottom, maxX = left, maxY = top;
          for (let y = top; y < bottom; y++) for (let x = left; x < left + 384; x++) {
            if (data[(y * scratch.width + x) * 4 + 3] >= 24) {
              minX = Math.min(minX, x); minY = Math.min(minY, y);
              maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
            }
          }
          if (maxX < minX || maxY < minY) return DEFAULT_CROPS[index];
          minX = Math.max(left, minX - 3); minY = Math.max(top, minY - 3);
          maxX = Math.min(left + 383, maxX + 3); maxY = Math.min(bottom - 1, maxY + 3);
          return [minX, minY, maxX - minX + 1, maxY - minY + 1];
        });
      } catch { /* Image pixels still draw normally if alpha inspection is unavailable. */ }
      if (lastState) draw(lastState, lastOptions);
      resolve(art);
    };
    art.onerror = () => reject(new Error('The village artwork could not be loaded.'));
  });
  art.src = atlasUrl;

  function roundedRect(x, y, w, h, radius = 5) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, radius);
  }

  function label(text, x, y, { fill = COLORS.cream, color = COLORS.ink, small = false, outline = null } = {}) {
    ctx.save();
    ctx.font = `${small ? 600 : 700} ${small ? 10 : 12}px system-ui, sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const shown = String(text ?? '').slice(0, 30);
    const width = Math.ceil(ctx.measureText(shown).width) + 16;
    roundedRect(Math.round(x - width / 2), Math.round(y - 10), width, 20, 7);
    ctx.fillStyle = fill; ctx.fill();
    if (outline) { ctx.strokeStyle = outline; ctx.lineWidth = 2; ctx.stroke(); }
    ctx.fillStyle = color; ctx.fillText(shown, Math.round(x), Math.round(y));
    ctx.restore();
  }

  function sprite(name, x, y, w, h, { fit = true, alpha = 1, rotation = 0 } = {}) {
    if (!atlas) return;
    const index = ATLAS_NAMES.indexOf(name);
    if (index < 0) return;
    const [sx, sy, sw, sh] = crops[index];
    let dw = w, dh = h;
    if (fit) { const scale = Math.min(w / sw, h / sh); dw = sw * scale; dh = sh * scale; }
    ctx.save(); ctx.globalAlpha = alpha;
    ctx.translate(Math.round(x + w / 2), Math.round(y + h / 2));
    if (rotation) ctx.rotate(rotation * Math.PI / 2);
    ctx.drawImage(atlas, sx, sy, sw, sh, Math.round(-dw / 2), Math.round(-dh / 2), Math.round(dw), Math.round(dh));
    ctx.restore();
  }

  function footSprite(name, x, y, w, h, options = {}) {
    const crop = crops[ATLAS_NAMES.indexOf(name)];
    const scale = crop ? Math.min(w / crop[2], h / crop[3]) : 1;
    const dh = crop ? crop[3] * scale : h;
    sprite(name, x - w / 2, y - dh, w, dh, options);
  }

  function pathCell(x, y) {
    return (x >= 5 && x <= 18 && y === 12)
      || (x >= 12 && x <= 14 && y >= 8 && y <= 17)
      || (x === 6 && y >= 8 && y <= 12)
      || (x >= 9 && x <= 17 && y === 8)
      || (x >= 18 && x <= 25 && y === 10)
      || (x === 18 && y >= 10 && y <= 12)
      || (x >= 8 && x <= 13 && y === 15)
      || (x >= 11 && x <= 15 && y >= 11 && y <= 14);
  }

  function grass() {
    ctx.fillStyle = COLORS.grass; ctx.fillRect(0, 0, canvas.width, canvas.height);
    for (let y = 0; y < TOWN.height; y++) for (let x = 0; x < TOWN.width; x++) {
      const n = (x * 71 + y * 97 + x * y * 13) % 19;
      if (pathCell(x, y)) {
        ctx.fillStyle = COLORS.pathEdge; ctx.fillRect(x * S, y * S, S, S);
        ctx.fillStyle = COLORS.path; ctx.fillRect(x * S + 1, y * S + 1, S - 2, S - 2);
        ctx.fillStyle = COLORS.pathStone;
        ctx.fillRect(x * S + 6 + n % 4, y * S + 9, 6, 3);
        if (n % 3 === 0) ctx.fillRect(x * S + 21, y * S + 23, 4, 3);
      } else {
        if (n < 7) { ctx.fillStyle = COLORS.grassLight; ctx.fillRect(x * S, y * S, S, S); }
        if (n > 14) { ctx.fillStyle = COLORS.grassDark; ctx.fillRect(x * S, y * S, S, S); }
        if (n % 3 === 0) {
          ctx.fillStyle = COLORS.grassMark;
          ctx.fillRect(x * S + 8, y * S + 20, 2, 4);
          ctx.fillRect(x * S + 12, y * S + 18, 2, 5);
        }
      }
    }
    ctx.fillStyle = '#afc483';
    ctx.fillRect(6 * S, 14 * S, 5 * S, 5 * S);
    ctx.fillStyle = '#cbdc9c'; ctx.fillRect(6 * S + 5, 14 * S + 5, 5 * S - 10, 5 * S - 10);
  }

  function pond(time) {
    const { x, y, w, h } = TOWN.pond;
    ctx.fillStyle = COLORS.pathEdge; ctx.fillRect(x * S - 7, y * S - 7, w * S + 14, h * S + 14);
    ctx.fillStyle = COLORS.path; ctx.fillRect(x * S - 4, y * S - 4, w * S + 8, h * S + 8);
    ctx.fillStyle = COLORS.waterDark; ctx.fillRect(x * S, y * S, w * S, h * S);
    ctx.fillStyle = COLORS.water; ctx.fillRect(x * S + 5, y * S + 5, w * S - 10, h * S - 10);
    const drift = reducedMotion?.matches ? 0 : Math.sin(time * 0.8) * 2;
    for (let j = 0; j < 7; j++) for (let i = 0; i < 5; i++) {
      ctx.fillStyle = (i + j) % 3 ? COLORS.waterLight : COLORS.waterDark;
      ctx.fillRect(Math.round(x * S + 22 + i * 39 + (j % 2) * 9 + drift), y * S + 20 + j * 29, 11 + i % 3 * 4, 2);
    }
    for (const [lx, ly] of [[21, 5], [24, 7], [20, 8]]) {
      ctx.fillStyle = '#739e73'; ctx.fillRect(lx * S + 3, ly * S + 10, 18, 7);
      ctx.fillStyle = '#d9a2b4'; ctx.fillRect(lx * S + 9, ly * S + 6, 6, 6);
    }
    label('Little pond', (x + w / 2) * S, (y + h) * S + 16);
  }

  function fence() {
    ctx.fillStyle = '#b59c77';
    for (let x = 12; x < canvas.width - 12; x += 26) {
      if (x > 12 * S && x < 15 * S) continue;
      ctx.fillRect(x, canvas.height - 16, 5, 15);
      ctx.fillRect(x, canvas.height - 11, 25, 4);
    }
  }

  function character(person, kind, time, { visitor = false, moving = false, friendship = false } = {}) {
    const x = (person.x + 0.5) * S, y = (person.y + 0.5) * S;
    const bob = reducedMotion?.matches ? 0 : moving ? Math.sin(time * 9) * 1.4 : Math.sin(time * 1.7 + person.x) * 0.5;
    ctx.save();
    ctx.fillStyle = visitor ? '#eef4e9' : kind === 'player' ? (person.color || '#89cdb9') : '#81946e';
    ctx.globalAlpha = kind === 'player' ? 0.75 : 0.24;
    ctx.beginPath(); ctx.ellipse(x, y - 1, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
    if (visitor) { ctx.strokeStyle = person.color || '#d8a1ba'; ctx.lineWidth = 3; ctx.stroke(); }
    ctx.restore();
    footSprite(kind, x, y - 1 + bob, 46, 59, { alpha: visitor ? 0.88 : 1 });
    label(visitor ? `${person.name || 'Friend'} · visiting` : person.name || 'You', x, y + 14, {
      small: true, outline: kind === 'player' ? (person.color || '#89cdb9') : null,
    });
    if (friendship) {
      ctx.fillStyle = '#fff9e9'; roundedRect(x + 11, y - 64, 17, 16, 6); ctx.fill();
      ctx.fillStyle = '#cf8b98';
      ctx.fillRect(x + 14, y - 60, 5, 4); ctx.fillRect(x + 21, y - 60, 4, 4);
      ctx.fillRect(x + 16, y - 56, 7, 3); ctx.fillRect(x + 18, y - 53, 3, 2);
    }
  }

  function town(state, time, guest, moving) {
    grass(); pond(time); fence();
    // The home footprint matches the blocked rectangle in the world rules.
    sprite('house', 3 * S, 3 * S, 6 * S, 5 * S, { fit: false });
    ctx.fillStyle = '#d5b493'; ctx.fillRect(6 * S, 8 * S, S, 9);
    label('Your home', 6 * S + 16, 8 * S + 21);
    sprite('bakery', 10 * S, 4 * S, 4 * S, 3.5 * S);
    label('Bakery', 12 * S, 4 * S - 9, { small: true });
    sprite('workshop', 16 * S, 13 * S, 3.7 * S, 3.4 * S);
    label('Workshop', 17.9 * S, 16.8 * S, { small: true });
    for (const [x, y] of [[7, 16], [9, 17], [6, 18], [3, 12], [23, 17]]) {
      footSprite('flowers', (x + 0.5) * S, (y + 0.5) * S, 52, 34);
    }
    const projectX = (PROJECT.x + 0.5) * S, projectY = (PROJECT.y + 0.5) * S;
    if (state.progress?.projectComplete) {
      footSprite('picnic', projectX, projectY + 13, 93, 60);
      footSprite('bench', projectX - 48, projectY + 65, 60, 39);
      footSprite('flowers', projectX + 56, projectY + 58, 44, 30);
    } else {
      ctx.fillStyle = '#d5b493'; ctx.fillRect(projectX - 5, projectY - 24, 4, 27);
      ctx.fillStyle = '#e9b3b9'; ctx.fillRect(projectX - 1, projectY - 24, 24, 15);
      ctx.fillStyle = COLORS.cream; ctx.fillRect(projectX + 5, projectY - 20, 4, 7);
      ctx.fillRect(projectX + 13, projectY - 20, 4, 7);
    }
    label(state.progress?.projectComplete ? 'Our picnic corner' : `Picnic corner · ${state.project?.donations?.length || 0}/3`, projectX, projectY + 34, { small: true });
    const whaleBob = reducedMotion?.matches ? 0 : Math.sin(time * 0.9) * 2;
    sprite('whale', 22 * S, 18 + whaleBob, 128, 91);

    const people = NPCS.map((npc, index) => ({ y: npc.y, draw: () => character(npc, ATLAS_NAMES[index], time, { friendship: state.friendships?.[npc.id] > 0 }) }));
    people.push({ y: state.player.y, draw: () => character(state.player, 'player', time, { moving }) });
    if (guest?.scene === 'town' && Number.isFinite(guest.x) && Number.isFinite(guest.y)) {
      people.push({ y: guest.y, draw: () => character(guest, 'player', time, { visitor: true }) });
    }
    const trees = TREE_POSITIONS.map(([x, y]) => ({ y: y + 0.2, draw: () => footSprite('tree', (x + 0.5) * S, (y + 0.5) * S, 92, 95) }));
    [...people, ...trees].sort((a, b) => a.y - b.y).forEach(row => row.draw());
  }

  function furniture(row, { ghost = false, valid = true } = {}) {
    const item = CAT[row.type];
    const size = furnitureSize(row.type, row.rotation);
    if (!item || !size) return;
    const x = row.x * S, y = row.y * S, w = size.w * S, h = size.h * S;
    ctx.save();
    if (ghost) ctx.globalAlpha = 0.66;
    ctx.fillStyle = ghost ? (valid ? '#bad6a4' : '#ecc0ba') : item.color;
    roundedRect(x + 3, y + 3, w - 6, h - 6, item.kind === 'rug' ? 3 : 6); ctx.fill();
    ctx.strokeStyle = ghost ? (valid ? '#597b4e' : '#b65d61') : '#9a775844'; ctx.lineWidth = ghost ? 2 : 1; ctx.stroke();
    if (item.kind === 'rug') {
      ctx.strokeStyle = '#f4d9d2'; ctx.lineWidth = 2; roundedRect(x + 8, y + 8, w - 16, h - 16, 3); ctx.stroke();
    } else if (FURNITURE_ART[row.type]) {
      const rotation = row.rotation % 2 ? 0 : (row.rotation === 2 ? 2 : 0);
      sprite(FURNITURE_ART[row.type], x + 4, y + 2, w - 8, h - 4, { rotation });
    } else {
      ctx.font = `${Math.min(w, h) > 40 ? 29 : 21}px system-ui, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(item.emoji, x + w / 2, y + h / 2 + 1);
    }
    if (row.rotation && !ghost) {
      ctx.fillStyle = '#fff9e9aa'; ctx.fillRect(x + w - 9, y + h - 9, 5, 5);
      ctx.fillStyle = '#77644e'; ctx.fillRect(x + w - 7, y + h - 8, 1, 3);
    }
    ctx.restore();
  }

  function ghostPlacement(state, placement) {
    if (!placement) return;
    const type = placement.type || placement.itemId || placement.item?.id;
    const x = Math.round(placement.x ?? placement.point?.x);
    const y = Math.round(placement.y ?? placement.point?.y);
    const row = { type, x, y, rotation: placement.rotation || 0 };
    const size = furnitureSize(type, row.rotation);
    if (!size || !Number.isFinite(x) || !Number.isFinite(y)) return;
    let valid = x >= 1 && y >= 1 && x + size.w <= HOME.width - 1 && y + size.h <= HOME.height - 1;
    valid = valid && !(x <= HOME.exit.x && HOME.exit.x < x + size.w && y <= HOME.exit.y && HOME.exit.y < y + size.h);
    valid = valid && !state.furniture.some(other => {
      if (other.id === placement.id || other.id === placement.furnitureId) return false;
      const otherSize = furnitureSize(other.type, other.rotation);
      return x < other.x + otherSize.w && x + size.w > other.x && y < other.y + otherSize.h && y + size.h > other.y;
    });
    valid = valid && !(state.player.x + 0.24 > x - 0.5 && state.player.x - 0.24 < x + size.w - 0.5
      && state.player.y + 0.24 > y - 0.5 && state.player.y - 0.24 < y + size.h - 0.5);
    if (typeof placement.valid === 'boolean') valid = placement.valid;
    furniture(row, { ghost: true, valid });
    label(CAT[type].name, x * S + size.w * S / 2, y * S - 9, {
      small: true, fill: valid ? '#f4fae9' : '#ffe6e0', color: valid ? '#406438' : '#994b50',
    });
  }

  function home(state, time, guest, placement, moving) {
    ctx.fillStyle = '#9eaa98'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#ecdfc4'; ctx.fillRect(S, S, (HOME.width - 2) * S, (HOME.height - 2) * S);
    for (let y = 1; y < HOME.height - 1; y++) for (let x = 1; x < HOME.width - 1; x++) {
      ctx.fillStyle = (x + y) % 2 ? '#dfbd92' : '#e6c8a0';
      ctx.fillRect(x * S, y * S, S, S);
      ctx.fillStyle = '#d0ac80'; ctx.fillRect(x * S, y * S + S - 1, S, 1);
      ctx.fillRect(x * S + ((y % 2) * 15), y * S + 7, 1, 12);
    }
    ctx.fillStyle = '#b8c6ac'; ctx.fillRect(0, 0, canvas.width, S);
    ctx.fillStyle = '#b5a485'; ctx.fillRect(S - 4, S, 4, canvas.height - 2 * S);
    ctx.fillRect(canvas.width - S, S, 4, canvas.height - 2 * S);
    ctx.fillRect(S - 4, S - 4, canvas.width - 2 * S + 8, 4);
    // A small window and the bottom door explain the room at a glance.
    ctx.fillStyle = '#786f5b'; ctx.fillRect(2 * S, 3, 2 * S, 25);
    ctx.fillStyle = '#b9d8d1'; ctx.fillRect(2 * S + 4, 6, 2 * S - 8, 19);
    ctx.fillStyle = '#f5e4ba'; ctx.fillRect(3 * S - 1, 6, 3, 19); ctx.fillRect(2 * S + 4, 14, 2 * S - 8, 3);
    ctx.fillStyle = '#896d55'; ctx.fillRect(HOME.exit.x * S, (HOME.height - 1) * S, S, S);
    ctx.fillStyle = '#c3a579'; ctx.fillRect(HOME.exit.x * S - 4, HOME.exit.y * S + 7, S + 8, 21);
    label('Your home', canvas.width / 2 + 18, 16, { small: true });
    label('Town ↓', (HOME.exit.x + 0.5) * S, canvas.height - 15, { small: true });
    if (placement) {
      ctx.save(); ctx.strokeStyle = '#99785444'; ctx.lineWidth = 1;
      for (let x = 1; x < HOME.width; x++) { ctx.beginPath(); ctx.moveTo(x * S, S); ctx.lineTo(x * S, canvas.height - S); ctx.stroke(); }
      for (let y = 1; y < HOME.height; y++) { ctx.beginPath(); ctx.moveTo(S, y * S); ctx.lineTo(canvas.width - S, y * S); ctx.stroke(); }
      ctx.restore();
    }
    const rugs = state.furniture.filter(row => CAT[row.type]?.kind === 'rug');
    rugs.forEach(row => furniture(row));
    const layers = state.furniture.filter(row => CAT[row.type]?.kind !== 'rug').map(row => ({
      y: row.y + furnitureSize(row.type, row.rotation).h - 0.5, draw: () => furniture(row),
    }));
    layers.push({ y: state.player.y, draw: () => character(state.player, 'player', time, { moving }) });
    if (guest?.scene === 'home' && Number.isFinite(guest.x) && Number.isFinite(guest.y)) {
      layers.push({ y: guest.y, draw: () => character(guest, 'player', time, { visitor: true }) });
    }
    layers.sort((a, b) => a.y - b.y).forEach(row => row.draw());
    ghostPlacement(state, placement);
  }

  function draw(state, options = {}) {
    if (!state?.player) return;
    lastState = state; lastOptions = options;
    const size = state.player.scene === 'home' ? HOME : TOWN;
    const width = size.width * S, height = size.height * S;
    if (canvas.width !== width) canvas.width = width;
    if (canvas.height !== height) canvas.height = height;
    canvas.style.aspectRatio = `${width} / ${height}`;
    ctx.imageSmoothingEnabled = false;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
    ctx.clearRect(0, 0, width, height);
    const time = Number.isFinite(options.time) ? options.time / 1000 : 0;
    const moving = previousPosition?.scene === state.player.scene
      && Math.hypot(state.player.x - previousPosition.x, state.player.y - previousPosition.y) > 0.001;
    previousPosition = { x: state.player.x, y: state.player.y, scene: state.player.scene };
    const guest = options.guest?.player || options.guest;
    if (state.player.scene === 'home') home(state, time, guest, options.placement, moving);
    else town(state, time, guest, moving);
  }

  function worldPoint(event) {
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return { x: 0, y: 0 };
    return {
      x: (event.clientX - rect.left) * canvas.width / rect.width / S - 0.5,
      y: (event.clientY - rect.top) * canvas.height / rect.height / S - 0.5,
    };
  }

  function portrait(npcIndex) {
    const index = Math.max(0, Math.min(2, Number.isInteger(npcIndex) ? npcIndex : 0));
    if (atlas && portraits.has(index)) return portraits.get(index);
    const out = document.createElement('canvas'); out.width = 128; out.height = 128;
    const pc = out.getContext('2d'); pc.imageSmoothingEnabled = false;
    if (atlas) {
      const [sx, sy, sw, sh] = crops[index];
      const scale = Math.min(112 / sw, 116 / sh);
      const w = Math.round(sw * scale), h = Math.round(sh * scale);
      pc.drawImage(atlas, sx, sy, sw, sh, Math.round((128 - w) / 2), 124 - h, w, h);
    }
    const url = out.toDataURL('image/png');
    if (atlas) portraits.set(index, url);
    return url;
  }

  return { draw, ready, worldPoint, portrait };
}
