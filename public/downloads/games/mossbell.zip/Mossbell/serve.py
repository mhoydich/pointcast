#!/usr/bin/env python3
"""Run the packaged game locally with a stable browser save origin."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, webbrowser
os.chdir(Path(__file__).resolve().parent)
class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path in ('/', '/index.html'):
            self.path='/Mossbell.html'
        return super().do_GET()
    def log_message(self, *_):
        pass
try:
    server=ThreadingHTTPServer(('127.0.0.1',48379), Handler)
except OSError:
    print('Mossbell could not open its local port. Stop the earlier Mossbell Terminal server with Control-C, then try again.')
    input('Press Return to close. ')
    raise SystemExit(1)
url='http://127.0.0.1:48379/'
print('Mossbell is open at '+url)
print('Leave this Terminal window open while playing. Control-C closes the local server.')
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    server.server_close()
