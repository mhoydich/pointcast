from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
import math, re, json, html, subprocess, os, hashlib
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).parent
ART=ROOT/'source'
FONTS={
 'sans':'/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed.ttf',
 'bold':'/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf',
 'serif':'/usr/share/fonts/truetype/dejavu/DejaVuSerifCondensed.ttf',
 'serifbold':'/usr/share/fonts/truetype/dejavu/DejaVuSerifCondensed-Bold.ttf',
 'mono':'/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',
}
FONTDATA={}
for k,p in FONTS.items():
 f=TTFont(p); FONTDATA[k]=(f,f.getBestCmap(),f.getGlyphSet(),f['head'].unitsPerEm,{})

class Note:
 def __init__(self,num,title,bg,ink):
  self.num,self.title,self.bg,self.ink=num,title,bg,ink; self.parts=[]; self.nouns=[]
  self.parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="150mm" height="75mm" viewBox="0 0 1800 900"><title>{html.escape(title)} — Nouns Money collection {num:02d}</title><desc>Fictional Nouns collectible note. Not legal tender. Exact official numbered Nouns art embedded without alteration. Design size 150 × 75 mm.</desc>')
  self.rect(0,0,1800,900,bg)
 def add(self,s): self.parts.append(s)
 def rect(self,x,y,w,h,fill='none',stroke=None,sw=1,rx=0):
  self.add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+(f' rx="{rx}"' if rx else '')+'/>')
 def line(self,x1,y1,x2,y2,col=None,sw=2): self.add(f'<path d="M{x1} {y1}H{x2}" fill="none" stroke="{col or self.ink}" stroke-width="{sw}"/>' if y1==y2 else f'<path d="M{x1} {y1}L{x2} {y2}" fill="none" stroke="{col or self.ink}" stroke-width="{sw}"/>')
 def path(self,d,fill='none',stroke=None,sw=2): self.add(f'<path d="{d}" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+'/>')
 def text(self,s,x,y,size,font='sans',fill=None,align='left',tracking=0):
  f,cmap,glyphs,upem,cache=FONTDATA[font]; scale=size/upem; advances=[]; names=[]
  for c in s:
   name=cmap.get(ord(c),'.notdef'); names.append(name); advances.append(f['hmtx'][name][0]*scale+tracking)
  width=sum(advances)-(tracking if s else 0)
  if align=='center': x-=width/2
  elif align=='right': x-=width
  self.add(f'<g fill="{fill or self.ink}" aria-label="{html.escape(s)}">')
  for name,adv in zip(names,advances):
   if name not in cache:
    pen=SVGPathPen(glyphs); glyphs[name].draw(pen); cache[name]=pen.getCommands()
   if cache[name]: self.add(f'<path d="{cache[name]}" transform="translate({x:.4f} {y}) scale({scale:.7f} {-scale:.7f})"/>')
   x+=adv
  self.add('</g>'); return width
 def art(self,nounid,x,y,size,frame=None):
  source=ASSETS[nounid]; text=source.read_text();
  content=re.sub(r'^.*?<svg\b[^>]*>','',text,count=1,flags=re.S); content=re.sub(r'</svg>\s*$','',content)
  match=re.search(r'viewBox=[\"\']([^\"\']+)',text); vb=match.group(1) if match else '0 0 320 320'
  if frame: self.rect(x-9,y-9,size+18,size+18,'none',frame,3)
  self.add(f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="{vb}" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges" aria-label="Official Noun {nounid}">{content}</svg>')
  self.nouns.append(nounid)
 def border(self,c=None,style='plain'):
  c=c or self.ink
  if style=='plain':
   self.rect(30,30,1740,840,'none',c,3); self.rect(42,42,1716,816,'none',c,1.5)
  elif style=='pixel':
   self.rect(30,30,1740,840,'none',c,8)
   for x in range(48,1753,32):
    self.rect(x,46,16,10,c); self.rect(x,844,16,10,c)
   for y in range(66,835,32):
    self.rect(46,y,10,16,c); self.rect(1744,y,10,16,c)
  elif style=='double':
   self.rect(30,30,1740,840,'none',c,2); self.rect(42,42,1716,816,'none',c,6); self.rect(56,56,1688,788,'none',c,1.5)
 def footer(self,fill=None,y=840,serial=True,small=24):
  fill=fill or self.ink
  self.text('NOUNS MONEY · COLLECTION 01',80,y,25,'bold',fill,tracking=1)
  self.text('Not legal tender',1720,y,small,'sans',fill,'right')
  if serial: self.text(f'N {self.num:06d}',1720,y-70,27,'mono',fill,'right',tracking=1)
 def motto(self,x,y,size=30,fill=None,align='left',tracking=1): self.text('ONE NOUN, EVERY DAY, FOREVER',x,y,size,'bold',fill,align,tracking)
 def tiles(self,x,y,cols,rows,step,c,mode=0):
  for row in range(rows):
   for col in range(cols):
    if ((row+col)%3==0 if mode==0 else (row*col+row+col)%5<2):
     self.rect(x+col*step,y+row*step,step*.45,step*.45,c)
 def grid(self,x,y,w,h,step,c):
  for xx in range(x,x+w+1,step): self.line(xx,y,xx,y+h,c,1)
  for yy in range(y,y+h+1,step): self.line(x,yy,x+w,yy,c,1)
 def rosette(self,cx,cy,r,c,sw=2,count=9):
  # Original geometric note ornament; deliberately no face or noggles geometry.
  for k in range(count):
   r0=r-k*10
   coords=[(-.4,-1),(.4,-1),(.4,-.8),(.65,-.8),(.65,-.65),(.8,-.65),(.8,-.4),(1,-.4),(1,.4),(.8,.4),(.8,.65),(.65,.65),(.65,.8),(.4,.8),(.4,1),(-.4,1),(-.4,.8),(-.65,.8),(-.65,.65),(-.8,.65),(-.8,.4),(-1,.4),(-1,-.4),(-.8,-.4),(-.8,-.65),(-.65,-.65),(-.65,-.8),(-.4,-.8)]
   d='M'+'L'.join(f'{cx+a*r0:.1f},{cy+b*r0:.1f}' for a,b in coords)+'Z'; self.path(d,'none',c,sw)
 def wavefield(self,x,y,w,h,c):
  for dy in range(0,h,15):
   pts=[]
   for dx in range(0,w+1,12):
    yy=y+dy+14*math.sin(dx/70+dy/50)
    yy=round(yy/6)*6
    pts.append(f'{x+dx},{yy}')
   self.path('M'+'L'.join(pts),'none',c,1.2)
 def save(self):
  self.add('</svg>'); path=ROOT/'svg'/f'{self.num:02d}-{self.title.lower().replace(" ","-")}.svg';path.write_text('\n'.join(self.parts)); return path

ASSETS={i:ART/f'noun-{i:04d}-original.svg' for i in range(10)}
def circle(n,x,y,r,fill,stroke=None,sw=2):
 n.add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+'/>')
def foot(n):
 n.line(60,815,1740,815,n.ink,2)
 n.text(f'COLLECTION 01 / NM-A-{n.num:04d}',60,854,23,'mono')
 n.text('COLLECTIBLE ART • NOT LEGAL TENDER',1740,854,22,'mono',align='right')
def title(n,x=60,y=132,size=97,font='bold',fill=None):n.text('NOUNS MONEY',x,y,size,font,fill,tracking=-2)
def label(n,s,x,y):n.text(s,x,y,22,'mono',tracking=2)
def build():
 out=[]
 # 1: oversized black typography, acidic split, portrait on raised orange panel
 n=Note(1,'Acid Assembly','#e6f46a','#191a17');title(n,size=112)
 n.line(60,167,1740,167,sw=5);n.rect(1080,200,660,560,'#fc7045')
 for x in range(1100,1735,32):n.line(x,210,x,750,'#ef542b',2)
 n.art(0,1150,240,480);n.text('1',55,680,570,'bold');n.text('LET’S',505,353,72,'bold');n.text('COLLECT',505,432,72,'bold');n.text('NOUNS.',505,511,72,'bold');label(n,'ONE / ART FOR ALL',520,731);foot(n);out.append(n)
 # 2: carnival red/cream, architectural arch and decorative scallops, giant stacked unit
 n=Note(2,'Carnival Five','#f4e8d0','#b63124');title(n,70,132,101,'serifbold')
 n.path('M620 780V490A280 280 0 0 1 1180 490V780Z','#b63124')
 # portrait is fully visible and square; no silhouette clipping
 n.art(1,660,285,480);n.text('5',80,661,570,'serifbold');n.text('5',1670,661,570,'serifbold',align='right')
 for x in range(90,1750,48):circle(n,x,189,12,n.ink)
 label(n,'FIVE NOUNS',70,750);label(n,'LET’S GO TEAM',1320,750);foot(n);out.append(n)
 # 3: violet editorial grid, huge denomination behind discrete left portrait
 n=Note(3,'Ultra Ten','#d7c3f4','#452478');n.rect(0,0,1800,178,'#452478');title(n,60,127,104,fill='#f3f66a')
 n.grid(60,208,1680,560,40,'#b49bd9');n.text('10',1700,688,610,'bold',fill='#f1ef64',align='right');n.art(2,130,258,480)
 n.rect(750,708,990,60,'#452478');n.text('TEN / THE DAILY COLLECTION',780,750,29,'mono','#fff3dc');foot(n);out.append(n)
 # 4: botanical green with concentric engraver lines and editorial cream title plaque
 n=Note(4,'Garden Twenty','#174b3c','#f0e8c9')
 for r in range(120,1080,18):circle(n,1390,450,r,'none','#407a59',2)
 n.rect(60,60,1110,139,'#f0e8c9');title(n,84,161,99,'serifbold','#174b3c');n.art(3,1170,260,480)
 n.text('20',70,659,435,'serifbold');label(n,'TWENTY NOUNS',90,744);n.text('SMALL ART.',650,356,52,'serif');n.text('BIG WORLD.',650,420,52,'serif');foot(n);out.append(n)
 # 5: high-energy cobalt sports ticket with perforation and angled orange value strip
 n=Note(5,'Team Fifty','#254de9','#fff6e4');n.path('M1130 0H1800V900H1420Z','#f66937');title(n,60,139,104)
 n.text('50',75,577,395,'bold');n.text('LET’S GO TEAM',78,687,64,'bold');label(n,'FIFTY / COLLECT TOGETHER',80,753)
 for y in range(205,790,32):circle(n,1035,y,7,n.ink)
 n.art(4,1170,270,480);foot(n);out.append(n)
 # 6: pink typography-led membership-card composition, broad sunburst with intact art
 n=Note(6,'Pink Orbit','#f4bed4','#762744');title(n,60,134,104)
 for a in range(0,360,12):
  t=math.radians(a);n.line(485+220*math.cos(t),490+220*math.sin(t),485+390*math.cos(t),490+290*math.sin(t),'#c47697',3)
 n.art(5,245,250,480);n.text('100',1730,535,395,'serifbold',align='right');n.text('A HUNDRED REASONS',930,650,41,'bold');label(n,'TO COLLECT NOUNS MONEY',930,705);foot(n);out.append(n)
 # 7: orange/black industrial catalog with thick partition and boxed typesetting
 n=Note(7,'Orange Index','#f49c37','#242727');n.rect(60,60,590,707,n.ink);n.art(6,115,175,480)
 n.text('NOUNS',720,205,167,'bold');n.text('MONEY',720,380,167,'bold');n.line(720,425,1740,425,sw=7)
 n.text('1',720,751,302,'bold');n.text('ONE',1050,551,76,'bold');n.text('GOOD',1050,633,76,'bold');n.text('COLLECTION.',1050,715,76,'bold');foot(n);out.append(n)
 # 8: paper/black newspaper with asymmetrical headline and a mint-green portrait mount
 n=Note(8,'Paper Edition','#eeeae0','#252623');title(n,60,147,118,'serifbold');n.line(60,180,1740,180,sw=9)
 n.text('THE ART OF',65,283,45,'serif');n.text('COLLECTING',65,348,57,'serifbold');n.text('5',75,734,391,'serifbold');n.rect(830,220,910,550,'#a5d8b7');n.art(7,1040,255,480)
 for y in range(420,734,33):n.line(450,y,750,y,n.ink,2)
 label(n,'FIVE / NOUN #7',900,793);foot(n);out.append(n)
 # 9: turquoise & orange flowing optical field with staggered chip denomination
 n=Note(9,'Wave Ten','#9ee1dc','#1c5369')
 for k in range(18):
  y=195+k*31;n.path(f'M0 {y}C420 {y-160} 850 {y+160} 1800 {y-80}','none','#60b9bd',5)
 n.rect(0,0,1800,180,'#1c5369');title(n,60,129,106,fill='#f2ede2');n.rect(70,248,600,520,'#f2774d');n.art(8,130,268,480)
 n.rect(815,287,400,425,'#f2ede2');n.rect(1250,245,470,425,'#f2ede2');n.text('1',1020,645,395,'bold',align='center');n.text('0',1485,602,395,'bold',align='center');foot(n);out.append(n)
 # 10: celestial purple/gold medallion, wide framing rather than old banknote layout
 n=Note(10,'Golden Cosmos','#3e2859','#f5d891');title(n,60,133,103,'serifbold')
 for r in range(290,410,14):circle(n,900,490,r,'none','#967245',2)
 for i in range(36):
  a=math.pi*i/18;circle(n,900+430*math.cos(a),490+278*math.sin(a),4,n.ink)
 n.rect(0,0,1800,175,'#3e2859');title(n,60,133,103,'serifbold');n.art(9,660,248,480);n.text('20',70,560,287,'serifbold');n.text('20',1720,560,287,'serifbold',align='right');label(n,'TWENTY',105,655);label(n,'NOUNS',1505,655);foot(n);out.append(n)
 return out
if __name__=='__main__':
 notes=build();meta=[]
 for n in notes:
  p=n.save();q=ROOT/'png'/p.with_suffix('.png').name
  subprocess.run(['inkscape',str(p),'--export-type=png',f'--export-filename={q}','--export-width=3600','--export-height=1800'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  im=Image.open(q).convert('RGB');im.save(q,dpi=(609.6,609.6));im.resize((1200,600)).save(ROOT/'qa'/q.name)
  meta.append({'number':n.num,'title':n.title,'nouns':n.nouns,'svg':str(p),'png':str(q),'size_mm':[150,75]});print(n.num,n.title,flush=True)
 (ROOT/'design_manifest.json').write_text(json.dumps(meta,indent=2))
 W,H=2480,3530;im=Image.new('RGB',(W,H),'#f2f0e9');d=ImageDraw.Draw(im);fb=ImageFont.truetype(FONTS['bold'],36);fs=ImageFont.truetype(FONTS['mono'],20)
 d.text((60,35),'NOUNS MONEY / LET’S COLLECT',font=fb,fill='#222222');d.text((60,92),'Collection 01 • Ten new designs • Authentic Nouns #0–9 • 150 × 75 mm',font=fs,fill='#555555')
 for i,m in enumerate(meta):
  x=60+(i%2)*1210;y=160+(i//2)*666
  im.paste(Image.open(m['png']).resize((1150,575)),(x,y));d.text((x,y+590),f'{i+1:02d} / '+m['title'].upper(),font=fb,fill='#222222');d.text((x,y+634),f'Noun #{m["nouns"][0]} • NM-A-{i+1:04d}',font=fs,fill='#555555')
 im.save(ROOT/'nouns-money-contact-sheet.png')
