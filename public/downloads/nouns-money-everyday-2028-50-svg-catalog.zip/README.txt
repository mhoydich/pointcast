NOUNS MONEY — THE EVERYDAY COLLECTION / 2028

50 individual original certificate compositions, native SVG + 1800×1200 PNG.
Open catalog.html for a visual catalog; catalog.json and catalog.csv contain full metadata.
The five designs in each family form a small visual series, with a different geometric ornament and individual title and dedication.

Mint preparation only. Planned price: 1 tez. Mint status: not configured. Edition quantity: TBD. No mint, sale, funding, redemption, financial rights or guaranteed benefits. The existing free Collect library is a separate collection.

Authentic Nouns #50–99: original pixel geometry, palette and background preserved from the verified sources. CC0 Nouns art. No ownership of source Noun NFTs is conveyed, and no official affiliation is claimed. See source-provenance.json for source verification and URLs. Native ornamental composition and lettering are newly authored.
