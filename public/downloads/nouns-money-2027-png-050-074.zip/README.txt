NOUNS MONEY — NORDIC SERIES 2027
100 individual collectible designs, actual Nouns NFTs #0–99.

PNG: 1800 × 900 pixels, 304.8 dpi, 150 × 75 mm.
SVG: editable native vector layout with outlined lettering and unchanged original Noun pixel artwork.
Bleed SVG: 156 × 81 mm with 3 mm paper-background bleed all sides. Trim to 150 × 75 mm centered.
RGB artwork; ask your printer to soft-proof and convert using their output profile. No printer-specific CMYK separation is claimed.
All denominations: 1. Serials: NM27-000001 through NM27-000100.
COLLECTIBLE ART — NOT LEGAL TENDER. No redemption, funding, ownership or endorsement claim.

Source art: official NounsDAO RLE assets and actual NFT seeds. See sources/provenance.json. Nouns art is CC0.
100 different Noun IDs and exact source artwork hashes verified unique.

Proof pages: 10 notes per page. Overview: all 100.
