NOGGLE RESERVE — TEN AUTHENTIC NOUNS NOTE PROTOTYPES

Ten front-face design studies. Fictional collectible art/trade notes, not legal tender.

DELIVERABLES
- 10 PNG images: 3600 × 1800 px, 2:1 landscape
- 10 vector-native SVG sources: 150 × 75 mm, type converted to outlines
- 2-column × 5-row comparison contact sheet
- Untouched original Nouns SVG artwork, source provenance, and exact-pixel render verification

ARTWORK
The artwork is the actual numbered Nouns #0–9, not generated lookalikes. Original SVGs from noun.pics, the image service used by nouns.wtf, were verified against the official Nouns asset traits and each token's seed. The source shapes and colors are unchanged, with uniform scaling only. Every artwork region in every final PNG matches the source PNG resized with nearest-neighbor sampling, pixel for pixel. Full token provenance is in source/official-art-provenance.json.

DESIGN / PRODUCTION NOTES
The printed size encoded in the SVGs is 150 × 75 mm. These are front-layout prototypes, not a press-ready production pack: no bleed/cutline engineering, color separations, spot-foil plates, proofed stock, or printer-specific finishing guarantees are included. The gold appearance is a flat process-color design study, not simulated or prepared metallic foil.

ONE-LINE CRITIQUES

01 / Founding Red: Best classic-currency direction; a tighter stepped frame would make the portrait feel more integrated.

02 / Arctic Ledger: Strongest everyday denomination system; echo the blue vertical stripe on future reverse designs.

03 / Daylight Ten: Most energetic color pairing; a slightly smaller 10 would give the slogan more breathing room.

04 / Midnight Vault: Strongest ceremonial note; retain the navy and gold but reduce one repeated NOUNS NOTE label next.

05 / Noun Parade: Best expression of the whole collection; add one extra Noun if you want the portrait count to match five.

06 / Pixel Weave: Closest to a security-printed banknote; increase the wave contrast slightly after a paper proof.

07 / Red Signal: Clearest from across the room; smaller side numerals would make the chainsaw Noun the singular focal point.

08 / Archive Stamps: Most collectible editorial layout; push the perforation motif a little further on the next pass.

09 / Blue Assembly: Best community/gallery note; a calmer title would give the five original Nouns more prominence.

10 / Golden Pair: Best premium pair; simplify the central NR column if you want a less formal, more playful note.
