"""Unit 02 lower chassis. All geometry is in metres, in vehicle coordinates."""

def unit02_build_running_gear():
    from math import sin, cos, pi, sqrt, hypot, atan2, ceil
    from collections import defaultdict
    from bisect import bisect_right
    from mathutils import Vector

    # A batch shares geometry by role and finish, not by axle or individual bolt.
    class Batches:
        def __init__(self):
            self.items = defaultdict(lambda: [[], []])

        def add(self, key, p, f):
            verts, faces = self.items[key]
            n = len(verts)
            verts.extend(p)
            faces.extend(tuple(n+i for i in face) for face in f)

        def finish(self):
            import bmesh
            for (name, finish), (points, polygons) in self.items.items():
                model = mesh(name, points, polygons, finish)
                # Merge the boundaries shared by batched curved strips; consistently
                # orient isolated, closed shoe and wheel parts for double-sided orbit.
                if model is None:
                    model = bpy.data.objects.get(name)
                if model and model.type == 'MESH':
                    bm = bmesh.new()
                    bm.from_mesh(model.data)
                    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=0.000005)
                    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
                    bm.to_mesh(model.data)
                    bm.free()
                    model.data.update()

    def loops(batch, key, rings, close_profile=False, caps=False):
        count = len(rings[0])
        verts = [v for ring in rings for v in ring]
        faces = []
        for j in range(len(rings) if close_profile else len(rings)-1):
            k = (j+1) % len(rings)
            for i in range(count):
                q = (i+1) % count
                faces.append((j*count+i,j*count+q,k*count+q,k*count+i))
        if caps:
            faces.extend([tuple(reversed(range(count))),
                          tuple((len(rings)-1)*count+i for i in range(count))])
        batch.add(key, verts, faces)

    def wheel_surface(batch, key, x, y, z, side, contour, seg=40, sealed=False, caps=False):
        rings = [[(x+rad*cos(2*pi*k/seg), y+side*d,
                   z+rad*sin(2*pi*k/seg)) for k in range(seg)] for d, rad in contour]
        loops(batch, key, rings, sealed, caps)

    def oriented_box(batch, key, center, axis_u, axis_v, axis_w, sizes):
        c, u, v, w = map(Vector, [center,axis_u,axis_v,axis_w])
        u *= sizes[0]/2
        v *= sizes[1]/2
        w *= sizes[2]/2
        p = [tuple(c+i*u+j*v+k*w) for i,j,k in
             [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),
              (-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
        batch.add(key, p, [(0,3,2,1),(4,5,6,7),(0,1,5,4),
                           (1,2,6,5),(2,3,7,6),(3,0,4,7)])

    def strut(batch, key, p1, p2, width, thickness):
        a,b = Vector(p1),Vector(p2)
        u = (b-a).normalized()
        v = Vector((0,1,0))
        w = u.cross(v).normalized()
        v = w.cross(u).normalized()
        oriented_box(batch,key,(a+b)/2,u,v,w,((b-a).length,width,thickness))

    def circular_plate_vents(batch,x,y,z,sgn):
        # A real perforated disc: an annular sector surrounds each opening.
        # Its die-pressed lip returns inward to meet the darker back web.
        holes = 8
        for h in range(holes):
            a0 = 2*pi*h/holes
            rings=[]
            for perimeter, depth, hole_r in [(True,.205,.037),(False,.205,.038),
                                              (False,.185,.033),(True,.185,.037)]:
                ring=[]
                for j in range(16):
                    a=2*pi*j/16
                    u,v=cos(a),sin(a)
                    if perimeter:
                        m=max(abs(u),abs(v))
                        theta=a0+(pi/holes)*u/m
                        r=.214+.080*v/m
                    else:
                        theta=a0+hole_r*u/.214
                        r=.214+hole_r*v
                    ring.append((x+r*cos(theta),y+sgn*depth,z+r*sin(theta)))
                rings.append(ring)
            loops(batch,('Pierced road wheel discs','steel'),rings,True)

    def track_path():
        # z=0.048 centre line on the flat: 27 mm belt + 21 mm grouser land.
        # Tangencies off the lower rollers put the rising shoes under the end wheels.
        re, rz, ex = .393,.606,3.57
        wx, wz, wr = 2.82,.474,.426
        dx,dz = ex-wx,rz-wz
        beta = atan2(dz,dx) - math.acos((wr-re)/hypot(dx,dz))
        def arc(cx,cz,r,begin,end,n):
            return [(cx+r*cos(begin+(end-begin)*i/n),cz+r*sin(begin+(end-begin)*i/n))
                    for i in range(n+1)]
        right=arc(ex,rz,re,pi/2,beta,35)+arc(wx,wz,wr,beta,-pi/2,5)
        left=[(-x,z) for x,z in reversed(right)]
        return right+left

    group('Chassis')
    ch = Batches()
    xyz = [(1,0,0),(0,1,0),(0,0,1)]
    def beam(name,pos,dim,finish='dark'):
        oriented_box(ch,(name,finish),pos,*xyz,dim)
    for s in [-1,1]:
        beam('Chassis longitudinal rails',(0,s*.68,.86),(7.55,.16,.33))
        beam('Lower chassis flanges',(0,s*.68,.715),(7.55,.24,.042),'steel')
        beam('Upper chassis flanges',(0,s*.68,1.015),(7.55,.24,.050),'steel')
    for x in [-3.44,-2.35,-1.22,0,1.22,2.35,3.44]:
        beam('Transverse members',(x,0,.86),(.14,1.73,.21))
    for x in [-2.95,-1.2,.55]:
        beam('Underslung equipment trays',(x,0,.54),(1.37,1.11,.39),'teal')
        beam('Equipment tray kick plates',(x,0,.34),(1.45,1.17,.045),'steel')
        for dx in [-.46,.46]:
            beam('Equipment straps',(x+dx,0,.537),(.061,1.13,.405),'dark')
    beam('Rear drive casing',(2.57,0,.66),(1.55,1.25,.57),'steel')
    for k in range(13):
        beam('Rear casing ribs',(1.91+k*.11,0,.666),(.030,1.28,.58),'dark')
    ch.finish()

    group('Running gear')
    g=Batches()
    path=track_path()
    segments=[]
    distance=[0.]
    for i,(x,z) in enumerate(path):
        xx,zz=path[(i+1)%len(path)]
        d=hypot(xx-x,zz-z)
        if d > 1e-8:
            segments.append((x,z,(xx-x)/d,(zz-z)/d))
            distance.append(distance[-1]+d)

    def at_track_length(length):
        s=length % distance[-1]
        i=min(len(segments)-1,bisect_right(distance,s)-1)
        x,z,dx,dz=segments[i]
        f=s-distance[i]
        return x+dx*f,z+dz*f,dx,dz

    for side in [-1,1]:
        cy=side*1.075
        # The continuous belt uses a square, rigid cross-section on the straight runs.
        # Across the nose/tail, local averaged normals avoid tiny breaks at joints.
        belt=[]
        for i,(x,z) in enumerate(path):
            prev=path[i-1]
            nxt=path[(i+1)%len(path)]
            av=Vector((x-prev[0],z-prev[1])).normalized()+Vector((nxt[0]-x,nxt[1]-z)).normalized()
            dx,dz=av.normalized()
            nx,nz=-dz,dx
            belt.append([(x+nx*h,cy+w,z+nz*h) for w,h in
                         [(-.333,-.026),(.333,-.026),(.333,.027),(-.333,.027)]])
        loops(g,('Continuous reinforced belts','rubber'),belt,True)
        shoe_count=104
        pitch=distance[-1]/shoe_count
        for j in range(shoe_count):
            x,z,dx,dz=at_track_length((j+.18)*pitch)
            t=Vector((dx,0,dz))
            n=Vector((-dz,0,dx))
            sy=Vector((0,1,0))
            c=Vector((x,cy,z))
            oriented_box(g,('Track shoes','dark'),c+n*.030,t,sy,n,(pitch*.80,.692,.008))
            for direction in [-1,1]:
                # Alternating chevron rises slightly toward the outer edges.
                interm=(sy*direction+t*.14).normalized()
                cross=interm.cross(n).normalized()
                center=c+n*.040+sy*(direction*.151)
                oriented_box(g,('Raised grouser ribs','steel'),center,cross,interm,n,(.035,.271,.016))
            for sign in [-1,1]:
                oriented_box(g,('Outer hinge knuckles','dark'),
                             c-t*pitch*.375+sy*(sign*.331),t,sy,n,(.051,.033,.040))
        for j in range(7):
            x=(j-3)*.94
            z=.474
            yy=cy+side*.029
            wheel_surface(g,('Road wheel rubber tires','rubber'),x,yy,z,side,
                          [(-.216,.329),(-.215,.380),(-.192,.396),(.166,.396),
                           (.188,.387),(.201,.376),(.201,.329)],sealed=True)
            wheel_surface(g,('Formed outer wheel rims','steel'),x,yy,z,side,
                          [(-.217,.276),(-.217,.331),(-.182,.344),(.187,.344),
                           (.21,.337),(.216,.326),(.202,.294),(.185,.289)],sealed=True)
            wheel_surface(g,('Turned wheel lips','lightmetal'),x,yy,z,side,
                          [(.202,.328),(.210,.332),(.215,.327),(.211,.322)],sealed=True)
            wheel_surface(g,('Recessed wheel backs','dark'),x,yy,z,side,
                          [(-.204,.29),(-.174,.29)],caps=True)
            circular_plate_vents(g,x,yy,z,side)
            wheel_surface(g,('Axle hubs','dark'),x,yy,z,side,
                          [(-.212,.121),(.171,.121),(.193,.142),(.215,.139),
                           (.232,.105),(.249,.082)],caps=True)
            wheel_surface(g,('Machined bearing covers','steel'),x,yy,z,side,
                          [(.245,.079),(.255,.076),(.262,.058)],seg=24,caps=True)
            for k in range(6):
                a=k*pi/3
                wheel_surface(g,('Fastener heads','lightmetal'),x+.102*cos(a),yy,z+.102*sin(a),side,
                              [(.227,.013),(.240,.012)],seg=6,caps=True)
            strut(g,('Suspension trailing arms','steel'),(x,cy-side*.244,z),
                  (x-.31,cy-side*.33,.76),.14,.14)
            wheel_surface(g,('Pivot bosses','dark'),x-.31,cy-side*.30,.76,side,
                          [(-.05,.105),(.056,.105)],seg=24,caps=True)
            wheel_surface(g,('Axle shoulders','steel'),x,cy-side*.21,z,side,
                          [(-.087,.115),(.005,.115)],seg=24,caps=True)
        for x in [-3.57,3.57]:
            z=.606
            # 17-pitch drive/end wheel with two flange rings and a dished five-spoke web.
            for dep in [-.152,.163]:
                nteeth=17
                rings=[]
                for d,inner in [(dep-.022,False),(dep+.022,False),
                                (dep+.022,True),(dep-.022,True)]:
                    pts=[]
                    for k in range(nteeth):
                        for frac,rad in [(0.,.335),(.23,.365),(.66,.365),(.88,.335)]:
                            r=.247 if inner else rad
                            a=2*pi*(k+frac)/nteeth
                            pts.append((x+r*cos(a),cy+side*d,z+r*sin(a)))
                    rings.append(pts)
                loops(g,('End wheel teeth','steel'),rings,True)
            wheel_surface(g,('End wheel rims','dark'),x,cy,z,side,
                          [(-.174,.235),(-.174,.295),(.184,.295),
                           (.200,.269),(.200,.238)],sealed=True)
            wheel_surface(g,('End wheel hubs','steel'),x,cy,z,side,
                          [(-.188,.102),(.218,.102),(.237,.086)],caps=True)
            for k in range(7):
                a=k*2*pi/7+.125
                r1,r2=.065,.265
                strut(g,('End wheel spokes','steel'),
                      (x+r1*cos(a),cy+side*.126,z+r1*sin(a)),
                      (x+r2*cos(a+.12),cy+side*.119,z+r2*sin(a+.12)),
                      .108,.073)
            for k in range(5):
                a=k*2*pi/5
                wheel_surface(g,('End flange bolts','lightmetal'),x+.065*cos(a),cy,z+.065*sin(a),side,
                              [(.235,.012),(.246,.012)],seg=6,caps=True)
        for x in [-2.05,0,2.05]:
            wheel_surface(g,('Upper return rollers','rubber'),x,cy,.858,side,
                          [(-.156,.108),(-.141,.116),(.146,.116),(.156,.108)],seg=28,caps=True)
    g.finish()

unit02_build_running_gear()
