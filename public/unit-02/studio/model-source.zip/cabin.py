"""Unit 02 interior. Metres in vehicle coordinates, z=1.20 finished floor."""

def build_broadcast_cabin():
    from math import sin, cos, tau, pi
    from mathutils import Vector

    group('Cabin')
    floor_z = 1.20

    # Small rolled and stamped details are combined by finish for a light export.
    batches = {}
    def add_faces(material, vertices, faces):
        coords, polygons = batches.setdefault(material, ([], []))
        first = len(coords)
        coords.extend(tuple(v) for v in vertices)
        polygons.extend(tuple(first + i for i in face) for face in faces)

    def detail_box(ctr, dims, material, basis=None):
        origin = Vector(ctr)
        axes = basis or ((1,0,0),(0,1,0),(0,0,1))
        u, v, w = [Vector(axis) * (length * .5) for axis, length in zip(axes, dims)]
        points = [origin + i*u + j*v + k*w for k in (-1,1) for j in (-1,1) for i in (-1,1)]
        faces = [(0,2,3,1),(4,5,7,6),(0,1,5,4),(1,3,7,5),(3,2,6,7),(2,0,4,6)]
        add_faces(material, points, faces)

    def frame(axis):
        normal = Vector(axis).normalized()
        seed = Vector((0,0,1)) if abs(normal.z) < .85 else Vector((0,1,0))
        u = seed.cross(normal).normalized()
        return u, normal.cross(u), normal

    def tube(a, b, radius, material, sides=10, end_radius=None):
        a, b = Vector(a), Vector(b)
        u, v, _ = frame(b-a)
        r2 = radius if end_radius is None else end_radius
        ring = [u*cos(tau*i/sides) + v*sin(tau*i/sides) for i in range(sides)]
        verts = [a + radius*p for p in ring] + [b + r2*p for p in ring]
        faces = [tuple(reversed(range(sides))), tuple(range(sides, sides*2))]
        faces += [(i,(i+1)%sides,sides+(i+1)%sides,sides+i) for i in range(sides)]
        add_faces(material, verts, faces)

    def arc_ring(center, axis, major, minor, material, start=0, end=tau, steps=40, cross=8):
        u, v, n = frame(axis)
        points, faces = [], []
        for i in range(steps + 1):
            theta = start + (end-start) * i / steps
            direction = u*cos(theta) + v*sin(theta)
            for j in range(cross):
                phi = tau*j/cross
                points.append(Vector(center) + direction*(major + minor*cos(phi)) + n*minor*sin(phi))
        for i in range(steps):
            for j in range(cross):
                a = i*cross + j
                b = i*cross + (j+1)%cross
                faces.append((a, a+cross, b+cross, b))
        if end-start < tau-.001:
            faces += [tuple(reversed(range(cross))), tuple(steps*cross+j for j in range(cross))]
        add_faces(material, points, faces)

    def bent_pipe(points, radius, material, sides=10):
        for a,b in zip(points,points[1:]):
            tube(a,b,radius,material,sides)

    def seat(title, x, y, driver=False):
        # Body space: u=right, v=forward. Operators face +y; driver faces -x.
        def p(u,v,h):
            return (x-v,y+u,h) if driver else (x+u,y+v,h)
        def piece(name, u, v, h, width, depth, height, material, bevel):
            dims = (depth,width,height) if driver else (width,depth,height)
            return box(title+' · '+name,p(u,v,h),dims,material,bevel)
        cyl(title+' · mounting flange',p(0,0,1.225),.175,.05,'Z','dark',32)
        cyl(title+' · swivel pedestal',p(0,0,1.42),.066,.36,'Z','steel',24)
        piece('slide rails',0,0,1.58,.37,.35,.085,'dark',.02)
        piece('seat pan',0,0,1.63,.50,.48,.09,'wood',.035)
        piece('foam seat',0,.007,1.69,.486,.465,.105,'upholstery',.045)
        # Back has a tapered silhouette and a deliberate six degree rake.
        def back_part(name,w,z0,z1,v0,v1,thick,material):
            widths=[w*.89,w,w,w*.91]; heights=[z0,z0+.045,z1-.045,z1]
            zs=[]; faces=[]
            for i,(ww,hh) in enumerate(zip(widths,heights)):
                vv = v0 + (v1-v0)*(hh-z0)/(z1-z0)
                zs.extend([p(-ww/2,vv,hh),p(ww/2,vv,hh),p(ww/2,vv+thick,hh),p(-ww/2,vv+thick,hh)])
            for i in range(3):
                for j in range(4):
                    a=4*i+j; b=4*i+(j+1)%4
                    faces.append((a,b,b+4,a+4))
            faces += [(3,2,1,0),(12,13,14,15)]
            mesh(title+' · '+name,zs,faces,material)
        back_top = 2.22 if driver else 2.12
        back_part('molded back shell',.47,1.72,back_top,-.245,-.296,.043,'wood')
        back_part('upholstered back',.437,1.75,back_top-.018,-.209,-.260,.053,'upholstery')
        for u in (-.16,.16):
            tube(p(u,-.085,1.605), p(u,-.237,1.79), .016, 'steel')
        # Subtle paired welt lines in the seat.
        for u in (-.16,.16):
            tube(p(u,-.149,1.742),p(u,.163,1.742),.0025,'teal',6)
        if driver:
            for u in (-.105,.105):
                tube(p(u,-.276,2.21),p(u,-.285,2.32),.009,'steel')
            piece('head restraint',0,-.286,2.345,.29,.105,.12,'upholstery',.045)

    # Driving position, housing and pedal box are all forward of the doorway.
    seat('Driving seat',-2.99,-.54,True)
    box('Driver footwell · heel plate',(-3.68,-.54,1.224),(.52,.60,.025),'dark',.008)
    for y,w in ((-.67,.095),(-.46,.065)):
        tube((-3.78,y,1.26),(-3.69,y,1.36),.017,'steel')
        box('Suspended pedal',(-3.69,y,1.375),(.095,w,.025),'rubber',.009)
    box('Cab · lower dashboard',(-3.77,-.20,1.85),(.48,1.67,.29),'teal',.04)
    box('Cab · padded instrument coaming',(-3.76,-.20,2.02),(.50,1.69,.082),'dark',.03)
    # Rear-facing dashboard with four distinct round instruments and telltales.
    box('Cab · instrument binnacle',(-3.518,-.50,1.923),(.022,.79,.144),'black',.009)
    for y,r in ((-.74,.052),(-.59,.052),(-.45,.040),(-.33,.040)):
        tube((-3.506,y,1.926),(-3.496,y,1.926),r,'lightmetal',28)
        tube((-3.496,y,1.926),(-3.492,y,1.926),r*.81,'black',24)
        tube((-3.490,y,1.926),(-3.489,y+r*.45,1.926+r*.38),.0025,'cream',6)
    for i in range(4):
        tube((-3.506,-.229+i*.026,1.938),(-3.500,-.229+i*.026,1.938),.006,'amber' if i<2 else 'red')
    # Steering wheel plane is pitched back towards the driver; three visible spokes.
    wheel = Vector((-3.39,-.54,1.99))
    normal=Vector((.76,0,.65)).normalized()
    wu,wv,_=frame(normal)
    tube((-3.59,-.54,1.72),wheel,.043,'dark',16)
    arc_ring(wheel,normal,.187,.017,'rubber',steps=44)
    for angle in (pi*.15,pi*.85,pi*1.5):
        end=wheel+wu*.173*cos(angle)+wv*.173*sin(angle)
        tube(wheel-normal*.020,end,.011,'steel')
    tube(wheel-normal*.027,wheel+normal*.012,.049,'rubber',18)
    for y in (.20,.32):
        tube((-3.46,y,1.62),(-3.42,y,1.90),.010,'steel')
        tube((-3.42,y,1.9),(-3.416,y,1.93),.022,'black')
    # Compact nav seat with a pad and folded route sheet.
    box('Navigation map ledge',(-3.39,.78,1.961),(.49,.92,.045),'wood',.012)
    box('Coast chart',(-3.36,.78,1.99),(.33,.51,.008),'cream',.004)
    for n in range(3):
        detail_box((-3.36,.66+.11*n,1.995),(.31,.003,.003),'teal')

    # A continuous worktop has a 740 mm working height and clears seated knees.
    desk0,desk1=-1.63,.96
    box('Studio · birch worktop',((desk0+desk1)/2,.989,1.9125),(desk1-desk0,.765,.055),'wood',.018)
    box('Studio · teal edge',((desk0+desk1)/2,.604,1.903),(desk1-desk0-.01,.012,.020),'teal',.003)
    for xi in (desk0+.04,desk1-.04):
        box('Studio · end cheek',(xi,.99,1.545),(.055,.69,.69),'wood',.012)
    box('Studio · cable chase',(-.32,1.28,1.75),(2.46,.12,.23),'dark',.014)
    seat('Presenter seat',-.86,.232)
    seat('Engineer seat',.27,.232)

    # Folded sloping mixer enclosure. The caps, dials and channel strips sit on its real plane.
    xmid, width, y0, y1 = -.54, 1.10, .666, 1.188
    mixer_lo, z0, z1 = 1.945, 1.985, 2.082
    def mix_z(y):
        return z0 + (z1-z0)*(y-y0)/(y1-y0)
    left,right=xmid-width/2,xmid+width/2
    vertices=[(left,y0,mixer_lo),(right,y0,mixer_lo),(right,y1,mixer_lo),(left,y1,mixer_lo),
              (left,y0,z0),(right,y0,z0),(right,y1,z1),(left,y1,z1)]
    faces=[(0,3,2,1),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)]
    mesh('Studio · broadcast console',vertices,faces,'dark')
    # Side cheeks follow the exact same slope.
    for frac in (-1,1):
        mid=xmid+frac*(width/2-.014)
        verts=[(mid+(-.014 if i in (0,3,4,7) else .014),p[1],p[2]+.006) for i,p in enumerate(vertices)]
        mesh('Studio · walnut console cheek',verts,faces,'wood')
    fwd=Vector((0,1,(z1-z0)/(y1-y0))).normalized()
    up=Vector((1,0,0)).cross(fwd).normalized()
    basis=[(1,0,0),fwd,up]
    for i in range(10):
        x=left+.069+(i*.080)
        y=.825
        detail_box((x,y,mix_z(y)+.002),(.005,.184,.003),'lightmetal',basis)
        y=.768+((i*3)%8)*.013
        detail_box((x,y,mix_z(y)+.008),(.047,.023,.013),'cream' if i<8 else 'orange',basis)
        for n in range(3):
            y=.984+n*.068
            origin=Vector((x,y,mix_z(y)+.003))
            tube(origin,origin+up*.018,.014,'steel' if n<2 else 'teal',12)
        y=.702
        detail_box((x,y,mix_z(y)+.005),(.027,.016,.006),'red' if i%3==0 else 'amber',basis)
    for y in (.98,1.085):
        detail_box((right-.133,y,mix_z(y)+.004),(.171,.081,.007),'cream',basis)
        for n in range(6):
            detail_box((right-.20+n*.022,y+.013,mix_z(y+.013)+.010),(.003,.013,.003),'dark',basis)
        detail_box((right-.126,y,mix_z(y)+.012),(.004,.058,.003),'red',basis)

    # Two independent spring-balanced parallelogram booms. A short cable loop
    # falls from each capsule. The sockets stay on the bench, not the roof.
    for n,(mount_x,tip_x) in enumerate(((-1.375,-.85),(.804,.28))):
        p=(mount_x,1.211,2.045); q=(mount_x,.995,2.445); r=(tip_x,.657,2.37)
        tube((mount_x,1.211,1.94),p,.027,'steel',16)
        tube((mount_x,1.211,1.946),(mount_x,1.211,1.961),.052,'black',18)
        for offset in (-.013,.013):
            bent_pipe([(p[0]+offset,p[1],p[2]),(q[0]+offset,q[1],q[2]),(r[0]+offset,r[1],r[2])],.007,'dark',8)
        for v in (p,q,r):
            tube((v[0]-.025,v[1],v[2]),(v[0]+.025,v[1],v[2]),.020,'steel')
        bent_pipe([(r[0],r[1],r[2]),(r[0],r[1]-.035,r[2]-.032),(r[0],r[1]-.041,r[2]-.061)],.007,'dark')
        a=Vector((r[0],r[1]-.028,r[2]-.04))
        b=Vector((r[0],r[1]-.118,r[2]-.09))
        tube(a,b,.024,'black',18)
        tube(b,b+(b-a).normalized()*.041,.028,'steel',18)
        bent_pipe([a,(a.x,a.y+.045,a.z-.056),(a.x,a.y+.10,a.z-.043),(a.x,a.y+.125,a.z+.026)],.0034,'rubber',6)

    # Compact turntable, LP bin, headphones on their stand and nearfield monitor.
    box('Studio · turntable plinth',(.355,.991,1.974),(.48,.36,.065),'dark',.016)
    cyl('Studio · record platter',(.308,.994,2.014),.147,.012,'Z','lightmetal',40)
    cyl('Studio · twelve inch disc',(.308,.994,2.025),.143,.007,'Z','black',48)
    cyl('Studio · record label',(.308,.994,2.031),.044,.004,'Z','orange',28)
    cyl('Studio · spindle',(.308,.994,2.036),.006,.012,'Z','steel',10)
    bent_pipe([(.545,1.119,2.029),(.529,1.057,2.045),(.449,.955,2.04)],.004,'lightmetal',8)
    detail_box((.445,.949,2.038),(.020,.028,.011),'black')
    # Records nest in a low cabinet between the print desk and sleeping module.
    box('Archive · LP cubby',(1.695,.999,1.428),(.386,.52,.429),'wood',.015)
    box('Archive · cubby opening',(1.695,.732,1.454),(.329,.018,.342),'dark',.004)
    for n in range(20):
        color=('cream','teal','orange','dark','white','red','wood')[n%7]
        detail_box((1.543+n*.0155,.716+(n%3)*.0018,1.46),(.011,.026,.285-(n%4)*.006),color)

    for xidx,x in enumerate((-1.42,.70)):
        box('Studio · monitor cabinet',(x,1.248,2.114),(.223,.191,.338),'wood',.014)
        box('Studio · monitor grille',(x,1.146,2.112),(.191,.019,.296),'dark',.006)
        for z,r in ((2.075,.065),(2.207,.024)):
            tube((x,1.139,z),(x,1.132,z),r,'rubber',24)
            tube((x,1.131,z),(x,1.125,z),r*.40,'steel',16)
    # Headphones standing vertically at the entry end of the worktop.
    hx,hy,hz=-1.386,.806,2.143
    tube((hx,hy,1.943),(hx,hy,2.248),.009,'steel')
    tube((hx,hy,1.943),(hx,hy,1.955),.062,'dark',20)
    # Arched band in x-z; the frame's +v points up because normal is +y.
    arc_ring((hx,hy,hz),(0,1,0),.094,.009,'dark',start=0,end=pi,steps=22)
    for sign in (-1,1):
        tube((hx+sign*.080,hy,hz-.012),(hx+sign*.103,hy,hz-.012),.044,'rubber',18)
    # Field bulletin printer with output sheet, roll and hand controls.
    box('Print · work surface',(1.48,1.038,1.9125),(.96,.66,.055),'wood',.015)
    box('Print · side panel',(1.929,1.033,1.55),(.047,.628,.70),'wood',.01)
    box('Print · duplicator body',(1.435,1.062,2.073),(.54,.432,.262),'cream',.035)
    box('Print · ink rail',(1.435,1.213,2.220),(.475,.10,.100),'teal',.023)
    box('Print · feed throat',(1.435,.841,2.067),(.402,.016,.035),'dark',.004)
    # Exit tray and a sheet with masthead and column marks facing the aisle.
    box('Print · paper tray',(1.435,.737,2.041),(.43,.207,.014),'dark',.005)
    detail_box((1.424,.735,2.052),(.348,.184,.006),'white')
    detail_box((1.424,.668,2.057),(.258,.015,.002),'teal')
    for j in range(6):
        for x in (1.35,1.494):
            detail_box((x,.69+j*.017,2.057),(.118-(j%3)*.008,.003,.0015),'steel')

    # The two stock mattress envelopes are exactly 1950 x 720 mm.
    bx,by=3.025,.84
    for upper,z in ((False,1.57),(True,2.405)):
        box('Bunk · laminated ply berth',(bx,by,z-.035),(2.01,.78,.07),'wood',.019)
        box('Bunk · ventilated mattress',(bx,by,z+.073),(1.95,.72,.146),'cream',.047)
        box('Bunk · wool cover',(bx-.18,by,z+.148),(1.43,.718,.034),'upholstery' if not upper else 'red',.014)
        for i in range(3):
            box('Bunk · woven blanket stripe',(bx+.25+i*.045,by,z+.167),(.020,.697,.004),'amber' if i!=1 else 'cream',.0015)
        box('Bunk · stitched pillow',(3.743,by,z+.172),(.43,.52,.13),'cream',.052)
        # Rounded rear reading light, its mount is on the bed end panel.
        tube((3.991,1.016,z+.38),(3.916,1.016,z+.38),.029,'steel',14)
        tube((3.918,1.016,z+.38),(3.875,1.016,z+.363),.039,'teal',16)
        tube((3.875,1.016,z+.363),(3.87,1.016,z+.361),.030,'lamp',16)
    for x in (2.046,4.005):
        for y in (.496,1.185):
            box('Bunk · corner post',(x,y,2.099),(.046,.048,1.79),'wood',.008)
    # Luggage lockers beneath lower berth.
    box('Berths · underbed locker carcass',(3.029,.84,1.37),(1.916,.70,.318),'wood',.014)
    for x in (2.39,3.018,3.646):
        box('Berths · locker front',(x,.482,1.377),(.59,.025,.26),'teal',.012)
        detail_box((x,.465,1.444),(.093,.009,.020),'dark')
    # A removable guard stops short at the foot for the vertical ladder.
    for x in (2.64,3.72):
        tube((x,.460,2.389),(x,.460,2.739),.013,'steel',12)
    tube((2.64,.460,2.73),(3.72,.460,2.73),.016,'steel',14)
    tube((2.64,.460,2.613),(3.72,.460,2.613),.010,'steel',10)
    for x in (2.119,2.45):
        tube((x,.405,1.222),(x,.405,2.477),.013,'lightmetal',12)
    for i in range(4):
        z=1.43+i*.263
        tube((2.119,.405,z),(2.45,.405,z),.013,'lightmetal',12)

    for finish,(vertices,faces) in batches.items():
        mesh('Cabin hardware · '+finish,vertices,faces,finish)

build_broadcast_cabin()
