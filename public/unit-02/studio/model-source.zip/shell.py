# Unit 02 • removable upper body, glazing and deployed boarding stair.
import math, bpy
from mathutils import Vector

def build_shell():
    pi = math.pi
    sin, cos = math.sin, math.cos
    from pathlib import Path
    def local_font(path):
        return bpy.data.fonts.load(path, check_existing=True) if Path(path).is_file() else None
    bold = local_font('/usr/share/fonts/truetype/open-sans/OpenSans-CondBold.ttf')
    mono = local_font('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf')
    def mark(name, body, pos, size, color, side=-1, style=None):
        o = text_obj(name, body, pos, size, color,
                     rotation=(pi/2, 0, 0 if side < 0 else pi), align='CENTER')
        if o is not None and o.type == 'FONT':
            if style or bold: o.data.font = style or bold
            o.data.align_y = 'CENTER'
            o.data.space_character = 1.02
        return o

    # All side pieces are closed solids. Winding is adapted to the outer face.
    def plate(name, points, side, color, thickness=.07, surface=1.45):
        pts=list(points)
        area=sum(x*z2-x2*z for (x,z),(x2,z2) in zip(pts, pts[1:]+pts[:1]))
        if (area>0) != (side<0):
            pts.reverse()
        n=len(pts)
        v=[(x, side*y, z) for y in [surface,surface-thickness] for x,z in pts]
        faces=[tuple(range(n)),tuple(range(2*n-1,n-1,-1))]
        faces.extend((i+n,(i+1)%n+n,(i+1)%n,i) for i in range(n))
        return mesh(name,v,faces,color)
    def plain(name, xmin, xmax, zmin, zmax, side, color, thick=.07, surface=1.45):
        return plate(name,[(xmin,zmin),(xmax,zmin),(xmax,zmax),(xmin,zmax)],side,color,thick,surface)
    def holepanel(name,l,r,b,t,cx,cz,rad,side,color,surface=1.45,thick=.07):
        # The continuous rim joins a circular opening to a rectangular skin panel.
        a=sorted({round(k*2*pi/40,9) for k in range(40)} |
                 {round(math.atan2(z-cz,x-cx)%(2*pi),9) for x in (l,r) for z in (b,t)})
        loops=[[],[]]
        for ang in a:
            dx,dz=cos(ang),sin(ang)
            tx=(r-cx if dx>0 else l-cx)/dx if abs(dx)>1e-8 else 1e8
            tz=(t-cz if dz>0 else b-cz)/dz if abs(dz)>1e-8 else 1e8
            d=min(tx,tz)
            loops[0].append((cx+d*dx,cz+d*dz))
            loops[1].append((cx+rad*dx,cz+rad*dz))
        if side>0:
            loops=[list(reversed(q)) for q in loops]
        n=len(a)
        v=[(x,side*y,z) for y in (surface,surface-thick) for lp in loops for x,z in lp]
        f=[]
        for i in range(n):
            j=(i+1)%n
            f.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),
                      (i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
        return mesh(name,v,f,color)
    def ring(name,x,z,side,outer,inner,surface,thickness,material):
        n=40
        angles=[i*2*pi/n for i in (range(n) if side<0 else reversed(range(n)))]
        v=[(x+rr*cos(a),side*y,z+rr*sin(a)) for y in (surface,surface-thickness)
           for rr in (outer,inner) for a in angles]
        f=[]
        for i in range(n):
            j=(i+1)%n
            f.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),
                      (i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
        mesh(name,v,f,material)
    def port(x,z,side,r,base):
        ring("Porthole • rolled retaining ring",x,z,side,r+.026,r-.006,base+.021,.042,'lightmetal')
        ring("Porthole • rubber seal",x,z,side,r-.004,r-.022,base+.010,.037,'rubber')
        cyl("Porthole • glazing",(x,side*(base-.011),z),r-.020,.012,'Y','glass',48)
    def grab(name, xyz, side):
        x,y,z=xyz
        p=[(x,side*y,z-.24),(x,side*(y+.072),z-.21),(x,side*(y+.072),z+.21),(x,side*y,z+.24)]
        for a,b in zip(p,p[1:]): rod(name,a,b,.017,'lightmetal')
    for side in (-1,1):
        group('Near shell' if side<0 else 'Far shell')
        l,d1,d2,r=-4.2,-2.50,-1.64,4.20
        # Main forward side wall and slim trapezoidal cab quarter window.
        pts=[(l,1.20),(d1,1.20),(d1,2.35),(-4.095,2.35),(l,2.05)]
        plate('Cab side • lower quarter',pts,side,'red')
        for x0,x1,z0,z1,c in [(d2,r,1.20,2.35,'red'),(d2,r,2.35,2.417,'teal')]:
            plain('Body • waist panel',x0,x1,z0,z1,side,c)
        plate("Cab side • belt", [(-4.095,2.35),(d1,2.35),(d1,2.417),(-4.072,2.417)], side,'teal')
        # Four structural infill polygons surround the offset quarterlight.
        outer=[(-4.072,2.417),(d1,2.417),(d1,3.28),(-3.77,3.28)]
        inner=[(-3.967,2.485),(-2.735,2.485),(-2.735,3.145),(-3.727,3.145)]
        for i in range(4):
            j=(i+1)%4
            plate('Cab quarter • surround',[outer[i],outer[j],inner[j],inner[i]],side,'cream')
        pane=[(-3.915,2.524),(-2.773,2.524),(-2.773,3.108),(-3.703,3.108)]
        for i in range(4):
            j=(i+1)%4
            plate('Cab quarter • gasket',[inner[i],inner[j],pane[j],pane[i]],side,'rubber',.023,1.451)
        plate('Cab quarter • glass',pane,side,'glass',.012,1.447)
        # Fill cabin upper panels; the far wall has a continuous structural door bay.
        if side==1:
            plain('Blanked crew bay',d1,d2,1.2,2.35,side,'red')
            plain('Blanked crew bay • belt',d1,d2,2.35,2.417,side,'teal')
            plain('Blanked crew bay • upper',d1,d2,2.417,3.28,side,'cream')
        else:
            plain('Door reveal • header',d1,d2,3.185,3.28,side,'cream')
            for x in [d1+.009,d2-.009]:
                box('Door • perimeter bulb seal',(x,-1.445,2.19),(.018,.064,1.98),'rubber',.004)
            # The door leaf is separately modeled and sits inside the actual wall aperture.
            dl,dr,ds=-2.479,-1.661,1.462
            plain('Boarding door • lower leaf',dl,dr,1.215,2.35,side,'red',.061,ds)
            plain('Boarding door • belt',dl,dr,2.35,2.417,side,'teal',.061,ds)
            holepanel('Boarding door • upper leaf',dl,dr,2.417,3.163,-2.07,2.785,.162,side,'cream',ds,.061)
            plain('Boarding door • header seal',d1,d2,3.164,3.182,side,'rubber',.04,1.443)
            port(-2.07,2.785,side,.162,ds)
            for z in (1.57,2.83):
                box('Door • hinge strap',(dl+.055,-1.476,z),(.17,.039,.051),'lightmetal',.008)
                cyl('Door • knuckle',(dl+.006,-1.497,z),.019,.084,'Z','steel',16)
            box('Door • latch escutcheon',(dr-.083,-1.480,2.11),(.052,.021,.094),'steel',.009)
            box('Door • pull lever',(dr-.126,-1.507,2.12),(.125,.037,.023),'lightmetal',.007)
            grab('Boarding • exterior handhold',(-1.55,1.471,2.01),side)
            box('Entry • drip rail',(-2.07,-1.484,3.215),(.96,.083,.032),'lightmetal',.01)
        centers=[-.92,.55,2.02,3.49]
        edges=[d2]+[(a+b)/2 for a,b in zip(centers,centers[1:])]+[r]
        for i,cx in enumerate(centers):
            holepanel('Body • porthole bay '+str(i+1),edges[i],edges[i+1],2.417,3.28,cx,2.78,.222,side,'cream')
            port(cx,2.78,side,.222,1.45)
        # Locally painted numbers and two lines of identifying type.
        ys=side*1.456
        def sx(x): return x if side<0 else 2.36-x
        mark('Livery • fleet number','02',(sx(-.87),ys,1.86),.81,'cream',side)
        mark('Livery • station','EL SEGUNDO',(sx(.87),ys,1.965),.39,'cream',side)
        mark('Livery • callsign','POINTCAST   /   FIELD BROADCAST',(sx(.87),ys,1.66),.084,'cream',side,mono)
        # Gasketed service hatch with corner screws and two compression latches.
        hx=3.24
        if side>0: hx=-.86
        box('Side • service hatch gasket',(hx,side*1.455,1.625),(1.01,.025,.58),'rubber',.025)
        box('Side • service hatch skin',(hx,side*1.472,1.625),(.981,.025,.549),'red',.023)
        for x in (hx-.36,hx+.36):
            box('Flush hatch latch',(x,side*1.493,1.82),(.089,.018,.024),'lightmetal',.004)
        for i in range(6):
            box('Service bay • grille slot',(hx,side*1.490,1.48+.037*i),(.46,.015,.014),'dark',.004)
        box('Body • lower rub strip',(0,side*1.458,1.235),(8.36,.027,.050),'steel',.005)
        # Combined fastener geometry to avoid excessive object and draw counts.
        riv=[]
        for i in range(51):
            x=-4.13+.165*i
            if side==-1 and d1-.03<x<d2+.03: continue
            riv.extend([(x,1.29),(x,2.31)])
            if x> -3.73:riv.append((x,3.218))
        for x in (d2+.045,-.17,1.29,2.76,4.145):
            for z in (1.40,1.55,2.19,2.51,2.68,2.91,3.08): riv.append((x,z))
        v=[]; f=[]
        for x,z in riv:
            k=len(v)
            for dy,rr in ((.001,.010),(.005,.007)):
                for i in range(6):
                    aa=i*pi/3
                    v.append((x+rr*cos(aa),side*(1.45+dy),z+rr*sin(aa)))
            for i in range(6):
                f.append((k+i,k+(i+1)%6,k+6+(i+1)%6,k+6+i))
            f.append(tuple(k+6+i for i in range(6)))
        mesh('Body • flush rivet runs',v,f,'lightmetal')

    group('Ends')
    box('Tail • lower panel',(4.169,0,1.775),(.062,2.89,1.15),'red',.021)
    box('Tail • belt',(4.169,0,2.3835),(.062,2.89,.067),'teal',.004)
    box('Tail • top panel',(4.169,0,2.8485),(.062,2.89,.863),'cream',.017)
    for yy in (-1.18,1.18):
        box("Rear marker surround",(4.207,yy,1.52),(.031,.19,.10),'rubber',.011)
        box("Rear marker lens",(4.231,yy,1.52),(.028,.153,.071),'orange',.011)
    box('Nose • lower panel',(-4.153,0,1.625),(.094,2.90,.85),'red',.027)
    box('Front • bumper',(-4.210,0,1.24),(.135,2.80,.109),'steel',.024)
    for yy in (-1.13,1.13):
        cyl('Front lamp • barrel',(-4.229,yy,1.51),.138,.109,'X','rubber',32)
        cyl('Front lamp • brass bezel',(-4.289,yy,1.51),.119,.026,'X','lightmetal',32)
        cyl('Front lamp • lens',(-4.305,yy,1.51),.099,.014,'X','lamp',32)
        for q in (-.044,.044):
            rod('Front lamp • cage',(-4.325,yy+q,1.421),(-4.325,yy+q,1.599),.0055,'steel')
    # Each pane has an individual rubber glazing bead and a raised wiping blade.
    def front(z):
        return -4.2+(z-2.05)*(.43/1.23)
    def wind(name, p, col, out=0, depth=.054):
        v=[(front(z)+d,y,z) for d in (-out,depth-out) for y,z in p]
        n=len(p); fs=[tuple(reversed(range(n))),tuple(range(n,2*n))]
        fs.extend((i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n))
        return mesh(name,v,fs,col)
    def windrect(name,y0,y1,z0,z1,col,out=0,depth=.054):
        return wind(name,[(y0,z0),(y1,z0),(y1,z1),(y0,z1)],col,out,depth)
    windrect('Nose • red apron',-1.45,1.45,2.05,2.35,'red')
    windrect('Nose • side belt',-1.45,1.45,2.35,2.417,'teal')
    windrect('Windshield • scuttle',-1.45,1.45,2.417,2.48,'cream')
    windrect('Windshield • header',-1.45,1.45,3.145,3.28,'cream')
    for i in range(4):
        a=-1.40+i*.70; b=a+.70
        windrect('Windshield • pillar',a,a+.048,2.48,3.145,'cream')
        for l0,r0,b0,t0 in [(a+.048,b-.010,2.48,2.507),(a+.048,b-.010,3.118,3.145),
                             (a+.048,a+.067,2.507,3.118),(b-.029,b-.010,2.507,3.118)]:
            windrect('Windshield • rubber seal',l0,r0,b0,t0,'rubber',.005,.035)
        windrect('Windshield • laminated glass',a+.067,b-.029,2.507,3.118,'glass',.002,.014)
        windrect('Windshield • pillar',b-.010,b,2.48,3.145,'cream')
        rod('Wiper • arm',(front(2.489)-.045,a+.16,2.489),(front(2.84)-.046,a+.43,2.84),.009,'black')
        rod('Wiper • blade',(front(2.708)-.052,a+.325,2.708),(front(2.995)-.052,a+.551,2.995),.012,'rubber')
    for a,b in [(-1.45,-1.4),(1.4,1.45)]:
        windrect('Windshield • corner post',a,b,2.48,3.145,'cream')
    for z in (1.69,1.864):
        pts=[(-.57,z+.10),(0,z-.075),(.57,z+.10),(.57,z+.169),(0,z-.006),(-.57,z+.169)]
        mesh('Nose • cream chevron',[(-4.203,y,h) for y,h in pts],[list(reversed(range(6)))],'cream')

    group('Roof')
    # Rectangular roof starts above the sloping header, leaving the glazing exposed.
    box('Roof • insulated deck',(.215,0,3.33),(7.97,2.90,.10),'cream',.044)
    for yy in (-1.442,1.442):
        box('Roof • drip gutter',(.216,yy,3.296),(7.967,.055,.052),'lightmetal',.012)
    for x in (-2.30,-.83,.64,2.11,3.58):
        box('Roof • lock seam',(x,0,3.382),(.028,2.79,.018),'cream',.007)
    box('Roof • egress hatch gasket',(2.91,.04,3.392),(.91,.91,.04),'rubber',.028)
    box('Roof • egress hatch',(2.91,.04,3.43),(.88,.88,.065),'cream',.034)
    for y in (-.25,.25):
        box('Hatch • hinge',(3.34,y,3.448),(.07,.14,.035),'lightmetal',.01)
    for y in (-.8,.8):
        box('Roof • vent plinth',(-2.18,y,3.404),(.50,.40,.062),'steel',.025)
        box('Roof • cowl',(-2.18,y,3.451),(.54,.44,.06),'cream',.026)
    for y in (-1.06,-.5,.5,1.06):
        box('Roof • clearance marker base',(-3.65,y,3.392),(.12,.106,.022),'rubber',.009)
        box('Roof • clearance marker lens',(-3.67,y,3.415),(.102,.081,.033),'amber',.014)
    mastx,masty=.48,.14
    box('Antenna • foot',(mastx,masty,3.414),(.41,.38,.07),'teal',.022)
    for z0,z1,rr,c in [(3.44,3.81,.073,'teal'),(3.80,4.27,.053,'lightmetal'),
                        (4.25,4.66,.041,'steel'),(4.64,4.99,.029,'lightmetal')]:
        cyl('Antenna • telescopic stage',(mastx,masty,(z0+z1)/2),rr,z1-z0,'Z',c,24)
        cyl('Antenna • compression collar',(mastx,masty,z1-.012),rr+.009,.031,'Z','dark',24)
    cyl('Antenna • beacon guard',(mastx,masty,5.027),.065,.096,'Z','steel',24)
    cyl('Antenna • amber beacon',(mastx,masty,5.095),.047,.059,'Z','amber',24)
    for xx, yy in ((-1.35,-1.22),(-1.35,1.22),(2.24,-1.22),(2.24,1.22)):
        box('Antenna • stay pad',(xx,yy,3.405),(.120,.097,.035),'steel',.007)
        rod('Antenna • guy wire',(xx,yy,3.426),(mastx,masty,4.69),.0065,'steel')
    group('Access steps')
    # A removable deployed flight. Five treads + door sill = six equal 200 mm rises.
    xc=-2.07
    for n in range(5):
        zz=.20*(n+1)
        yy=-2.74+.253*n
        box('Boarding • tread '+str(n+1),(xc,yy,zz-.024),(.77,.251,.048),'steel',.010)
        box('Boarding • nosing',(xc,yy-.112,zz+.002),(.758,.029,.009),'orange',.003)
        for off in (-.065,-.018,.029,.076):
            box('Boarding • anti-slip bar',(xc,yy+off,zz+.005),(.705,.014,.008),'dark',.002)
    for ss in (-1,1):
        xx=xc+ss*.368
        rod('Boarding • flight stringer',(xx,-2.83,.130),(xx,-1.50,1.174),.029,'steel')
        box('Boarding • ground foot',(xx,-2.77,.035),(.13,.22,.065),'rubber',.012)
        rod('Boarding • foot leg',(xx,-2.77,.045),(xx,-2.77,.19),.023,'steel')
        rod('Boarding • sill bracket',(xx,-1.61,1.083),(xx,-1.447,1.166),.026,'lightmetal')
    # One continuous handrail leaves the camera-facing end of each tread visible.
    xx=xc+.353
    for yy,zt,zb in [(-2.72,1.05,.205),(-1.54,1.97,1.12)]:
        rod('Boarding • rail stanchion',(xx,yy,zb),(xx,yy,zt),.019,'lightmetal')
    rod('Boarding • handrail',(xx,-2.72,1.05),(xx,-1.54,1.97),.025,'lightmetal')

build_shell()
