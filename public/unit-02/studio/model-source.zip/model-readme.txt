UNIT 02 WORKS
El Segundo mobile broadcast station / metric layout study
Public workroom   https://pointcast.xyz/loom/topic/unit-02

Open Unit-02-Workshop.blend in Blender 4.3 or later. The Outliner separates the near wall, far wall, roof, structural ends, boarding stair, cabin, deck, scale figure, chassis and tracks. Switch off Near shell and Roof to look into the radio room. Individual parts retain their names in the editable scene.

Body dimensions are 8.40 m long and 2.90 m wide. The finished deck is 1.20 m above the ground. Clear height to the structural roof underside is 2.08 m. The 0.70 m reserved aisle follows the side opposite the radio desk. The scale figure is 1.78 m tall. The five deployed treads add to the model footprint. These dimensions describe the layout model. Mass, drive performance, structural loads, access compliance and a full-scale construction design have not been assessed.

Rebuild from the scripts with Blender 4.3+:
    blender -b -P master.py -- --editable-only
    blender -b -P master.py -- --model-only
    blender -b -P master.py

The first command rebuilds the individually editable scene. The second exports the grouped glTF file. The third exports glTF and renders the exterior, cutaway and inside camera views. Keep all four Python files together. Installed Open Sans Condensed and DejaVu Sans Mono are used where available; otherwise the script uses Blender's bundled lettering. The supplied scene embeds its fonts.

Model coordinates are metres. The nose points toward negative X. Negative Y is the entry side. Z is up. The body envelope excludes the deployed stair, outboard lamps, trim and mast.
