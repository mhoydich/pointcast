import bpy,sys,math,os,time,bmesh
from pathlib import Path
from mathutils import Vector, Matrix
from math import sin,cos,pi
bp=bpy
D=Path(__file__).resolve().parent
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'
scene.unit_settings.length_unit='METERS'
def lin(c):
    c=c/255
    return c/12.92 if c<.04045 else ((c+.055)/1.055)**2.4
def rgba(c):
    return tuple(lin(int(c[p:p+2],16)) for p in (0,2,4))+(1.,)
paints={
'cream':('f1e2c3',.15,.38),'red':('bb432f',.18,.33),'teal':('175355',.22,.37),
'dark':('34454a',.38,.42),'rubber':('272f31',.01,.75),'steel':('626e70',.64,.38),
'lightmetal':('bfc7be',.76,.28),'glass':('759a9f',.12,.16),'black':('202629',.18,.53),
'orange':('f68837',.13,.45),'white':('f7eed8',.05,.54),'wood':('d7a66c',.01,.53),
'upholstery':('2d6966',.01,.73),'amber':('f9ab4f',.11,.26),'lamp':('ffdfa6',.05,.3),
'floor':('626a63',.15,.63),'figure':('bc7954',.10,.47),'weave':('947459',.02,.83)}
materials={}
def mat(name):
    if isinstance(name,bpy.types.Material):return name
    if name in materials: return materials[name]
    col,metal,rough=paints[name]
    m=bpy.data.materials.new(name);m.use_nodes=True
    s=m.node_tree.nodes.get('Principled BSDF')
    m.diffuse_color=rgba(col)
    s.inputs['Base Color'].default_value=rgba(col)
    s.inputs['Metallic'].default_value=metal
    s.inputs['Roughness'].default_value=rough
    if name=='glass':
        s.inputs['Alpha'].default_value=.37
        m.diffuse_color=(*rgba(col)[:3],.37)
        m.surface_render_method='DITHERED'
    if name in ('amber','lamp'):
        s.inputs['Emission Color'].default_value=rgba(col)
        s.inputs['Emission Strength'].default_value=.45 if name=='amber' else .70
    materials[name]=m;return m
assemblies={}
active=None
def group(name):
    global active
    if name not in assemblies:
        c=bpy.data.collections.new(name)
        scene.collection.children.link(c)
        e=bpy.data.objects.new(name,None);c.objects.link(e)
        e.empty_display_type='PLAIN_AXES';e.empty_display_size=.13
        assemblies[name]=(c,e)
    active=assemblies[name]
    return active[1]
def newobj(name,data):
    o=bpy.data.objects.new(name,data);active[0].objects.link(o);o.parent=active[1]
    return o
def mesh(name,vertices,faces,material):
    m=bpy.data.meshes.new(name);m.from_pydata(vertices,[],faces);m.update()
    o=newobj(name,m);m.materials.append(mat(material));return o
def box(name,center,size,material,bevel=0):
    sx,sy,sz=[v*.5 for v in size]
    pts=[(x*sx,y*sy,z*sz) for x,y,z in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
    o=mesh(name,pts,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],material)
    o.location=center
    if bevel:
        b=o.modifiers.new('Edge radius','BEVEL');b.width=min(bevel,min(size)*.49);b.segments=3
        n=o.modifiers.new('Face normals','WEIGHTED_NORMAL')
    return o
def cyl(name,center,radius,depth,axis='Z',material='steel',verts=32):
    pts=[(radius*cos(i*2*pi/verts),radius*sin(i*2*pi/verts),z) for z in (-depth/2,depth/2) for i in range(verts)]
    fs=[tuple(reversed(range(verts))),tuple(range(verts,verts*2))]+[(i,(i+1)%verts,(i+1)%verts+verts,i+verts) for i in range(verts)]
    o=mesh(name,pts,fs,material);o.location=center
    for p in list(o.data.polygons)[2:]:p.use_smooth=True
    if axis=='X':o.rotation_euler.y=pi/2
    elif axis=='Y':o.rotation_euler.x=pi/2
    return o
def rod(name,a,b,radius,material):
    aa,bb=Vector(a),Vector(b);d=bb-aa
    o=cyl(name,(aa+bb)*.5,radius,d.length,'Z',material,14)
    if d.length>1e-8:o.rotation_euler=d.to_track_quat('Z','Y').to_euler()
    return o
def text_obj(name,body,location,size,material,rotation=(0,0,0),align='CENTER',font=None):
    f=bpy.data.curves.new(name,'FONT');f.body=body;f.size=size;f.align_x=align;f.resolution_u=5
    if font:f.font=font if isinstance(font,bpy.types.VectorFont) else bpy.data.fonts.load(font,check_existing=True)
    o=newobj(name,f);o.location=location;o.rotation_euler=rotation;f.materials.append(mat(material));return o
def runfile(n):
    exec(compile((D/n).read_text(),str(D/n),'exec'),globals())
group('Deck')
box('Insulated floor cassette',(0,0,1.1325),(8.40,2.90,.115),'dark',.025)
box('Finished resilient deck',(0,0,1.195),(8.38,2.86,.010),'floor',.003)
for x in [-3.28,-2.52,-1.64,-.75,.14,1.03,1.92,2.81,3.70]:
    box('Access floor seam',(x,0,1.2005),(.006,2.75,.001),'dark')
for n in ['gear.py','shell.py','cabin.py']:runfile(n)

group('Scale figure')
# Articulated survey figure, standing alongside the mixing position in the aisle.
# A single closed loft per part keeps the silhouette readable and gives the scale a physical reference.
def loft(name,loops,material,segments=24):
    vertices=[(cx+rx*cos(i*2*pi/segments),cy+ry*sin(i*2*pi/segments),z) for cx,cy,z,rx,ry in loops for i in range(segments)]
    last=(len(loops)-1)*segments
    faces=[tuple(reversed(range(segments))),tuple(range(last,last+segments))]
    for j in range(len(loops)-1):
        k=j*segments
        faces += [(k+i,k+(i+1)%segments,k+(i+1)%segments+segments,k+i+segments) for i in range(segments)]
    o=mesh(name,vertices,faces,material)
    for p in o.data.polygons:p.use_smooth=True
    return o
fx,fy,fz=1.38,-.79,1.20
def form(name,rows,material='figure'):
    if any(tag in name for tag in ('shin','thigh','knee','hip')): material='dark'
    if any(tag in name for tag in ('torso','upper arm')): material='orange'
    if 'boot' in name: material='rubber'
    return loft(name,[(fx+x,fy+y,fz+z,rx,ry) for x,y,z,rx,ry in rows],material)
def ball(name,x,y,z,rx,ry,rz,material='figure'):
    return form(name,[(x,y,z+rz*sin(phi),max(.001,rx*cos(phi)),max(.001,ry*cos(phi))) for phi in [-pi/2,-1.21,-.84,-.45,0,.45,.84,1.21,pi/2]],material)
for sign in (-1,1):
    hip=.096*sign;knee=.105*sign;heel=.123*sign
    offset=.037*sign
    form('Scale · boot',[(heel,offset+.052,0,.061,.121),(heel,offset+.043,.043,.063,.139),(heel,offset+.017,.084,.057,.103),(heel,offset,.113,.044,.052)])
    form('Scale · shin',[(heel,offset,.096,.036,.043),(heel,offset-.008,.19,.045,.054),(knee,offset-.019,.344,.065,.068),(knee,offset,.473,.049,.055)])
    ball('Scale · knee',knee,offset,.49,.052,.053,.052,'weave')
    form('Scale · thigh',[(knee,offset,.513,.05,.052),(hip,0,.66,.073,.076),(hip,0,.81,.087,.083),(hip,0,.902,.077,.077)])
form('Scale · hip',[(0,0,.813,.143,.078),(0,0,.88,.179,.106),(0,0,.967,.163,.098),(0,0,1.03,.125,.081)])
form('Scale · torso',[(0,0,1.004,.123,.084),(0,0,1.125,.137,.09),(0,.008,1.27,.185,.114),(0,.003,1.396,.198,.109),(0,0,1.437,.151,.077),(0,0,1.48,.064,.054)])
form('Scale · neck',[(0,0,1.438,.061,.052),(0,.002,1.523,.052,.052)],'weave')
form('Scale · head',[(0,.026,1.504,.041,.053),(0,.023,1.546,.071,.073),(0,.005,1.604,.087,.094),(0,0,1.663,.089,.092),(0,-.004,1.725,.078,.083),(0,-.002,1.762,.052,.058),(0,.001,1.780,.005,.008)])
for sign in (-1,1):
    form('Scale · upper arm',[(.185*sign,0,1.404,.058,.062),(.213*sign,-.004,1.317,.065,.063),(.232*sign,.006,1.192,.05,.05),(.248*sign,.013,1.10,.039,.041)])
    ball('Scale · elbow',.247*sign,.016,1.087,.039,.041,.042,'weave')
    dy=.09 if sign<0 else .018
    form('Scale · forearm',[(.248*sign,.017,1.084,.039,.040),(.254*sign,.036,1.012,.044,.045),(.251*sign,.055+dy,.862,.029,.032)])
    ball('Scale · hand',.25*sign,.067+dy,.805,.030,.042,.069)
# Flush warm cabin lighting is physically attached to the ceiling.
group('Roof')
for x in (-2.9,-.75,1.35,3.30):
    for y in (-.66,.66):
        cyl('Cabin downlight',(x,y,3.273),.086,.014,'Z','steel',24)
        cyl('Cabin downlight lens',(x,y,3.262),.064,.012,'Z','lamp',24)
bpy.context.view_layer.update()

args = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if '--editable' in args or '--editable-only' in args:
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type=='VIEW_3D':
                space=area.spaces.active
                space.region_3d.view_distance=12.8
                space.region_3d.view_location=(0,-.35,2.02)
                space.region_3d.view_rotation=Vector((8.5,16,-6.8)).to_track_quat('-Z','Y')
                space.region_3d.view_perspective='ORTHO'
                space.shading.color_type='MATERIAL'
                space.overlay.show_overlays=False
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(D/'Unit-02-Workshop.blend'),compress=True)
    if '--editable-only' in args: sys.exit(0)

# Bake assembly components once; triangulation/export then happens on shared scene geometry.
def bake_model():
    dg=bpy.context.evaluated_depsgraph_get()
    for cname,(coll,parent) in list(assemblies.items()):
        objects=[o for o in coll.objects if o.type in ('FONT','CURVE','MESH')]
        if not objects:continue
        baked=[]
        for o in objects:
            oe=o.evaluated_get(dg)
            m=bpy.data.meshes.new_from_object(oe,preserve_all_data_layers=True,depsgraph=dg)
            if len(m.vertices)==0:continue
            matrix=o.matrix_world.copy()
            new=bpy.data.objects.new('Baked part',m)
            coll.objects.link(new);new.matrix_world=matrix
            baked.append(new)
        for o in objects:bpy.data.objects.remove(o,do_unlink=True)
        bpy.ops.object.select_all(action='DESELECT')
        for b in baked:b.select_set(True)
        if not baked: continue
        bpy.context.view_layer.objects.active=baked[0]
        bpy.ops.object.join()
        joined=bpy.context.object;joined.name=cname+' · surfaces'
        joined.parent=parent
    bpy.ops.object.select_all(action='DESELECT')
bake_model()
bpy.context.view_layer.update()
bpy.ops.export_scene.gltf(filepath=str(D/'Unit-02.glb'),export_format='GLB',export_yup=True,export_cameras=False,export_lights=False,export_materials='EXPORT',export_texcoords=False,export_animations=False)
print('EXPORTED',flush=True)
if '--model-only' in args: sys.exit(0)

# Studio, lights and cameras are kept outside the exported model.
world=bpy.data.worlds.new('Studio ambient');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.78,.82,.87,1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value=.36
scene.render.engine='CYCLES';scene.cycles.samples=36;scene.cycles.use_denoising=False
scene.render.threads_mode='FIXED';scene.render.threads=9
scene.cycles.max_bounces=7;scene.cycles.transparent_max_bounces=6
scene.render.resolution_x=1500;scene.render.resolution_y=950
scene.render.resolution_percentage=100
scene.render.film_transparent=True
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA'
scene.view_settings.view_transform='AgX'
try:scene.view_settings.look='AgX - Medium High Contrast'
except:pass
def area(name,pos,target,power,color,size):
    ld=bpy.data.lights.new(name,'AREA');ld.energy=power;ld.color=color;ld.shape='DISK';ld.size=size
    o=bpy.data.objects.new(name,ld);scene.collection.objects.link(o);o.location=pos
    o.rotation_euler=(Vector(target)-Vector(pos)).to_track_quat('-Z','Y').to_euler()
    return o
studio=[
area('Large window',(-4,-6,11),(0,0,1.4),1900,(1,.89,.74),8),
area('Cool softbox',(1,-6,5),(1,0,1.5),750,(.73,.86,1),6),
area('Aft edge light',(4.5,6,8),(0,0,2),2300,(1,.94,.80),6),
area('Cab fill',(-7,2,4),(-3,0,1.4),480,(.82,.9,1),4)]
roomlights=[]
for x in (-2.85,-.65,1.45,3.25):
    roomlights.append(area('Ceiling pool',(x,0,3.245),(x,.48,1.3),36,(1,.85,.66),.9))
camera_data=bpy.data.cameras.new('Design study camera');cam=bpy.data.objects.new('Camera',camera_data);scene.collection.objects.link(cam);scene.camera=cam
def state(hidden):
    for n,(coll,e) in assemblies.items():
        for o in coll.objects:o.hide_render=n in hidden
def studio_camera(pos,target,scale):
    camera_data.type='ORTHO';camera_data.ortho_scale=scale;cam.location=pos
    cam.rotation_euler=(Vector(target)-Vector(pos)).to_track_quat('-Z','Y').to_euler()
def render(name):
    scene.render.filepath=str(D/(name+'.png'));bpy.ops.render.render(write_still=True)
    print('RENDERED '+name,flush=True)
state({'Scale figure'})
studio_camera((-9.1,-16,7.0),(-.03,-.30,2.22),11.7)
render('hero')
state({'Near shell','Roof'})
studio_camera((-5.2,-15,9.9),(-.03,-.32,1.77),10.95)
render('cutaway')
state({'Scale figure'})
camera_data.type='PERSP';camera_data.lens=16.5;camera_data.sensor_width=36;camera_data.clip_start=.035
cam.location=(3.91,-1.13,2.81)
cam.rotation_euler=(Vector((-.26,.38,2.30))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.film_transparent=False
scene.render.resolution_x=1500;scene.render.resolution_y=900
scene.cycles.samples=62
render('Unit-02-Inside')
