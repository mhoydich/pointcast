// Node 24+: execute the pinned official TypeScript renderer, then compare all
// 100 transparent SVG outputs byte for byte. Temporary files are cleaned.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const source = fs.readFileSync(path.join(root, 'official-source/svg-builder.ts'), 'utf8');
const expected = 'c0c65e6e937114bf8fc4e297b28aa8a28c8936ea41276b4e0027603f4756602f';
if (crypto.createHash('sha256').update(source).digest('hex') !== expected) throw Error('Official source changed');
const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'nouns-hundred-sdk-'));
try {
  // The only source edit marks a type-only import as type-only so Node's
  // built-in TypeScript stripping does not attempt to load a runtime module.
  fs.writeFileSync(path.join(scratch, 'renderer.ts'), source.replace("import { DecodedImage }", "import type { DecodedImage }"));
  const { buildSVG } = await import(pathToFileURL(path.join(scratch, 'renderer.ts')));
  const data = JSON.parse(fs.readFileSync(path.join(root, 'assets/image-data.json')));
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json')));
  const results = manifest.items.map(item => {
    const s = item.seed;
    const parts = [data.images.bodies[s.body], data.images.accessories[s.accessory], data.images.heads[s.head], data.images.glasses[s.glasses]];
    const actual = fs.readFileSync(path.join(root, item.svg), 'utf8');
    const expectedSVG = buildSVG(parts, data.palette);
    if (actual !== expectedSVG) throw Error(`Official SDK mismatch: ${item.id}`);
    return { id: item.id, byte_for_byte_match: true };
  });
  const report = { status: 'passed', official_renderer_sha256: expected, node: process.version, count: results.length, comparison: 'Exact UTF-8 SVG bytes against official buildSVG; all 100 transparent portraits', source_adaptation: 'Only import changed to import type for native Node TypeScript execution', items: results };
  fs.writeFileSync(path.join(root, 'official-sdk-validation.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, count: results.length, comparison: report.comparison }));
} finally {
  fs.rmSync(scratch, { recursive: true, force: true });
}
