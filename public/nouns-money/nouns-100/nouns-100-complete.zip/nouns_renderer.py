#!/usr/bin/env python3
"""Original Nouns asset renderer and deterministic batch generator. GPL-3.0.

No network or packages required. RLE geometry follows the official Nouns SDK.
Local series hashes select traits; they do not identify minted tokens.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import struct
import sys
import time
import zlib

ROOT = Path(__file__).resolve().parent
COMMIT = '2213eea1c15f331f786784c2621d53bdecf907e2'
ASSET_SHA = 'a03f22b7838b35fdf0332617c9b8e2b032eb26cf1632afbefb200fec64c4bc20'
LAYERS = [('body', 'bodies'), ('accessory', 'accessories'), ('head', 'heads'), ('glasses', 'glasses')]
FIELDS = ['background', 'body', 'accessory', 'head', 'glasses']

def assets():
    raw = (ROOT / 'assets/image-data.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != ASSET_SHA:
        raise ValueError('Asset checksum mismatch. Restore the pinned snapshot or deliberately update provenance.')
    return json.loads(raw)

def counts(data):
    return {'background': len(data['bgcolors']), **{key:len(data['images'][group]) for key,group in LAYERS}}

def validate_seed(seed, data):
    if set(seed) != set(FIELDS):
        raise ValueError('Seed must contain exactly background, body, accessory, head, glasses.')
    for key, limit in counts(data).items():
        if type(seed[key]) is not int or not 0 <= seed[key] < limit:
            raise ValueError(f'{key} must be an integer from 0 to {limit-1}.')
    return seed

def series_seed(series, index, data):
    limits = counts(data)
    return {key: int.from_bytes(hashlib.sha256(f'{series}\0{index}\0{key}'.encode()).digest()[:8], 'big') % limits[key] for key in FIELDS}

def rectangles(seed, data, transparent=False):
    validate_seed(seed, data)
    result = [(0,0,32,32,None if transparent else data['bgcolors'][seed['background']])]
    for key, group in LAYERS:
        encoded = data['images'][group][seed[key]]['data']
        raw = bytes.fromhex(encoded.removeprefix('0x'))
        if len(raw) < 5 or (len(raw)-5) % 2:
            raise ValueError('Invalid RLE byte length.')
        palette, top, right, bottom, left = raw[:5]
        if len(raw) == 5 and raw == bytes(5):
            continue  # Canonical accessory-none is an empty RLE image.
        if palette != 0 or not 0 <= left < right <= 32 or not 0 <= top <= bottom <= 32:
            raise ValueError('Unsupported palette or invalid RLE bounds.')
        x,y = left,top
        for run, color in zip(raw[5::2],raw[6::2]):
            if color >= len(data['palette']):
                raise ValueError('Invalid RLE palette index.')
            while run:
                length = min(run, right-x)
                if length <= 0 or y >= 32:
                    raise ValueError('RLE run exceeds the 32x32 canvas.')
                if color:
                    result.append((x,y,length,1,data['palette'][color]))
                x += length
                if x == right:
                    x,y = left,y+1
                run -= length
    return result

def render_svg(seed, data, transparent=False):
    rects = rectangles(seed,data,transparent)
    bg = 'none' if transparent else '#'+rects[0][4]
    parts = [f'<svg width="320" height="320" viewBox="0 0 320 320" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="{bg}" />']
    for x,y,w,h,color in rects[1:]:
        parts.append(f'<rect width="{w*10}" height="{h*10}" x="{x*10}" y="{y*10}" fill="#{color}" />')
    return ''.join(parts)+'</svg>'

def render_png(seed, data, size=640, transparent=False):
    if size < 32 or size > 2048 or size % 32:
        raise ValueError('PNG size must be a multiple of 32, between 32 and 2048.')
    pixels = [[(0,0,0,0) for _ in range(32)] for _ in range(32)]
    for x,y,w,h,color in rectangles(seed,data,transparent):
        if color is None:
            continue
        rgba = tuple(bytes.fromhex(color))+(255,)
        for yy in range(y,y+h):
            for xx in range(x,x+w):
                pixels[yy][xx]=rgba
    scale=size//32
    rows=[]
    for row in pixels:
        encoded=b'\0'+b''.join(bytes(pixel)*scale for pixel in row)
        rows.extend([encoded]*scale)
    def chunk(kind,payload):
        return struct.pack('>I',len(payload))+kind+payload+struct.pack('>I',zlib.crc32(kind+payload)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(rows),9))+chunk(b'IEND',b'')

def batch(out, series, count, jobs=4, size=640, transparent=False, explicit=None):
    data=assets()
    if not 1 <= count <= 10000 or not 1 <= jobs <= 32:
        raise ValueError('Use count 1..10000 and jobs 1..32.')
    if size < 32 or size > 2048 or size % 32:
        raise ValueError('PNG size must be a multiple of 32, between 32 and 2048.')
    if explicit and count != 1:
        raise ValueError('Explicit seed renders one portrait. Use --count 1.')
    seeds=[validate_seed(explicit,data)] if explicit else [series_seed(series,i,data) for i in range(count)]
    # Ensure all five-index tuples are unique within this batch.
    seen=set()
    for i, seed in enumerate(seeds):
        salt=0
        while tuple(seed[k] for k in FIELDS) in seen:
            salt+=1
            seed=series_seed(f'{series}:collision:{salt}',i,data)
        seeds[i]=seed
        seen.add(tuple(seed[k] for k in FIELDS))
    out=Path(out)
    out.mkdir(parents=True,exist_ok=False)
    start=time.perf_counter()
    def one(pair):
        i,seed=pair
        stem=f'noun-{i+1:04d}'
        svg=render_svg(seed,data,transparent)
        png=render_png(seed,data,size,transparent)
        (out/f'{stem}.svg').write_text(svg)
        (out/f'{stem}.png').write_bytes(png)
        return {'id':stem,'seed':seed,'traits':{'background':data['bgcolors'][seed['background']], **{key:data['images'][group][seed[key]]['filename'] for key,group in LAYERS}},'svg':f'{stem}.svg','png':f'{stem}.png','svg_sha256':hashlib.sha256(svg.encode()).hexdigest(),'png_sha256':hashlib.sha256(png).hexdigest()}
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        items=list(pool.map(one,enumerate(seeds)))
    manifest={'schema':1,'source':{'repository':'https://github.com/nounsDAO/nouns-monorepo','commit':COMMIT,'asset_sha256':ASSET_SHA,'artwork':'Original Nouns artwork; public domain / CC0 per official documentation'},'series':series,'seed_algorithm':'sha256-series-v1 (local trait selection; not an on-chain Noun ID)','transparent':transparent,'size':size,'jobs':jobs,'elapsed_seconds':round(time.perf_counter()-start,3),'items':items}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('catalog',help='List trait names and indices.')
    p=sub.add_parser('batch',help='Generate SVG + crisp PNG portraits in parallel.')
    p.add_argument('--out',required=True)
    p.add_argument('--series',default='nouns-money')
    p.add_argument('--count',type=int,default=6)
    p.add_argument('--jobs',type=int,default=4)
    p.add_argument('--size',type=int,default=640)
    p.add_argument('--transparent',action='store_true')
    p.add_argument('--seed',help='Five comma-separated indices: background,body,accessory,head,glasses')
    a=parser.parse_args()
    if a.command=='catalog':
        data=assets()
        print(json.dumps({'counts':counts(data),'backgrounds':data['bgcolors'],**{key:[{'index':i,'name':v['filename']} for i,v in enumerate(data['images'][group])] for key,group in LAYERS}},indent=2))
    else:
        explicit=dict(zip(FIELDS,map(int,a.seed.split(',')))) if a.seed else None
        if a.seed and len(a.seed.split(',')) != 5:
            parser.error('--seed requires exactly five integers.')
        m=batch(a.out,a.series,a.count,a.jobs,a.size,a.transparent,explicit)
        print(json.dumps({'manifest':str(Path(a.out)/'manifest.json'),'count':len(m['items']),'jobs':m['jobs'],'elapsed_seconds':m['elapsed_seconds']}))

if __name__=='__main__':
    try:
        main()
    except (ValueError, OSError) as error:
        print(f'nouns.py: {error}', file=sys.stderr)
        sys.exit(2)
