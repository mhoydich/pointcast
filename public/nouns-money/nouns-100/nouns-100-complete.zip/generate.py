#!/usr/bin/env python3
"""Reproduce The Hundred using pinned original Nouns traits. GPL-3.0.

Portraits require Python 3 standard library. Contact sheets and independent
pixel verification require Pillow. Usage: python3 generate.py --out /tmp/new-set
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import nouns_renderer as renderer

ROOT = Path(__file__).resolve().parent
SERIES = 'michael-hoydich-the-hundred-2026-10-19-v1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def independent_pixels(seed, data, background=False):
    """Independent linear-buffer RLE decode, including final occlusion."""
    pixels = [(0, 0, 0, 0)] * 1024
    if background:
        pixels = [tuple(bytes.fromhex(data['bgcolors'][seed['background']])) + (255,)] * 1024
    for key, group in [('body', 'bodies'), ('accessory', 'accessories'), ('head', 'heads'), ('glasses', 'glasses')]:
        raw = bytes.fromhex(data['images'][group][seed[key]]['data'].removeprefix('0x'))
        palette, top, right, bottom, left = raw[:5]
        assert palette == 0
        if len(raw) == 5:
            assert raw == bytes(5)
            continue
        width = right - left
        assert width > 0
        cursor = 0
        for run, color in zip(raw[5::2], raw[6::2]):
            for offset in range(run):
                row, col = divmod(cursor + offset, width)
                x, y = left + col, top + row
                assert 0 <= x < 32 and 0 <= y < 32
                if color:
                    pixels[y * 32 + x] = tuple(bytes.fromhex(data['palette'][color])) + (255,)
            cursor += run
    return bytes(v for pixel in pixels for v in pixel)


def select_seed(cohort, ordinal, head, data):
    seed = renderer.series_seed(f'{SERIES}:{cohort["id"]}', ordinal, data)
    seed['head'] = head
    # Background is part of the reproducible five-field seed, though omitted
    # from transparent portraits. Uniqueness is checked after flattening all
    # visible layers with that background removed.
    return seed


def contact_sheets(out, manifest):
    from PIL import Image, ImageDraw, ImageFont
    font_path = Path('/System/Library/Fonts/Supplemental/Arial.ttf')
    font_bold = Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf')
    def font(size, bold=False):
        p = font_bold if bold else font_path
        return ImageFont.truetype(str(p), size) if p.exists() else ImageFont.load_default()
    dest = out / 'contact-sheets'
    dest.mkdir(exist_ok=True)
    for cohort in manifest['cohorts']:
        members = [a for a in manifest['items'] if a['cohortId'] == cohort['id']]
        canvas = Image.new('RGB', (1600, 900), cohort['paper'])
        d = ImageDraw.Draw(canvas)
        d.text((36, 22), cohort['name'].upper(), fill=cohort['ink'], font=font(34, True))
        d.text((36, 66), cohort['description'], fill=cohort['ink'], font=font(18))
        for i, item in enumerate(members):
            x, y = 32 + (i % 5) * 312, 112 + (i // 5) * 362
            d.rounded_rectangle((x, y, x + 286, y + 340), radius=10, fill='#fffdf8')
            avatar = Image.open(out / item['png']).convert('RGBA').resize((256, 256), Image.Resampling.NEAREST)
            canvas.paste(avatar, (x + 15, y + 8), avatar)
            d.text((x + 15, y + 274), f'{item["number"]:03d}  {item["name"]}', fill=cohort['ink'], font=font(20, True))
            d.text((x + 15, y + 304), item['traits']['head'].removeprefix('head-'), fill='#656563', font=font(15))
        d.text((36, 866), 'THE HUNDRED / MICHAEL HOYDICH / ORIGINAL NOUNS TRAITS / LOCAL FICTIONAL CHARACTERS', fill=cohort['ink'], font=font(15))
        canvas.save(dest / f'{cohort["id"]}.jpg', quality=94, subsampling=0)
    canvas = Image.new('RGB', (2560, 3100), '#f2eee6')
    d = ImageDraw.Draw(canvas)
    d.text((36, 22), 'THE HUNDRED', fill='#222222', font=font(54, True))
    d.text((38, 90), 'A NOUNS CASTING CALL / 100 ORIGINAL-FRAMEWORK CHARACTERS / MICHAEL HOYDICH', fill='#555555', font=font(23))
    for ci, cohort in enumerate(manifest['cohorts']):
        y = 148 + ci * 288
        d.rectangle((24, y, 2536, y + 276), fill=cohort['paper'])
        d.text((40, y + 8), cohort['name'].upper(), fill=cohort['ink'], font=font(18, True))
        members = [a for a in manifest['items'] if a['cohortId'] == cohort['id']]
        for i, item in enumerate(members):
            x = 40 + i * 250
            avatar = Image.open(out / item['png']).convert('RGBA').resize((192, 192), Image.Resampling.NEAREST)
            canvas.paste(avatar, (x + 16, y + 36), avatar)
            d.text((x + 5, y + 237), f'{item["number"]:03d} {item["name"]}', fill=cohort['ink'], font=font(16, True))
    d.text((36, 3055), 'Canonical artwork is CC0. Character names and stories are fictional. No mint, ownership, rarity or live-agent claim.', fill='#555555', font=font(20))
    canvas.save(dest / 'all-100.jpg', quality=94, subsampling=0)


def validate(out, manifest, data):
    from PIL import Image
    seen = set()
    results = []
    palette = {'#' + p for p in data['palette'] if p}
    for item in manifest['items']:
        seed = item['seed']
        renderer.validate_seed(seed, data)
        expected = independent_pixels(seed, data)
        fingerprint = sha(expected)
        assert fingerprint not in seen, f'Visible duplicate {item["id"]}'
        seen.add(fingerprint)
        assert fingerprint == item['visible_geometry_sha256']
        svg_path = out / item['svg']
        svg_bytes = svg_path.read_bytes()
        assert sha(svg_bytes) == item['svg_sha256']
        root = ET.fromstring(svg_bytes)
        assert root.attrib['viewBox'] == '0 0 320 320'
        assert root.attrib['shape-rendering'] == 'crispEdges'
        canvas = Image.new('RGBA', (32, 32))
        from PIL import ImageDraw
        draw = ImageDraw.Draw(canvas)
        for rect in list(root)[1:]:
            values = [int(rect.attrib[k]) for k in ['x', 'y', 'width', 'height']]
            assert all(v % 10 == 0 for v in values)
            x, y, w, h = [v // 10 for v in values]
            assert 0 <= x < 32 and 0 <= y < 32 and x + w <= 32 and y + h <= 32
            fill = rect.attrib['fill']
            assert fill in palette
            draw.rectangle((x, y, x + w - 1, y + h - 1), fill=fill)
        assert canvas.tobytes() == expected
        for path, bg in [(item['png'], False), (item['opaquePng'], True)]:
            with Image.open(out / path) as im:
                assert im.size == (640, 640) and im.mode == 'RGBA'
                exp = Image.frombytes('RGBA', (32, 32), independent_pixels(seed, data, bg)).resize((640, 640), Image.Resampling.NEAREST)
                assert im.tobytes() == exp.tobytes(), f'PNG mismatch {path}'
        assert sha((out / item['png']).read_bytes()) == item['png_sha256']
        assert svg_bytes.decode() == renderer.render_svg(seed, data, True)
        results.append({'id':item['id'], 'valid_seed':True, 'svg_grid_and_palette':True, 'independent_svg_pixels':True, 'transparent_and_opaque_png_pixels':True, 'visible_geometry_sha256':fingerprint})
    assert len(manifest['items']) == 100 and len(seen) == 100
    assert len({a['seed']['head'] for a in manifest['items']}) == 100
    report = {'status':'passed', 'count':100, 'unique_visible_rgba_geometry':len(seen), 'unique_head_traits':100, 'svg_canvas':[320,320], 'native_grid':[32,32], 'png_dimensions':[640,640], 'png_scale':20, 'background_only_duplicates':0, 'items':results}
    (out / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT)
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    out = args.out.resolve()
    data = renderer.assets()
    if args.verify_only:
        report = validate(out, json.loads((out/'manifest.json').read_text()), data)
        print(json.dumps({k:v for k,v in report.items() if k!='items'}))
        return
    if (out / 'manifest.json').exists():
        raise SystemExit('Existing collection detected. Use --out with a fresh directory or --verify-only.')
    out.mkdir(parents=True, exist_ok=True)
    (out / 'portraits/backgrounds').mkdir(parents=True, exist_ok=True)
    cohorts = json.loads((ROOT / 'cohorts.json').read_text())
    rows = [line.split('|') for line in (ROOT / 'characters.txt').read_text().splitlines() if line.strip()]
    assert len(rows) == 100 and all(len(r) == 3 for r in rows)
    items = []
    for ci, cohort in enumerate(cohorts['cohorts']):
        for offset, head in enumerate(cohort['head_indices']):
            index = ci * 10 + offset
            name, line, bio = rows[index]
            assert name == cohort['character_names'][offset]
            seed = select_seed(cohort, offset, head, data)
            renderer.validate_seed(seed, data)
            stem = f'noun-{index+1:04d}'
            svg = renderer.render_svg(seed, data, True).encode()
            png = renderer.render_png(seed, data, 640, True)
            opaque = renderer.render_png(seed, data, 640, False)
            (out / f'portraits/{stem}.svg').write_bytes(svg)
            (out / f'portraits/{stem}.png').write_bytes(png)
            (out / f'portraits/backgrounds/{stem}.png').write_bytes(opaque)
            items.append({'id':stem,'number':index+1,'name':name,'cohortId':cohort['id'],'cohortName':cohort['name'],'oneLiner':line,'bio':bio,'seed':seed,'traits':{'background':data['bgcolors'][seed['background']],**{key:data['images'][group][seed[key]]['filename'] for key,group in renderer.LAYERS}},'svg':f'portraits/{stem}.svg','png':f'portraits/{stem}.png','opaquePng':f'portraits/backgrounds/{stem}.png','svg_sha256':sha(svg),'png_sha256':sha(png),'opaque_png_sha256':sha(opaque),'visible_geometry_sha256':sha(independent_pixels(seed,data))})
    manifest = {'schema':1,'title':cohorts['title'],'creator':cohorts['creator'],'series':SERIES,'source':{'repository':'https://github.com/nounsDAO/nouns-monorepo','commit':renderer.COMMIT,'asset_sha256':renderer.ASSET_SHA,'artwork_license':'CC0 per official Nouns documentation','code_license':'GPL-3.0','customization':'New deterministic combinations of canonical traits; no newly drawn trait assets','identity_note':cohorts['character_note']},'seed_algorithm':'sha256-series-v1 for background/body/accessory/glasses; curated canonical head per roster','transparent':True,'nativeGrid':32,'pngSize':640,'cohorts':cohorts['cohorts'],'items':items}
    (out / 'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    contact_sheets(out, manifest)
    report = validate(out,manifest,data)
    if out != ROOT:
        for filename in ['cohorts.json','characters.txt','generate.py','nouns_renderer.py','LICENSE','FRAMEWORK.md','README.md','live-framework-check.json']:
            if (ROOT/filename).exists(): shutil.copy2(ROOT/filename,out/filename)
        shutil.copytree(ROOT/'assets',out/'assets',dirs_exist_ok=True)
        if (ROOT/'official-source').exists(): shutil.copytree(ROOT/'official-source',out/'official-source',dirs_exist_ok=True)
    print(json.dumps({'manifest':str(out/'manifest.json'),'count':100,'unique_visible_geometry':report['unique_visible_rgba_geometry'],'validation':str(out/'validation.json')}))


if __name__ == '__main__':
    main()
