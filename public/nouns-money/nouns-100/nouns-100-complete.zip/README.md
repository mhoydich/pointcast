# The Hundred: A Nouns Casting Call

Created by Michael Hoydich. Canonical character production, names and biographies assembled by the Codex Hundred Nouns production agent using the original Nouns framework.

100 visual companion concepts in ten casts: Screen After Dark, Signal Garage, Deep Time Radio, Tidal Department, Pocket Cosmos, Night Market, Greenroom Garden, Field Trip Club, Paper City and Oddball League. Each has an exact original-framework portrait, reproducible seed, name, one-line persona and short biography.

## Start here

- `contact-sheets/all-100.jpg`: the complete casting board.
- `contact-sheets/<cohort>.jpg`: ten larger boards with ten characters each.
- `manifest.json`: the machine-readable roster, biographies, five-field seeds, trait names, paths and checksums.
- `portraits/noun-0001.svg` through `noun-0100.svg`: transparent, editable, canonical vectors.
- `portraits/noun-0001.png` through `noun-0100.png`: transparent 640 × 640 PNGs.
- `portraits/backgrounds/`: the same 100 characters on their canonical seed backgrounds.
- `FRAMEWORK.md`: the source check, specifications, licensing distinction and verification findings.

These are fictional character concepts for creative use. A persona description does not connect an AI agent or grant it tools, credentials, payments or autonomous powers. The numbers 001–100 identify positions in this local collection; they are not minted Noun IDs. The collection combines existing canonical traits and makes no claim that every combination is globally new.

## Reproduce the collection

Use Python 3 and Pillow. The portrait renderer itself uses only Python's standard library; Pillow makes contact sheets and independently checks PNG pixels.

```sh
python3 generate.py --out /tmp/nouns-hundred-reproduction
python3 generate.py --verify-only
node verify-official.mjs
```

Choose a fresh output folder for reproduction. The generator refuses to overwrite an existing manifest. The Node verification requires Node 24 or another runtime supporting native TypeScript stripping. It uses the bundled official source, changes only a type-only import annotation for execution, compares all 100 SVGs, and removes its temporary files.

The seed-selection namespace is `michael-hoydich-the-hundred-2026-10-19-v1`. `cohorts.json` supplies the canonical head choices and the grouping; `characters.txt` supplies the original names and prose. The artwork file is checksum-pinned at `a03f22b7838b35fdf0332617c9b8e2b032eb26cf1632afbefb200fec64c4bc20`.

Use SVGs for print layouts or enlargement. Keep pixel displays at integer multiples of 32 and disable image smoothing. Contact sheets are presentation JPEGs; they are not the canonical portrait masters. This delivery has not been physically printed or manufactured.

The canonical character ZIP contains this roster, portraits, sheets, reproducible engine, source evidence and checks. Entertainment and generated-art editions belong to their separately credited packages.
