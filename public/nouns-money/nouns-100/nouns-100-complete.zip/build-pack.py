#!/usr/bin/env python3
"""Package the canonical 100-character deliverables, independently of editions."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
names = ['README.md', 'FRAMEWORK.md', 'LICENSE', 'cohorts.json', 'characters.txt',
         'manifest.json', 'generate.py', 'nouns_renderer.py', 'verify-official.mjs',
         'build-pack.py', 'validation.json', 'official-sdk-validation.json',
         'live-framework-check.json', 'visual-review.json']
paths = [ROOT / name for name in names]
for name in ['assets', 'portraits', 'contact-sheets', 'official-source']:
    paths.extend(p for p in (ROOT / name).rglob('*') if p.is_file())
paths = sorted(paths, key=lambda p: p.relative_to(ROOT).as_posix())
archive = ROOT / 'nouns-100-complete.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in paths:
        info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), (2026, 10, 19, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(paths)
    for path in paths:
        assert z.read(path.relative_to(ROOT).as_posix()) == path.read_bytes()
assert archive.stat().st_size < 25 * 1024 * 1024
report = {'status':'passed','archive':archive.name,'members':len(paths),
          'bytes':archive.stat().st_size,'under_25_MiB':True,'crc':'passed',
          'all_member_bytes_match_source':True,
          'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(ROOT/'archive-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
