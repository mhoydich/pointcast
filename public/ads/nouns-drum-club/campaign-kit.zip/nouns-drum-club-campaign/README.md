# Nouns Drum Club campaign kit

Preview campaign package for PointCast’s Nouns Drum Club.

## Contents

- 30 placements in PNG, SVG, and HTML: 90 ad files total.
- 3 source compositions in PNG and WebP at 1536 × 1024.
- `campaign.json` placement manifest and `docs/series.json` creative prompt record.
- `SHA256SUMS.txt` for delivery verification.

Placements cover 160 × 600, 300 × 250, 300 × 600, 320 × 50, 320 × 100, 336 × 280, 728 × 90, 970 × 250, 1080 × 1080, and 1080 × 1920 for each of three concepts. HTML placements use the sibling PNG; SVG placements use package-relative source art. Keep the included folder structure intact.

Deliver by unzipping the whole package and hosting its contents together. These are static, silent placements: no audio, animation, tracking script, wallet action, mint action, or autoplay is included. Links open the free Nouns Drum Club player, where sound starts only after a person interacts.
