# El Segundo seasonal living atlas — verified research and methodology

Research date: **2 October 2026**. Prepared for the PointCast concept atlas and its connected Object Library. Use the companion `hazards-sources.md` for verified NOAA/NWS/EPA seasonal hazard guidance. The files in this folder are implementation research inputs, not proof of an operating lending service.

## What the evidence supports

The useful local distinction is between **coast, coastal plain, inland basin/valley, and exposed hills**, then the season and the task. Four NOAA station normals make the coastal cooling signal visible. Their normal August daily highs are LAX **76.7°F**, the Downtown/USC series **84.0°F**, Long Beach airport **83.2°F**, and Burbank airport **88.9°F**. A shaded block, windy bluff, reflective parking lot, and room with afternoon sun can differ from the nearest station. These figures describe station climatology rather than individual-day conditions or personal comfort.

LAX's precipitation normals total **12.23 inches** when its twelve rounded monthly values are summed. About **86.9%** falls in November–March. Its August precipitation normal rounds to **0.00 inches**; this does not mean August rain is impossible. Downtown's corresponding rounded monthly sum is **14.25 inches**; Long Beach is **12.02**, Burbank **13.91**. Numerical values are extracted directly from NOAA's station CSVs linked below.

The observed calendar-year rainfall chart adds variability that a normal hides. The accepted daily LAX observations aggregate to about **27.1 inches in 1998**, **3.6 in 2013**, and **25.4 in 2023**. These are research aggregates, rounded to one decimal, from complete daily precipitation coverage in those years. The **1991–2025** extract has all 365 or 366 accepted precipitation days for all 35 calendar years at both LAX and the Downtown series. Do not label these as rain seasons: the local July–June rain season and October–September water year are different periods.

## Radius and map contract

- Center: **33.9192° N, 118.4165° W**, a declared approximate El Segundo civic-center reference point, not a user's address.
- Radius: **25 statute miles = 40.2336 km**. Membership uses the haversine great-circle distance with Earth radius **3,958.7613 miles**, a practical approximation to straight-line distance across this small area. It is not road distance or travel time.
- The circle includes ocean and portions of cities. A city label inside the circle does not put the whole city inside it. Clip categorical land areas and point samples to the circle; do not interpret offshore portions as residential recommendations.
- The four normal anchors lie within the radius: LAX **2.05 mi**, USC anchor **10.18 mi**, Burbank **19.73 mi**, and Long Beach **17.18 mi** from the declared center. These use the plotted normal-period anchor coordinates in `weather-data.json`.
- Display the station anchors and their values separately from manually drawn **illustrative categorical areas**. The areas summarize terrain and coastal exposure; they are not NOAA climate-zone boundaries, measured block-level temperatures, or numerical interpolation.
- A suitability label describes the selected purpose, season, and stated assumptions. “Coastal afternoon walking,” “inland morning errands,” and “a sheltered outdoor workspace” are useful purposes. No location is universally optimal. Accessibility, shade, cost, air quality, transport, and the actual day's conditions affect suitability.

The map should explain what its controls change: season alters the editorial guidance; purpose changes the activity or object advice; station selection reveals historical normal values. Keep current NWS weather and AirNow links distinct from historical layers. A warning, smoke episode, storm, or closure overrides the seasonal suggestion.

## Station coverage and history

| Normal station / NOAA ID | Plotted normal anchor | Elevation used | History and coverage caveat |
|---|---|---:|---|
| Los Angeles International Airport / **USW00023174** | 33.9381, -118.3889 | 29.6 m | HOMR metadata reaches December 1930. The downloaded accepted PRCP, TMAX, and TMIN daily record starts **1 August 1944**, and reaches 29 September 2026 in this snapshot. Airport observations sample an airport exposure, not every El Segundo street. |
| Los Angeles Downtown / USC / **USW00093134** | **34.0236, -118.2911** (USC) | **54.6 m** (USC) | NWS's composite official record dates to **July 1877**. The downloaded daily TMAX/TMIN begin 1 April 1906 and PRCP on 4 April 1906. Civic Center observations ran 1964–1999; USC housed the official site from 1999 until 2024. NWS announced relocation to Frank Hotchkin Memorial Training Center on **20 May 2024**. Raw recent series therefore includes a location change. |
| Burbank Glendale Pasadena Airport / **USW00023152** | 34.2006, -118.3575 | 225.9 m | HOMR airport metadata reaches April 1931, but the supplied daily PRCP/TMAX/TMIN file begins **22 May 1998**. Its monthly 1991–2020 temperature normals carry **R / Representative** flags and 20–21 available years, with missing months estimated. Do not imply 30 observed years at one unchanged site. |
| Long Beach Daugherty airport / **USW00023129** | 33.8117, -118.1464 | 9.4 m | HOMR airport metadata reaches December 1930; the downloaded accepted daily core elements start **1 January 1949**. The airport is inland from the immediate beach and should not stand for all waterfront locations. |

Coordinate provenance matters. The Downtown normals CSV is named “LOS ANGELES DWTN USC CAMPUS” but embeds **34.0511, -118.2353, 70.1 m**, legacy downtown metadata. The atlas uses the independently verified **USC location from NOAA HOMR** as a clearly approximate normal-period anchor, retaining the original metadata in the JSON for provenance. Current FHMC coordinates in HOMR are **34.0678, -118.2417, 115.2 m**, with metadata effective 24 May 2024; this effective metadata date differs from NWS's announced move date. Do not position the 1991–2020 USC normal at FHMC or invent a 30-year FHMC normal.

For the other three plotted anchors, values above are the coordinates/elevations in the **normals CSV**, which can differ slightly from current NOAA station metadata. The plotted points are climate reference anchors, not precise descriptions of current instrument siting. HOMR documents moves, names, equipment, and observing changes; a station identifier alone does not guarantee unchanging conditions.

LAX, Downtown and Long Beach monthly temperature normals have **S / Standard** flags: sufficient availability for at least 24 years, with missing months estimated where nearby records permit. This still does not mean every monthly value contains 30 uninterrupted years of raw measurements. Burbank's R flag is important to show in the source appendix. Precipitation availability/completeness flags are retained separately for every month in the extracted data.

## Show observations, normals, period change, and scenarios separately

1. **Observed history:** calendar-year rain bars derived from GHCN-Daily, 1991–2025. Include station changes, coverage counts, the period, and the quality filter. These are actual archived observations after the stated filtering and unit conversion.
2. **Normal:** monthly 1991–2020 average daily high/low and precipitation at the four stations. These describe long-term seasonal conditions, including NOAA's estimation and adjustment procedures.
3. **Comparable period change:** NOAA provides recomputed 1981–2010 maximum/minimum temperature normals using the same underlying data basis as the 1991–2020 normals. For LAX, August high changes **75.7 → 76.7°F**, July **74.6 → 75.1°F**, October **73.2 → 74.4°F**. These are differences between overlapping 30-year periods, with 20 shared years; they are not a per-decade trend estimate or a future forecast.
4. **Scenario:** a named stress case such as “hot offshore afternoon,” “smoke plus heat,” or “wet winter week.” Mark it as illustrative. Do not assign a recurrence probability or project street-level temperatures without an actual model and its supporting data.

Avoid subtracting the original **published** 1981–2010 station normals from the new set to infer a local trend: NOAA warns that changes in historical corrections and homogenization can distort that comparison. For example, Downtown's published old August high is 84.4°F, but its **recomputed** old August high is 82.8°F; the current normal is 84.0°F. The comparable increase is 1.2°F, while the naive published-to-published subtraction would misleadingly suggest a decrease. The extracted comparison CSVs retain all three versions.

## How one might have mapped this in the past

**Network on paper.** NWS's historical timeline describes telegraphed observations being collected and plotted in the nineteenth century. A period map might show observation points and the broad patterns between them. The absent neighborhoods were a real coverage limitation, not measured blanks to be filled with invented precision. This is a reconstruction of the practice, not a claim that an El Segundo 25-mile living map already existed.

**Los Angeles reference-point atlas, 2000.** Bruno and Ryan's *Climate of Los Angeles, California*, NOAA Technical Memorandum NWS WR-261, January 2000, uses an explicit climate reference-point map (printed **p. 8, Figure 6**), a vertical inversion profile from August 1999 (**p. 19, Figure 11**), and typical wind/Catalina Eddy diagrams (**p. 67, Figure 31a**). Its nearby wind-corridor diagram appears on printed p. 68. These are good precedents for showing stations, terrain, and circulation as separate evidence. The report's older numerical averages and records should not be substituted for 1991–2020 normals or current safety guidance. The source PDF was inspected visually because it is a scanned document.

**Modern scientific gridding.** NOAA nClimGrid maps provide a defensible path for a future quantitative extension: station observations are combined into roughly 4-km cells, with observation-count information and documented uncertainty. Even that resolution does not measure a courtyard or a shaded sidewalk. This prototype uses qualitative areas and station anchors instead of pretending to reproduce that scientific product.

## Practical seasonal interpretation and object utility

The recommendations below are **editorial inferences** from the station seasonality plus the primary-source mechanisms in `hazards-sources.md`. All object names are concepts; neither climate efficacy nor hardware performance is claimed.

| Season | A useful local routine | Object concept connection |
|---|---|---|
| Winter / Dec–Feb | Keep flexible outdoor time between storms; choose dry daylight errands; carry a layer; inspect rain protection and drainage before a wet spell. | **Pocket Companion** holds a rain/gear checklist; **Ambient Lamp** supports an indoor reading corner during darker or wet afternoons. It is not a weather sensor. |
| Spring / Mar–May | Use mild outdoor periods; expect cool cloudy coastal starts; carry a removable layer; select a sheltered spot when wind matters. | **Focus Dial** sets a short outdoor break; **Pocket Companion** compares a morning coast plan with a sheltered inland alternative. |
| Summer / Jun–Aug | Try coastal outdoor time when the day's forecast and air quality permit; favor morning and shade inland; reduce direct afternoon sun; check whether outdoor air is actually cooler and cleaner before ventilating. | **Focus Dial** reminds you to pause and check conditions; an optional **Shade Clip** prototype explores portable shade; **Pocket Companion** presents a packing card. None replaces hydration, cooling, or official guidance. |
| Autumn / Sep–Nov | Keep heat, offshore wind, and smoke contingencies; have an indoor alternative; secure loose outdoor items; revisit rain gear as the season changes. | **Ambient Lamp** supports an indoor fallback; **Pocket Companion** holds a smoke/heat plan; a **Comfort Kit** concept gathers ordinary sun/rain gear without implying medical protection. |

The atlas should not instruct people to open windows every night: cooler hours can coincide with smoke. A filtered-air room must also remain safely cool. When heat or smoke prevents a safe home environment, use official local cooling/clean-air resources. Weather may support timing choices, but an untested prototype cannot certify environmental safety.

## Reproducible extraction and verification

Run `python3 research/extract-weather-data.py` with the downloaded NOAA files in this folder. Outputs are `weather-data.json`, `monthly-normals.csv`, and `observed-calendar-years.csv`.

- The normal parser selects `MLY-TMAX-NORMAL`, `MLY-TMIN-NORMAL`, `MLY-TAVG-NORMAL`, `MLY-PRCP-NORMAL`, and their availability/completeness fields. NOAA station CSVs already express these temperature fields in Fahrenheit and precipitation in inches. Values are kept at published precision.
- Daily `.dly` parsing follows NOAA's fixed-column format. Exclude `-9999` missing values and every value with a nonblank **QFLAG**. A blank QFLAG means no listed quality check failed; it does not prove absolute accuracy. Measurement/source flags remain available in the raw snapshot.
- Convert daily precipitation from tenths of millimeters to inches by dividing by **254**. Trace precipitation contributes zero measured depth. Convert temperatures from tenths of °C with `value / 10 * 9 / 5 + 32`. Annual rain is reported only when every expected calendar day has an accepted value; otherwise output `null`, not a partial low total.
- All 70 station/calendar-year precipitation records pass the 365/366-day rule. Some temperature years have rejected or missing days. Do not present a peak from incomplete temperature coverage as an official annual or all-time record. The optional rounded-90°F counter uses whole-degree Fahrenheit rounding and is not a heat-risk measure.
- Published normal rainfall values and converted daily observations have different rounding paths. For public rain-history copy, one decimal is adequate; certify any regulatory or formal record claim through NOAA/NWS official products.
- Source snapshots have SHA-256 hashes in `source-manifest.json`, together with the retrieval date and URL. A hash identifies the researched file version. NOAA can revise archive observations after this date; a future rerun should update the snapshot, hash, and date together.

## Primary-source appendix

**Norms and method**

- [NOAA/NCEI U.S. Climate Normals overview, definitions, comparison cautions](https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals)
- [LAX monthly 1991–2020 normals CSV](https://www.ncei.noaa.gov/data/normals-monthly/1991-2020/access/USW00023174.csv)
- [Downtown / USC monthly normals CSV](https://www.ncei.noaa.gov/data/normals-monthly/1991-2020/access/USW00093134.csv)
- [Burbank airport monthly normals CSV](https://www.ncei.noaa.gov/data/normals-monthly/1991-2020/access/USW00023152.csv)
- [Long Beach airport monthly normals CSV](https://www.ncei.noaa.gov/data/normals-monthly/1991-2020/access/USW00023129.csv)
- [NOAA normal-file units and completeness/measurement flags](https://www.ncei.noaa.gov/data/normals-monthly/1991-2020/doc/Readme_By-Variable_By-Station_Normals_Files.txt)
- [Comparable maximum-temperature normal periods CSV](https://www.ncei.noaa.gov/data/normals-monthly/doc/Comparison_Normals_Maximum_Temperature.csv)
- [Comparable minimum-temperature normal periods CSV](https://www.ncei.noaa.gov/data/normals-monthly/doc/Comparison_Normals_Minimum_Temperature.csv)

**Observations and history**

- [GHCN-Daily documentation, units and quality flags](https://www.ncei.noaa.gov/pub/data/ghcn/daily/readme.txt)
- [LAX daily source](https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/USW00023174.dly), [Downtown daily source](https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/USW00093134.dly), [Burbank daily source](https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/USW00023152.dly), [Long Beach daily source](https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/USW00023129.dly)
- [NOAA HOMR station history repository](https://www.ncei.noaa.gov/access/homr/) and [documented public JSON API](https://www.ncei.noaa.gov/access/homr/api)
- Station-history URLs: [LAX](https://www.ncei.noaa.gov/access/homr/#qid=GHCND:USW00023174), [Downtown](https://www.ncei.noaa.gov/access/homr/#qid=GHCND:USW00093134), [Burbank](https://www.ncei.noaa.gov/access/homr/#qid=GHCND:USW00023152), [Long Beach](https://www.ncei.noaa.gov/access/homr/#qid=GHCND:USW00023129)
- [NWS Downtown relocation notice, May 2024](https://www.weather.gov/lox/DowntownLosAngelesMove) and [official Service Change Notice 24-47](https://www.weather.gov/media/notification/pdf_2023_24/scn24-47_downtown_los_angeles_observing_site_move.pdf)
- [NWS airport-temperature reporting explanation](https://www.weather.gov/lox/asostemperature)
- [NWS history of weather observation and mapping](https://www.weather.gov/timeline)
- [NWS WR-261, Climate of Los Angeles, January 2000](https://www.weather.gov/media/wrh/online_publications/TMs/TM-261.pdf)
- [NOAA nClimGrid-Daily, resolution and recommended uses/limitations](https://www.ncei.noaa.gov/products/land-based-station/nclimgrid-daily)

**Mechanisms and live guidance** are linked individually in `hazards-sources.md`: NOAA marine layer, NWS seasonal weather guide, NWS heat guidance, EPA combined heat/smoke guidance, EPA indoor clean-room guidance, AirNow fire/smoke resources, and NOAA California climate summary.

## Proposed PRD and business-case outline

**Atlas problem:** a single city forecast or annual average does not explain seasonal coastal/inland tradeoffs or help choose small everyday adjustments. **Users:** residents, remote workers, walkers, local makers, and visitors planning recurring routines. **Core flow:** choose season → choose purpose → inspect a map area/station → read an action card → open a related concept in the Object Library. **MVP acceptance:** declared 25-mile radius; keyboard-operable seasonal/purpose controls; readable station table and source appendix; historical rain, normals, and period differences labeled distinctly; mobile map alternative; original accessible guide characters; no forecast or inventory claims. **Success signals:** source opens, map/control use, saved checklists, and concept feedback—not fabricated demand or climate-benefit metrics.

**Connected library hypothesis:** trialing a small object may teach a resident what helps before buying or making several versions. The published demo should test catalog clarity, task relevance, and the proposed borrow/try/improve flow. Real loans require an operator, known inventory, pickup/return rules, maintenance, liability assessment, availability, and support before bookings are enabled. **Business questions:** who runs the shelf, which objects survive repeated use, what upkeep costs, what accessible alternatives are needed, and whether a sponsor or membership can cover operations. **Evidence plan:** voluntary usability research and prototype feedback, then a bounded local pilot only after its operations exist. **Risks:** false precision in environmental claims, untested hardware, inequitable access, privacy from location data, and demand implied by a demo. **Stage gate:** prove comprehension and utility, then separately validate fabrication and lending operations. No ROI, savings, health outcomes, or real inventory are established by this research.
