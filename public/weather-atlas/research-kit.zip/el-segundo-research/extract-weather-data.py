"""Reproduce the atlas research extracts from NOAA source files in this folder.

No API key is required. Download URLs, filters, periods and distinctions are
recorded in weather-research.md. This file does not alter feature code.
"""
import calendar
import csv
import datetime as dt
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CENTER = (33.9192, -118.4165)
RADIUS_MI = 25
EARTH_RADIUS_MI = 3958.7613


def distance_mi(lat, lon):
    p1, p2 = map(math.radians, [CENTER[0], lat])
    dp = math.radians(lat - CENTER[0])
    dl = math.radians(lon - CENTER[1])
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_RADIUS_MI * math.asin(math.sqrt(a))


STATIONS = [
    ("lax", "LAX · coast", "noaa-lax-1991-2020.csv", 33.9381, -118.3889, 29.6),
    ("downtown", "Downtown / USC · historical series", "noaa-downtown-la-1991-2020.csv", 34.0236, -118.2911, 54.6),
    ("burbank", "Burbank airport · inland valley", "noaa-burbank-1991-2020.csv", 34.2006, -118.3575, 225.9),
    ("long-beach", "Long Beach airport · coastal plain", "noaa-long-beach-1991-2020.csv", 33.8117, -118.1464, 9.4),
]
stations = []
csv_rows = []
for sid, label, filename, lat, lon, elevation in STATIONS:
    rows = list(csv.DictReader((ROOT / filename).open()))
    station = {
        "id": sid, "label": label, "stationId": rows[0]["STATION"],
        "latitude": lat, "longitude": lon, "elevationM": elevation,
        "distanceMi": round(distance_mi(lat, lon), 2), "period": "1991–2020",
        "sourceUrl": f'https://www.ncei.noaa.gov/data/normals-monthly/1991-2020/access/{rows[0]["STATION"]}.csv',
        "sourceMetadata": {k.lower(): rows[0][k].strip() for k in ["NAME", "LATITUDE", "LONGITUDE", "ELEVATION"]},
        "months": [],
    }
    for row in rows:
        m = int(row["DATE"])
        item = {
            "month": m, "label": calendar.month_abbr[m],
            "highF": float(row["MLY-TMAX-NORMAL"]), "lowF": float(row["MLY-TMIN-NORMAL"]),
            "meanF": float(row["MLY-TAVG-NORMAL"]), "precipIn": float(row["MLY-PRCP-NORMAL"]),
            "highTemperatureCompleteness": row["comp_flag_MLY-TMAX-NORMAL"].strip(),
            "highTemperatureAvailableYears": int(row["years_MLY-TMAX-NORMAL"]),
            "lowTemperatureCompleteness": row["comp_flag_MLY-TMIN-NORMAL"].strip(),
            "lowTemperatureAvailableYears": int(row["years_MLY-TMIN-NORMAL"]),
            "meanTemperatureCompleteness": row["comp_flag_MLY-TAVG-NORMAL"].strip(),
            "meanTemperatureAvailableYears": int(row["years_MLY-TAVG-NORMAL"]),
            "precipCompleteness": row["comp_flag_MLY-PRCP-NORMAL"].strip(),
            "precipAvailableYears": int(row["years_MLY-PRCP-NORMAL"]),
        }
        station["months"].append(item)
        csv_rows.append({"stationId": station["stationId"], "station": label, "period": "1991–2020", **item})
    station["annualPrecipInFromRoundedMonths"] = round(sum(m["precipIn"] for m in station["months"]), 2)
    station["novMarPrecipFraction"] = round(sum(m["precipIn"] for m in station["months"] if m["month"] in [11, 12, 1, 2, 3]) / station["annualPrecipInFromRoundedMonths"], 4)
    stations.append(station)


def parse_daily(filename):
    daily = {}
    for line in (ROOT / filename).read_text().splitlines():
        year, month, element = int(line[11:15]), int(line[15:17]), line[17:21]
        if element not in ["TMAX", "TMIN", "PRCP"]:
            continue
        for day in range(1, calendar.monthrange(year, month)[1] + 1):
            base = 21 + (day - 1) * 8
            value = int(line[base:base + 5])
            mflag, qflag, sflag = line[base + 5:base + 8]
            if value == -9999 or qflag != " ":
                continue
            date = dt.date(year, month, day)
            daily.setdefault(date, {})[element] = {"value": value, "mflag": mflag, "sflag": sflag}
    return daily


observations = []
for sid, filename in [("lax", "noaa-lax-daily.dly"), ("downtown", "noaa-downtown-daily.dly")]:
    daily = parse_daily(filename)
    for year in range(1991, 2026):
        expected = 366 if calendar.isleap(year) else 365
        data = {d: vals for d, vals in daily.items() if d.year == year}
        prcp = [v["PRCP"]["value"] for v in data.values() if "PRCP" in v]
        tmax = [(d, v["TMAX"]["value"]) for d, v in data.items() if "TMAX" in v]
        peak = max(tmax, key=lambda p: p[1]) if tmax else None
        observations.append({
            "station": sid, "year": year, "periodType": "calendar year", "expectedDays": expected,
            "precipAcceptedDays": len(prcp), "precipIn": round(sum(prcp) / 254, 2) if len(prcp) == expected else None,
            "tmaxAcceptedDays": len(tmax),
            "peakHighF": round(peak[1] / 10 * 9 / 5 + 32, 1) if peak else None,
            "peakDate": peak[0].isoformat() if peak else None,
            "daysRoundedHighAtLeast90F": sum(round(v / 10 * 9 / 5 + 32) >= 90 for _, v in tmax) if len(tmax) == expected else None,
        })

comparisons = []
for variable, filename in [("highF", "noaa-normal-comparison-max.csv"), ("lowF", "noaa-normal-comparison-min.csv")]:
    for row in csv.DictReader((ROOT / filename).open()):
        if row["GHCN_ID"] not in ["USW00023174", "USW00093134"]:
            continue
        comparisons.append({
            "stationId": row["GHCN_ID"], "variable": variable, "month": int(row["MONTH"]),
            "published1981_2010F": int(row["OLD_1981_2010"]) / 10,
            "recomputed1981_2010F": int(row["NEW_1981_2010"]) / 10,
            "normal1991_2020F": int(row["NEW_1991_2020"]) / 10,
            "changeComparableF": round((int(row["NEW_1991_2020"]) - int(row["NEW_1981_2010"])) / 10, 1),
        })

out = {
    "retrieved": "2026-10-02", "radius": {"center": CENTER, "mi": RADIUS_MI, "method": "haversine / straight-line surface distance", "earthRadiusMi": EARTH_RADIUS_MI},
    "stations": stations, "observedCalendarYears": observations,
    "normalPeriodComparisons": comparisons,
    "dailyExtraction": {"qualityFilter": "nonmissing values with blank GHCNd QFLAG", "precipConversion": "tenths of mm / 254 = inches", "tempConversion": "tenths C / 10 × 9/5 + 32", "tempThreshold": "daysRoundedHighAtLeast90F uses whole-Fahrenheit rounding before the threshold; not a heat-risk measure", "tracePrecip": "T measurement flag is retained as zero measured precipitation", "annualRule": "report rain total only when every expected calendar day has an accepted precipitation value", "warning": "research extraction from GHCNd, not certified official annual climate report; revisions and rounding can change values"},
}
(ROOT / "weather-data.json").write_text(json.dumps(out, indent=2) + "\n")
with (ROOT / "monthly-normals.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=list(csv_rows[0]))
    writer.writeheader(); writer.writerows(csv_rows)
with (ROOT / "observed-calendar-years.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=list(observations[0]))
    writer.writeheader(); writer.writerows(observations)
print("Wrote weather-data.json, monthly-normals.csv and observed-calendar-years.csv")
for station in stations:
    print(station["label"], station["distanceMi"], station["annualPrecipInFromRoundedMonths"], station["novMarPrecipFraction"])
for station in ["lax", "downtown"]:
    complete = [r for r in observations if r["station"] == station and r["precipIn"] is not None]
    print(station, "complete-rain years", len(complete), "min", min(complete, key=lambda x: x["precipIn"]), "max", max(complete, key=lambda x: x["precipIn"]))
