# El Segundo living atlas — seasonal patterns, hazards, and useful objects

Research checked 2 October 2026. This is a primary-source editorial brief for a historical and seasonal atlas within a 25-mile straight-line radius of El Segundo. It is not a forecast, parcel-level hazard assessment, medical plan, or claim that any object has been made or is available to borrow. Suggested object names and map treatments below are original design proposals.

## Verified factual basis

### Marine layer and coast–inland contrasts

Cold coastal water cools the lowest air beneath a warmer layer: a temperature inversion. NOAA describes the persistence of this marine layer in Southern California's early summer as May Gray and June Gloom. Strong pressure aloft can compress the layer close to the coast; weaker pressure allows it to deepen and move farther inland. Terrain can interrupt that movement, and places above the inversion can be warmer and clearer than places below it. Therefore, a beach, an inland neighborhood, and a hilltop should not share one fixed comfort label. This is a physical explanation, not a measured boundary for a particular morning. [NOAA JetStream: The Marine Layer](https://www.noaa.gov/jetstream/ocean/marine-layer)

The sea breeze arises from different heating of land and water. Cooler marine air can advance inland during the day and alter temperature, humidity, and wind. Its local reach depends on the wider weather pattern, terrain, vegetation, and buildings; NOAA's generic examples should not be imported as measured El Segundo temperature differences or guaranteed afternoon cooling. [NOAA JetStream: The Sea Breeze](https://www.noaa.gov/jetstream/ocean/sea-breeze)

### Rain, dry summers, offshore wind, and terrain

NWS's regional guide describes metropolitan Southern California as having mild, sometimes wet winters and warm, very dry summers, with most rain from winter storms between November and March. Rain varies sharply with storm tracks, showers, wind direction, and terrain. Rising air over mountains can enhance precipitation. The same guide describes Santa Ana winds as dry offshore winds from the east or northeast, strongest below some passes and canyons. They occur mainly in fall and winter; falling air warms by compression, and fall events can produce coastal heat. Their impacts can include fire spread, debris, outages, and difficult travel. These are regional mechanisms, not an El Segundo frequency estimate. The guide is legacy educational material; do not reuse its old alert thresholds or assert that every offshore event is hot. [NWS San Diego: The Weather Guide](https://www.weather.gov/media/sgx/documents/The_Weather_Guide.pdf) (PDF pp. 33–35 and 42–43; zero-based pages; the history section is marked February 2012.)

### Historical variability, trends, and future scenarios

NOAA's 2022 California summary uses observations through 2020. It describes large year-to-year rainfall variability and periodic extended wet and dry intervals, and explains that atmospheric rivers can cause torrential rain. The statewide historical temperature series rose almost 3°F since the early twentieth century. Its future warming ranges come from climate-model emissions scenarios, not observed future conditions or annual local forecasts. These statewide results are useful context; they do not establish the warming rate, rainfall trend, or expected heat increase inside this 25-mile circle. The summary found no long-term statewide winter-precipitation trend through its analysis period. Avoid a single deterministic claim that every local winter will become drier. [NOAA NCEI: California State Climate Summary 2022](https://statesummaries.ncics.org/chapter/ca/)

Drought is an extended precipitation deficiency. NWS distinguishes meteorological drought (rainfall deficit), hydrologic drought (water supply effects), agricultural drought (soil and irrigation effects), and socioeconomic drought (supply and demand effects). A dry summer by itself is not proof of a declared drought, nor does a wet local storm prove that regional water supply has recovered. [NWS: Understand Drought and Know How to Respond](https://www.weather.gov/safety/drought)

The U.S. Drought Monitor is a weekly synthesis of physical indicators and local observations, with D0 identifying abnormally dry conditions and D1–D4 drought categories. Use its historical maps as separately dated regional context, not a neighborhood water restriction or property-level moisture reading. [NOAA NIDIS: California Drought Information](https://www.drought.gov/states/california)

### Heat and daily living

NWS recommends moving strenuous activities to cooler periods, reducing direct sun exposure, taking shade breaks, wearing suitable light clothing, and using a cool indoor location when needed. It also notes that fans can exhaust hot air or draw in cooler air, but should not be directed at people when a room is hotter than 90°F. Do not reduce heat comfort to a monthly average high; activity, shade, humidity, nighttime conditions, and the building matter. Current NWS information should override the seasonal plan. [NWS: During a Heat Wave](https://www.weather.gov/safety/heat-during)

### Smoke, air quality, ventilation, and combined heat

Smoke can affect a community even when the fire is far away, and can enter a building through open windows, ventilation, and leaks. A map of nearby fire locations alone does not measure personal exposure. [EPA: Wildfires and Indoor Air Quality](https://www.epa.gov/emergencies-iaq/wildfires-and-indoor-air-quality-iaq)

EPA's clean-room guidance recommends a comfortable room with windows and doors closed against smoke, no particle-producing activities, and a portable air cleaner sized for the room that does not generate ozone. A compatible higher-efficiency HVAC filter may also help; compatibility requires checking the system. Keep safely cool, and seek another suitable place if the home cannot remain cool or smoke continues entering. A homemade object should not be presented as a proven air-cleaning device. [EPA: Create a Clean Room](https://www.epa.gov/emergencies-iaq/create-clean-room-protect-indoor-air-quality-during-wildfire)

EPA's June 2026 combined heat-and-smoke guidance says that the coolest period can also be the smokiest. It recommends checking both temperature and air quality when timing outdoor activity, and explains that managing dangerous indoor heat can require tradeoffs with smoke protection. Consequently, “open the windows every evening” is unsuitable atlas copy. Describe ventilation as conditional on cooler outdoor air, acceptable air quality, safe conditions, and the building's equipment; include a cleaner-air cooling alternative. [EPA: Protect Yourself From Smoke and Heat](https://www.epa.gov/system/files/documents/2026-06/heat-and-smoke-factsheet_1.pdf) (June 2026, EPA-452/F-26-009)

AirNow recommends its Fire and Smoke Map during wildfire smoke. It combines permanent and temporary PM2.5 monitors with crowdsourced sensors, fire locations, and smoke information. The ordinary AirNow dial can show a different pollutant, such as ozone. A smoke plume and a nearby sensor should not be treated as a certified indoor reading or a guarantee for an unmonitored neighborhood. [AirNow: Using AirNow During Wildfires](https://www.airnow.gov/fires/using-airnow-during-wildfires/); [AirNow Fire and Smoke Map](https://fire.airnow.gov/)

### Travel and storm overrides

During a high wind warning, NWS directs people into a sturdy building. Outdoor areas under trees or power lines and high-profile road vehicles can be vulnerable. The atlas should make wind warnings an override for exposed recreation rather than marking a ridge or beach as always suitable. [NWS: During a High Wind Event](https://www.weather.gov/safety/wind-during)

Do not route walkers or drivers into flood water or around flooded-road barriers. A historical rain map is not a passability map. [NWS Flood Safety](https://www.weather.gov/safety/flood-turn-around-dont-drown)

Low visibility can change an otherwise comfortable coastal trip: NWS advises slower driving, extra time, low-beam headlights, and greater following distance in fog. A thermal suitability layer should not imply that transportation conditions are safe. [NWS: Driving in Fog](https://www.weather.gov/safety/fog-driving)

### Station-data interpretation

LAX's ASOS calculates running five-minute temperature averages. Its shortened public five-minute reports round to whole Celsius degrees, while official daily highs and lows use more precise internally tracked values. Daily climate-report times use local standard time. Use official climate records for historical extremes, not highs and lows reconstructed from rounded public intraday observations. This still leaves station exposure, coverage, and neighborhood representativeness to be documented by the atlas's station appendix. [NWS Los Angeles: How Is Temperature Reported at Airports (Like LAX)?](https://www.weather.gov/lox/asostemperature)

## Suggested seasonal calendar — editorial inference

These are planning defaults inferred from the verified mechanisms above. They are not monthly predictions or universal rules. Pair them with the atlas's actual station normals and dated observations.

| Period | Useful living pattern | Change plan when | Object concept connection |
| --- | --- | --- | --- |
| December–February | Choose a dry daylight interval for outdoor time; carry a removable layer and keep rain gear accessible. Plan an indoor making or reading alternative. | Storm, flood, surf, wind, air-quality, or heat information conflicts with the seasonal default. | Rain Sleeve for a notebook; Layer Roll for a light layer; Focus Dial and Ambient Lamp for indoor time. |
| March–April | Reassess shade and layers as days lengthen. Use a garden observation log before adjusting watering; follow the actual local water rules. | Late storms, rain-slick routes, wind, or unusually warm days change the outing. | Water Ledger as a manual soil/rain/watering journal; Pocket Companion as a packing reminder. |
| May–June | Allow for coastal gray mornings and variable clearing. Compare the beach and inland plan on the day; keep a removable layer in the bag. | Persistent coastal cloud, low visibility, unexpected inland heat, or a deep marine layer changes comfort. | Layer Roll; Ambient Lamp for gray-day indoor work; Pocket Companion with separate coast/inland checkboxes. |
| July–August | Start with a shade-first route and cooler activity window; compare indoor and outdoor conditions before ventilating. Choose a cooled indoor alternative during significant heat. | Hot nights, unusual humidity, smoke, poor air quality, or a weak marine layer reduces the expected relief. | Shade Dial as a manual sun/shade planning tool; Window Compass as a check-before-opening reminder; Focus Dial indoors. |
| September–October | Keep both summer shade gear and an offshore-wind plan ready. Coastal proximity can be helpful under onshore flow, but it is not a heat exemption. | Offshore heat, wind, fire alerts, smoke, or the first storm overrides the routine. | Shade Dial; Filter Caddy for storing/carrying a standard commercial cleaner and replacement filter; Pocket Companion for an alert checklist. |
| November | Return rain gear to the everyday kit while retaining heat, wind, and smoke checks. Prepare an indoor alternate and review household equipment. | Weather differs from the seasonal transition; significant hazards require following current official instructions. | Rain Sleeve; Ambient Lamp; Window Compass. |

Object names above are illustrative concepts, not inventory, bookings, fabrication claims, tested products, sensors, protective equipment, or substitutes for official guidance. The Filter Caddy is storage/handling furniture, not an original filtration technology. A shade object needs real wind and stability testing before outdoor use.

## Suitable map design

Use separate layers for coastal exposure, inland thermal range, hills/slopes, and urban surface context. Draw illustrative zones softly rather than crisp claims about exact marine-layer reach. Offer seasons and daily-use goals such as “shade,” “layers,” “rain readiness,” and “indoor alternate.” Do not name one neighborhood the optimum place for every resident or activity.

For each selected zone, show the nearest relevant station(s), elevation, record period, data category, and uncertainty. Keep these categories explicit:

- **Observed history:** a measured station value on a date, with source and station metadata.
- **Climate normals:** a defined 30-year station baseline; not the conditions expected every day.
- **Trend context:** an analysis over a stated region and period; statewide warming is not a measured local rate.
- **Scenario:** a modeled possible future with stated assumptions; not an annual prediction.
- **Illustrative suitability:** an editorial interpretation for a specified activity and season; not measured at every map point.

The 25-mile circle is an editorial area, not a meteorological barrier: systems, smoke, winds, watersheds, and water supplies cross it. Clip displayed recommendations to the circle, but allow explicitly labeled outside-area stations or regional context where necessary. Do not infer local smoke safety, landslide exposure, fire hazard, road passability, or flood probability solely from monthly temperature and rain normals.

Current information links should be clearly labeled live external resources: [NWS Los Angeles/Oxnard](https://www.weather.gov/lox/), [AirNow Fire and Smoke Map](https://fire.airnow.gov/), and [NOAA NIDIS California](https://www.drought.gov/states/california). Do not freeze today's advisories into a timeless historical atlas.

## Historical mapping connection

NWS's education resource page links both archived daily weather maps and its regional weather-history compilation. Those support a historical story about station observations and large-scale maps being interpreted alongside local terrain and reports. The weather-history compilation is selected significant events, not a complete census or a normal-frequency estimate. A dated map should carry its observation time and period rather than being presented as a modern forecast. [NWS San Diego: Education Resources](https://www.weather.gov/sgx/education_resources); [NWS: A History of Significant Weather Events in Southern California](https://www.weather.gov/media/sgx/documents/weatherhistory.pdf)

## Methodology and limitations

1. Read NOAA/NWS sources for regional mechanisms, seasonal context, station interpretation, and public hazard guidance; read EPA/AirNow for smoke and indoor-air choices. Followed primary-source links and verified the exact destinations through web reads.
2. Kept qualitative regional explanations separate from local measurements. No new interpolation, neighborhood heat series, daily smoke climatology, parcel hazard ranking, or equipment performance study was performed for this brief.
3. Included the NOAA 2022 state summary only as state-scale context, retaining its observed period through 2020 and separating its model projections from observations. Excluded today's transient alerts from seasonal factual copy.
4. Applied regional sources as clearly labeled editorial inference in the calendar. Need station normals and a radius calculation from the atlas's other research work before publishing numeric local claims.
5. NWS's legacy Weather Guide is appropriate for broad mechanisms, but its historic service descriptions, statistics, hazard criteria, and some narrative claims may be outdated. The atlas should use current official information for live decisions.
6. DWR's Drought and Conservation Tips pages appeared in web responses but returned 403 on detailed reread; no specific water-saving claim from them is used here. The HeatRisk application likewise returned 403. Use verified NWS heat guidance and link the local NWS entry point; do not imply the research captured HeatRisk data.

The practical atlas question is “what helps this activity under these conditions?” Good labels describe the tradeoff and the next check. They cannot guarantee personal comfort, forecast precision, or one universally best place to live.
