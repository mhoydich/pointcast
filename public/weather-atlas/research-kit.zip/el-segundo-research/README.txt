PointCast El Segundo research kit, accessed 2026-10-02.
Extract this folder; run python3 extract-weather-data.py to regenerate weather-data.json, monthly-normals.csv and observed-calendar-years.csv from the included exact source snapshots. No API key or network access is required.
Read weather-research.md, methodology-and-product-briefs.md and hazards-sources.md for station periods, quality flags, site moves, scenarios and limitations. Raw hashes and source URLs are in source-manifest.json.
Public aliases: evidence.json = weather-data.json; normals.csv = monthly-normals.csv; observed-years.csv = observed-calendar-years.csv.
Object Library is a concept demo only. No physical stock or booking operation is claimed. Object SVG characters are original CC0 artwork, Nouns-inspired with no imported token assets or official affiliation. Atlas guides are original PointCast editorial artwork.
