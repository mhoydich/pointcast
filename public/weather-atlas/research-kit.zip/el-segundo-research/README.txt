PointCast El Segundo research kit, accessed2026-10-02.
Extract this folder and run python3 extract-weather-data.py to regenerate weather-data.json,monthly-normals.csv and observed-calendar-years.csv from the included exact source snapshots. No API key or network access required.
See source-manifest.json for URLs and hashes. Current NOAA data can be revised. Read weather-research.md and hazards-sources.md for periods,station moves and limits.
Public website aliases:evidence.json=weather-data.json;normals.csv=monthly-normals.csv;observed-years.csv=observed-calendar-years.csv.
All object concepts and lending interactions are demo only.
