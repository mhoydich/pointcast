# El Segundo atlas: mapping method and two proposed product briefs

Research checked 2 October 2026. This is an internal implementation handoff. Seasonal hazards and living guidance are detailed in `hazards-sources.md`; station values, coordinates, record histories, and normals are being assembled separately. The proposals below do not establish physical inventory, fabrication, lending operations, a forecast service, or official affiliation with Nouns.

## Publish-ready mapping story

**A weather map used to begin with a station.** The U.S. Signal Office began the Daily Weather Map on 1 January 1871. The series evolved into charts of surface weather, upper-air height, daily high/low temperature, and precipitation. NCEI's scanned historical collection covers 1871–13 January 2002; modern weekly editions are a separate WPC product. These maps place a day in its wider weather pattern. They do not resolve the temperature of a particular porch. [NOAA NCEI Daily Weather Maps metadata](https://www.ncei.noaa.gov/access/metadata/landing-page/bin/iso?id=gov.noaa.ncdc%3AC01006), [WPC Daily Weather Map](https://www.wpc.ncep.noaa.gov/dwm/dwm.shtml)

**Contours supplied the missing landscape.** USGS's historical topographic collection preserves maps originally printed from 1884 to 2006. A dated quadrangle can show hills, contours, waterways, settlement, and changing land cover. Comparing editions helps explain the physical setting in which observations were made; a contour is elevation, not a measured temperature boundary. Historic maps use historic datums and editions, so overlays need georeferencing and metadata. [USGS Historical Topographic Maps](https://www.usgs.gov/programs/national-geospatial-program/historical-topographic-maps-preserving-past)

**A modern climate surface is an estimate between observations.** PRISM's current normals describe 1991–2020, with 800 m and 4 km grids. Its mapping uses elevation and station information; the methods also consider coastal proximity, terrain orientation, atmospheric layers, topographic position, and related physical differences. This is more defensible than connecting airport values with a smooth color gradient that ignores the coast and hills. A grid still represents a model estimate over an area, not a sensor at every home. The 2008 methods paper describes an older 1971–2000 dataset: cite it for method, not as the period of the current normals. [PRISM 1991–2020 normals](https://prism.oregonstate.edu/normals/), [Daly et al. 2008 methods paper](https://prism.oregonstate.edu/pubs/link/2008_daly-etal_ijoc.pdf)

**The best map answers a specific living question.** A useful map lets a resident select a season and a purpose—shade, a removable layer, rain readiness, a cooler outing, or an indoor alternative—then inspect tradeoffs. There is no universally optimal neighborhood. The same hill may be sunny above a shallow marine layer, exposed to wind, or cooler under another weather pattern. NOAA describes how the marine layer's depth changes and how terrain changes its reach; in early summer it can persist as May Gray or June Gloom. [NOAA Marine Layer](https://www.noaa.gov/jetstream/ocean/marine-layer)

## Proposed modern map and calendar method

1. **Declare the center.** Use one stated editorial reference point in El Segundo, with its latitude/longitude shown in the methodology. Keep that same center in the map, station inclusion checks, CSV, and text. A city has an area; a radius needs a point. The implementing team must supply the exact chosen point rather than silently changing it between views.
2. **Define 25 miles.** Use a geodesic/great-circle straight-line distance, not driving time or road distance. Twenty-five statute miles equals 40.2336 km. For a simple reproducible inclusion check use the Haversine formula with mean Earth radius 6,371.0088 km. A GIS geodesic on WGS84 is preferable for drawing the final boundary. Document which is used; do not present either as a travel catchment.
3. **Show observations first.** Display station pins, station IDs, elevation, distance from center, source, record period, and coverage caveats. Stations beyond the circle may supply clearly labeled regional context; they are not inside-area observations. Airport exposure differs from a shaded yard or a dense street.
4. **Separate layers.** Keep actual station observations, 1991–2020 normals, historical map links, regional trend context, future scenarios, and editorial suitability in distinct labeled views. Statewide warming context must not be drawn as a measured local trend.
5. **Use an honest first-release map.** If no PRISM raster is actually downloaded and processed, show categorical illustrative coastal/inland/hill areas and station pins. Label the areas “illustrative microclimate zones” and “seasonal planning guidance.” Do not call the graphics NOAA interpolation or PRISM data. Coastal cloud boundaries move; draw soft transitions or explain that visible boundaries are editorial.
6. **Reserve numerical interpolation for a documented pipeline.** To add a PRISM layer, retain the downloaded product/version, variable, units, period, resolution, retrieval date, land mask, clipping process, and cell values. Compare cells at the station locations, describe resolution limits, and provide the inputs. Do not infer indoor comfort, smoke exposure, route passability, or parcel hazard from temperature/precipitation cells.
7. **Show the tradeoff.** A selection should explain an activity fit and the next check, rather than assigning a universal “best” score. Good example: “For a shaded summer walk, compare this coastal route with your inland option; check today's heat, wind, air quality, and route conditions.” The preference is editorial, not a forecast probability.
8. **Make the calendar adaptable.** Use the six seasonal rows in `hazards-sources.md`, paired with actual monthly station normals. Display all 12 months as accessible buttons or a select menu, with keyboard operation and a text alternative to the map. The season is a planning default; current official information can change the plan.
9. **Expose limitations in place.** The circle is an editorial boundary, not a barrier to storms, smoke, wind, watersheds, or water supply. Record gaps, station moves, instruments, urban surfaces, aspect, shade, humidity, and building conditions limit generalization.

### Four evidence types that must never be blended

| Label | What it means | Required context |
| --- | --- | --- |
| Historical observation | What a station measured on a date, or what a dated incident report recorded | Station/report, date/time, units, source, coverage |
| Climate normal | A statistical baseline over a defined period | 1991–2020 here; station or modeled grid; variable and units |
| Trend context | An analyzed change over a stated area and time span | Method, region, period, consistent data versions; statewide is not local |
| Future scenario | A modeled possible future under assumptions | Emissions pathway, model/ensemble, baseline, future period, range |

Illustrative suitability is a fifth category: an interpretation of the evidence for a chosen activity. It should have its own legend and should not inherit an “observed” badge.

### Comparing “past” and current normals correctly

NOAA's latest standard station normals are 1991–2020, released in 2021 and corrected for some sites in 2023. NOAA warns that directly subtracting the separately released 2011-era 1981–2010 station normals from the 2021-era 1991–2020 normals can mix climate changes with revisions and different homogenization. For temperature comparisons, use NOAA's derived comparison files, which recompute the earlier period from the same underlying data version. The two periods overlap for 20 years; a difference between them is not automatically a linear annual trend. [NOAA U.S. Climate Normals, comparison documentation](https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals)

## Historical context suitable for a compact timeline

- **1871 onward, mapping history:** National Daily Weather Maps begin. Treat an archival chart as a dated snapshot, not a local forecast or neighborhood measurement. [NCEI metadata](https://www.ncei.noaa.gov/access/metadata/landing-page/bin/iso?id=gov.noaa.ncdc%3AC01006)
- **1884–2006, landscape history:** USGS preserves printed topographic-map editions; link the viewer rather than inventing a specific El Segundo edition that has not been fetched. [USGS collection](https://www.usgs.gov/programs/national-geospatial-program/historical-topographic-maps-preserving-past)
- **2014–2015, state drought context:** NOAA's 2022 assessment describes severe drought associated with multiple below-average precipitation years and record warmth. This is a state-scale episode, not an El Segundo soil-moisture measurement. [California State Climate Summary 2022](https://statesummaries.ncics.org/chapter/ca/)
- **7 January 2025, local-area incident:** CAL FIRE's incident record places the Palisades Fire southeast of Palisades Drive, at 34.07022, −118.54453; it records containment on 31 January 2025. Calculate its point's distance from the chosen El Segundo center before claiming circle inclusion. A point location is not the complete burn perimeter or a map of exposure across the circle. Do not infer the cause from weather or treat an event as a recurrence probability. [CAL FIRE Palisades Fire record](https://www.fire.ca.gov/incidents/2025/1/7/palisades-fire)

NOAA's 2022 California summary uses observations through 2020 and describes almost 3°F of statewide warming since the early twentieth century. It finds large rainfall variability and no long-term statewide winter-precipitation trend in its analysis. Future heat/drought statements in that report are scenarios, with emissions assumptions and uncertainty. Do not imply a measured warming rate or a guaranteed rainfall future inside the 25-mile area. [NOAA state summary](https://statesummaries.ncics.org/chapter/ca/)

For wind context, NWS says Santa Ana winds are most common September–May. Dry winds descend toward the coast through mountain passages and can warm by compression. That supports keeping wind/fire checks beyond autumn, without assigning a local event count or claiming every offshore day is hot. [NWS Mountain and Valley Winds](https://www.weather.gov/safety/wind-mountain-valley)

## Object utility and original guide proposals

These are design concepts and editorial connections, not tested equipment or loan stock. Existing Focus Dial, Ambient Lamp, and Pocket Companion concepts should remain the core catalog; each should link back to Local Object Factory.

| Guide proposal | Purpose in the atlas | Object connections and practical use |
| --- | --- | --- |
| **Cloud**, a cloud-headed pixel character | Coastal uncertainty and May–June layers | Pocket Companion packing checklist; Ambient Lamp for indoor work under a gray sky. No therapeutic lighting claim. |
| **Shade**, a canopy-headed pixel character | Sun exposure and summer timing | Shade Dial as a manual shade/time reminder; Focus Dial for an indoor session during an uncomfortable heat period. It does not measure UV or prevent heat illness. |
| **Contour**, a folded-map-headed character | Hills, exposure, terrain, and historic maps | Pocket Companion's coast/inland/hill comparison card; Window Compass reminder to compare conditions before opening windows. It is not a wind sensor. |
| **Drop**, a rain-gauge-headed character | Rain variability and water routines | Rain Sleeve for carrying a notebook; Water Ledger as a manual rain/soil/watering log. It does not certify waterproofing or replace actual local water rules. |
| **Filter**, a filter-caddy-headed character | Indoor alternative when heat and smoke intersect | A storage/handling caddy for a standard commercial air cleaner and spare filter, pending design tests; never claim homemade filtration performance. |

Use original artwork with geometric pixel styling and square glasses. State “Original PointCast characters inspired by Nouns; independent project.” If using actual Nouns trait art, record the asset source, exact files/seeds, and art license separately. The monorepo's general code license is GPL-3.0: do not treat it as proof of the art's CC0 status. The official assets README identifies the bodies/accessories/heads/glasses data and rendering workflow, and Nouns Center supplies asset downloads, but these reads did not independently establish the CC0 dedication. The implementation's asset-provenance work must verify that dedication before attributing imported art as CC0. [Nouns official asset README](https://raw.githubusercontent.com/nounsDAO/nouns-monorepo/master/packages/nouns-assets/README.md), [Nouns Center assets](https://nouns.center/assets)

## Proposed PRD: El Segundo Object Library

**Problem and audience.** A local resident can see a promising object design but cannot yet tell what it helps with, how a trial would work, or how their experience might improve it. A designer needs structured use feedback before building inventory.

**Product hypothesis.** Connecting a transparent concept catalog to a short trial-planning demo and the climate atlas will make object utility legible and produce better design questions. This is a hypothesis to evaluate; there is no evidence here of demand, lending readiness, or revenue.

**First release.** Publish Focus Dial, Ambient Lamp, and Pocket Companion, plus clearly marked seasonal concept extensions. Every card has use case, concept status, climate/season connections, care/testing questions, and a Local Object Factory link. A “Try the lending demo” flow lets a visitor choose an object and purpose, sketch a pretend trial duration, and review a local demo summary. Every step and result says that it creates no booking and no pickup commitment. Feedback can be a local worksheet or downloadable trial card; avoid contact-data collection without an actual operator and retention plan.

**Core journey.** Atlas season/zone → relevant concept → object use case → demo trial plan → reflection prompts (“What worked?”, “What failed?”, “What would you change?”) → Local Object Factory design brief. Also support catalog → atlas as the reverse journey.

**Success criteria proposed for evaluation.** In five voluntary usability sessions, all participants can identify concept status and lack of booking; at least four can complete a demo and locate the linked factory/atlas. These are proposed acceptance targets, not measured results. Technical acceptance: keyboard completion, mobile layout, visible status at every step, no payment/reservation endpoint, working reset/download, and no false availability count.

**Operations required before a real pilot.** Named operator and location, actual tracked inventory, fabrication and relevant safety testing, cleaning/care procedures, lending terms, accessibility, return/damage process, capacity, and privacy controls. Enable actual booking only after those facts exist and the owner authorizes it.

## Proposed PRD: El Segundo Weather and Living Atlas

**Problem and audience.** One city temperature fails to explain the coastal/inland/hill differences and the seasonal choices a resident makes about outdoor time, shade, layers, windows, water, and gear.

**Product hypothesis.** A map that distinguishes evidence types and pairs seasons with useful objects can improve planning literacy and local experimentation without pretending to predict each day.

**First release.** A transparent 25-mile boundary; coast/inland/hill selections; accessible month controls; NOAA station pins and monthly normals; historical observations and mapping history; clearly bounded trend/scenario context; a six-part living calendar; object-library connections; source/method appendix; downloadable CSV and planning/research briefs. Map graphics remain illustrative unless a documented raster pipeline is implemented.

**Acceptance.** A resident can identify the center/radius method, normal period, relevant station, illustrative map status, and live information links. In proposed usability checks, ask visitors to explain the difference between a normal and a forecast; record understanding rather than claiming behavioral benefit. Technical acceptance includes numeric/source consistency, radius checks, keyboard and text equivalents, legible legends, touch controls, working cross-links/images/downloads, and no unverified “optimal” score.

**Later evidence work.** Add reproducible PRISM cells; shade/land-cover context; longer same-version station comparisons; local participatory observation protocols. Treat portable sensor logs as separate citizen observations with calibration/exposure metadata, not replacement NOAA records. A live warning or forecast feature needs its own freshness, outage, source, and operational requirements.

## Business-case outline and options

| Option | Expected value to test | Cost categories | Dependency and principal risk |
| --- | --- | --- | --- |
| Publish catalog + atlas + demo now | Clearer object utility; source literacy; learn which concepts residents understand | Editorial research, design/development, hosting, maintenance, accessibility review | Content and links need periodic review; readers may mistake demo for service without prominent status |
| Staffed small physical pilot later | Observe actual use, returns, care burden, repair, and design changes | Fabrication quotes, testing, operator time, storage, cleaning, repair, replacement, administration | Requires actual operator/inventory/testing; utilization and willingness to pay are unmeasured |
| Full lending service later | Broader access and sustained design feedback if a pilot supports it | Inventory, staffing, fulfillment, systems, support, security/privacy, ongoing maintenance | Do not launch from concept-page traffic alone; operating costs and local demand remain unknown |

**Illustrative budget worksheet, not a forecast.** Assume 12 trial kits solely to structure an eventual pilot worksheet: `12 × actual quoted kit cost + testing cost + operator hours × actual rate + storage/cleaning/repair costs + an explicitly chosen contingency`. This does not assert that any kits exist or give a procurement recommendation. Atlas maintenance should similarly budget `review hours × actual rate + hosting/data/storage costs`. No revenue, savings, market-size, or payback projection is supported by this research.

**Decision gates.** Continue the concept release if visitors understand the evidence and service status. Consider a physical pilot only after operating facts exist and qualitative research supports it. Consider charging or scaling only after actual cost/use/return evidence and separate owner approval. Measure completed demos, correctly understood limitations, useful design-feedback quality, and real pilot outcomes when applicable; do not label page views as successful loans.

## Source appendix, verification, and remaining limits

Primary sources used above: NOAA NCEI Daily Weather Maps metadata; WPC Daily Weather Map; USGS Historical Topographic Maps; PRISM normals and Daly et al.'s original methods paper; NOAA U.S. Climate Normals documentation; NOAA California State Climate Summary 2022; NOAA Marine Layer; NWS Mountain and Valley Winds; CAL FIRE Palisades Fire; official Nouns asset README and Nouns Center resources. Specific living/hazard sources and their interpretations are in `hazards-sources.md`.

Verification method: opened primary pages and followed source links; used the original PRISM research PDF for the interpolation method. NOAA map metadata and WPC material were available in indexed primary-source text, while direct reruns intermittently returned timeout/403. USGS's viewer was blocked by 403; no specific local historic quadrangle was fetched. The California Fourth Assessment Los Angeles report is linked by the official CEC catalog, but its 14.3 MB PDF exceeded this web tool's fetch limit and shell networking could not resolve the host; no numeric regional projection from that unread report is used. [CEC official regional report entry](https://www.energy.ca.gov/media/2078)

No new scientific raster interpolation, parcel-level risk map, forecast, local temperature trend, equipment performance test, measured demand study, or fabrication audit was performed for this handoff. Final implementation must reconcile its station tables and exact chosen center with this method. Exact historic-map editions and imported art's CC0 provenance remain tasks for the relevant implementation lanes.
