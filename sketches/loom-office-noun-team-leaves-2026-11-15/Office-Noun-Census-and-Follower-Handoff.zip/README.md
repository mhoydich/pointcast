# Office Noun handoff for Sol and Duet

## A · Noun Census

Import **noun-census-seed.csv** as 24 independently indexed Tezos records. It covers Action Noun series four and five, Sunday Shift, and the four desk keepsakes cited by the signing desk. `catalog_key` combines chain, network, contract and token ID; upsert on that key if a record already exists. First-seen is the index timestamp, shown in UTC and Eastern time. Scene labels are editorial descriptions based on the token notes.

The verification column covers TzKT token records and indexed metadata. Artifact URIs are from that metadata. The artifact bytes, current listing availability, unfetched series and unminted drawings are outside this seed. A complete census still needs the rest of Sol's source inventory and art-only records. Keep off-chain observations separate from chain facts.

Sources: [Sol's acceptance](https://pointcast.xyz/loom?to=loom%3A46888ec7422b6de42a49d8dc%23m_0l1a1y0z0w) · [Signing desk's series four and desk keepsakes](https://pointcast.xyz/loom?to=loom%3A46888ec7422b6de42a49d8dc%23m_3s493a096w) · [Series five](https://pointcast.xyz/loom?to=loom%3A46888ec7422b6de42a49d8dc%23m_0w3118122h) · [Sunday Shift](https://pointcast.xyz/loom?to=loom%3A46888ec7422b6de42a49d8dc%23m_6u3z0w6x37).

## F · Follower Nouns

**follower-noun-intake.csv** has 25 empty follower slots, 25 unassigned full Noun portraits and one short, editable invitation per portrait. The contact sheet previews the casting. The portraits are composed in code from CC0 official background, body, accessory, head and glasses data; the CSV records each layer. Pick or change the cast once the evidence-backed list arrives.

Duet still needs a dated snapshot of the latest 25 @officenoun followers from the X desk. Record what order the source shows. If recency is unknown, keep the order field unknown and leave the batch unresolved. At handoff, one handle per row with the dated evidence reference is enough. Handles and evidence fields start blank.

Sources: [Duet's blocker](https://pointcast.xyz/loom?to=loom%3A46888ec7422b6de42a49d8dc%23m_1m6u4n5i3j) · [Standup](https://pointcast.xyz/loom?to=loom%3A46888ec7422b6de42a49d8dc%23m_5y4r4z6735) · [Official Nouns trait data](https://github.com/nounsDAO/nouns-monorepo/blob/master/packages/nouns-assets/src/image-data.json).

Official trait data SHA-256: `a03f22b7838b35fdf0332617c9b8e2b032eb26cf1632afbefb200fec64c4bc20`.
